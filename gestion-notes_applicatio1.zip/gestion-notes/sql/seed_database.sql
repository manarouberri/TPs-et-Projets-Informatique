START TRANSACTION;

INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role, actif)
VALUES ('Admin', 'Super', 'admin@university.local', '$2y$10$QpM8wHnI2C3bq3vN6t5YPeCw8YkJk5b2fVxWqYQp3E0VbC1n8fW.q', 'admin', 1)
ON DUPLICATE KEY UPDATE id = id;

INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role, actif)
VALUES ('Emmanuel', '', 'emmanuel@university.euromed', '$2y$10$QpM8wHnI2C3bq3vN6t5YPeCw8YkJk5b2fVxWqYQp3E0VbC1n8fW.q', 'professeur', 1)
ON DUPLICATE KEY UPDATE id = id;

SET @admin_id = (SELECT id FROM utilisateurs WHERE email = 'admin@university.local');
SET @prof_id  = (SELECT id FROM utilisateurs WHERE email = 'emmanuel@university.euromed');

INSERT INTO filieres (code, nom, niveau, responsable_id)
VALUES ('FCS', 'Informatique', 'L3', @admin_id)
ON DUPLICATE KEY UPDATE id = id;
SET @filiere_id = (SELECT id FROM filieres WHERE code = 'FCS');

INSERT INTO periodes (nom, code, annee_universitaire, type, date_debut_saisie, date_fin_saisie, statut)
VALUES ('Semestre 1', 'S1-2025', '2025/2026', 'semestre', '2026-01-01 00:00:00', '2026-02-01 23:59:59', 'ouverte')
ON DUPLICATE KEY UPDATE id = id;
SET @periode_id = (SELECT id FROM periodes WHERE code = 'S1-2025');

INSERT INTO matieres (code, nom, filiere_id, coefficient, credits, seuil_validation)
VALUES ('ALG101', 'Algèbre', @filiere_id, 1.0, 4, 10.00)
ON DUPLICATE KEY UPDATE id = id;
SET @matiere_id = (SELECT id FROM matieres WHERE code = 'ALG101');

INSERT INTO affectations_profs (professeur_id, matiere_id, periode_id, groupe)
VALUES (@prof_id, @matiere_id, @periode_id, 'A')
ON DUPLICATE KEY UPDATE professeur_id = professeur_id;

INSERT INTO configuration_colonnes (matiere_id, periode_id, nom_colonne, code_colonne, type, note_max, coefficient, obligatoire, ordre)
VALUES 
(@matiere_id, @periode_id, 'Devoir Surveillé', 'DS', 'note', 20.00, 1.0, TRUE, 1),
(@matiere_id, @periode_id, 'Travaux Pratiques', 'TP', 'note', 20.00, 1.0, TRUE, 2),
(@matiere_id, @periode_id, 'Examen Final', 'EX', 'note', 20.00, 1.0, TRUE, 3)
ON DUPLICATE KEY UPDATE id = id;

INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role, actif)
VALUES 
('Étudiant', 'Alpha', 'alpha.etudiant@university.edu', '', 'etudiant', 1),
('Étudiant', 'Beta', 'beta.etudiant@university.edu', '', 'etudiant', 1),
('Étudiant', 'Gamma', 'gamma.etudiant@university.edu', '', 'etudiant', 1)
ON DUPLICATE KEY UPDATE id = id;

SET @stu1 = (SELECT id FROM utilisateurs WHERE email = 'alpha.etudiant@university.edu');
SET @stu2 = (SELECT id FROM utilisateurs WHERE email = 'beta.etudiant@university.edu');
SET @stu3 = (SELECT id FROM utilisateurs WHERE email = 'gamma.etudiant@university.edu');

INSERT INTO inscriptions_matieres (etudiant_id, matiere_id, periode_id, groupe, dispense)
VALUES 
(@stu1, @matiere_id, @periode_id, 'A', FALSE),
(@stu2, @matiere_id, @periode_id, 'A', FALSE),
(@stu3, @matiere_id, @periode_id, 'A', FALSE)
ON DUPLICATE KEY UPDATE etudiant_id = etudiant_id;

INSERT INTO progression_saisie (matiere_id, periode_id, professeur_id, total_etudiants, total_notes_attendues, notes_saisies, pourcentage, valide_par_prof)
VALUES (
    @matiere_id, 
    @periode_id, 
    @prof_id, 
    (SELECT COUNT(*) FROM inscriptions_matieres WHERE matiere_id = @matiere_id AND periode_id = @periode_id),
    (SELECT COUNT(*) FROM inscriptions_matieres WHERE matiere_id = @matiere_id AND periode_id = @periode_id) * 
    (SELECT COUNT(*) FROM configuration_colonnes WHERE matiere_id = @matiere_id AND periode_id = @periode_id),
    0,
    0.00,
    FALSE
)
ON DUPLICATE KEY UPDATE id = id;

INSERT INTO formules (matiere_id, periode_id, formule, description)
VALUES (@matiere_id, @periode_id, '(DS*0.3 + TP*0.2 + EX*0.5)', 'Moyenne pondérée classique')
ON DUPLICATE KEY UPDATE formule = formule;

COMMIT;

