-- =============================================
-- PROFESSOR MODULE - DATABASE SCHEMA
-- Grade Management System
-- =============================================
-- This schema implements the complete database structure
-- for the Professor Module with all required tables
-- =============================================

-- 1️⃣ GRADING PERIODS TABLE
-- Read access + lock control for professors
CREATE TABLE periodes ( 
    id                  INT PRIMARY KEY AUTO_INCREMENT, 
    nom                 VARCHAR(100) NOT NULL, 
    code                VARCHAR(20) UNIQUE NOT NULL, 
    annee_universitaire VARCHAR(9) NOT NULL, 
    type                ENUM('semestre', 'trimestre', 'session', 'rattrapage') NOT NULL, 
    date_debut_saisie   DATETIME NOT NULL, 
    date_fin_saisie     DATETIME NOT NULL, 
    statut              ENUM('a_venir', 'ouverte', 'fermee', 'publiee') DEFAULT 'a_venir', 
    date_creation       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Index for performance
    INDEX idx_statut (statut),
    INDEX idx_periode_active (date_debut_saisie, date_fin_saisie)
);

-- 2️⃣ SUBJECTS TABLE  
-- Consultation by the professor
CREATE TABLE matieres ( 
    id                  INT PRIMARY KEY AUTO_INCREMENT, 
    code                VARCHAR(20) UNIQUE NOT NULL, 
    nom                 VARCHAR(150) NOT NULL, 
    coefficient         DECIMAL(3,1) DEFAULT 1, 
    seuil_validation    DECIMAL(4,2) DEFAULT 10, 
    date_creation       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Index for performance
    INDEX idx_code (code)
);

-- 3️⃣ PROFESSOR–SUBJECT ASSIGNMENTS
-- Central access control for the module
CREATE TABLE affectations_profs ( 
    id              INT PRIMARY KEY AUTO_INCREMENT, 
    professeur_id   INT NOT NULL, 
    matiere_id      INT NOT NULL, 
    periode_id      INT NOT NULL, 
    groupe          VARCHAR(50), 
    
    -- Composite unique key to prevent duplicate assignments
    UNIQUE KEY unique_affectation (professeur_id, matiere_id, periode_id, groupe),
    
    -- Foreign key constraints
    FOREIGN KEY (matiere_id) REFERENCES matieres(id) ON DELETE CASCADE,
    FOREIGN KEY (periode_id) REFERENCES periodes(id) ON DELETE CASCADE,
    
    -- Indexes for performance
    INDEX idx_professeur (professeur_id),
    INDEX idx_matiere (matiere_id),
    INDEX idx_periode (periode_id)
);

-- 4️⃣ DYNAMIC COLUMN CONFIGURATION
-- Read-only access for the professor module
CREATE TABLE configuration_colonnes ( 
    id              INT PRIMARY KEY AUTO_INCREMENT, 
    matiere_id      INT NOT NULL, 
    periode_id      INT NOT NULL, 
    nom_colonne     VARCHAR(50) NOT NULL, 
    code_colonne    VARCHAR(20) NOT NULL, 
    type            ENUM('note', 'bonus', 'malus', 'info') DEFAULT 'note', 
    note_max        DECIMAL(5,2) DEFAULT 20, 
    coefficient     DECIMAL(3,1) DEFAULT 1, 
    obligatoire     BOOLEAN DEFAULT TRUE, 
    ordre           INT NOT NULL, 
    date_creation   TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
    
    -- Composite unique key to prevent duplicate columns
    UNIQUE KEY unique_colonne (matiere_id, periode_id, code_colonne),
    
    -- Foreign key constraints
    FOREIGN KEY (matiere_id) REFERENCES matieres(id) ON DELETE CASCADE,
    FOREIGN KEY (periode_id) REFERENCES periodes(id) ON DELETE CASCADE,
    
    -- Indexes for performance
    INDEX idx_config_matiere (matiere_id),
    INDEX idx_config_periode (periode_id),
    INDEX idx_ordre (ordre)
);

-- 5️⃣ STUDENT ENROLLMENTS IN SUBJECTS
-- Determines the rows of the spreadsheet
CREATE TABLE inscriptions_matieres ( 
    id                  INT PRIMARY KEY AUTO_INCREMENT, 
    etudiant_id         INT NOT NULL, 
    matiere_id          INT NOT NULL, 
    periode_id          INT NOT NULL, 
    groupe              VARCHAR(50), 
    dispense            BOOLEAN DEFAULT FALSE, 
    date_inscription    TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
    
    -- Composite unique key to prevent duplicate enrollments
    UNIQUE KEY unique_inscription (etudiant_id, matiere_id, periode_id),
    
    -- Foreign key constraints
    FOREIGN KEY (matiere_id) REFERENCES matieres(id) ON DELETE CASCADE,
    FOREIGN KEY (periode_id) REFERENCES periodes(id) ON DELETE CASCADE,
    
    -- Indexes for performance
    INDEX idx_inscription_etudiant (etudiant_id),
    INDEX idx_inscription_matiere (matiere_id),
    INDEX idx_inscription_periode (periode_id),
    INDEX idx_groupe (groupe)
);

-- 6️⃣ GRADES TABLE
-- Core of the professor module
CREATE TABLE notes ( 
    id                  INT PRIMARY KEY AUTO_INCREMENT, 
    etudiant_id         INT NOT NULL, 
    colonne_id          INT NOT NULL, 
    valeur              DECIMAL(5,2), 
    statut              ENUM('saisie', 'absent', 'dispense', 'defaillant') DEFAULT 'saisie', 
    saisi_par           INT NOT NULL, 
    date_saisie         TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
    date_modification   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
    
    -- Composite unique key to prevent duplicate grades
    UNIQUE KEY unique_note (etudiant_id, colonne_id),
    
    -- Foreign key constraints
    FOREIGN KEY (colonne_id) REFERENCES configuration_colonnes(id) ON DELETE CASCADE,
    
    -- Indexes for performance
    INDEX idx_notes_etudiant (etudiant_id),
    INDEX idx_notes_colonne (colonne_id),
    INDEX idx_saisi_par (saisi_par),
    INDEX idx_statut (statut)
);

-- 7️⃣ GRADE MODIFICATION HISTORY (AUDIT)
-- Mandatory integrity and traceability
CREATE TABLE historique_notes ( 
    id                  INT PRIMARY KEY AUTO_INCREMENT, 
    note_id             INT NOT NULL, 
    ancienne_valeur     DECIMAL(5,2), 
    nouvelle_valeur     DECIMAL(5,2), 
    ancien_statut       VARCHAR(20), 
    nouveau_statut      VARCHAR(20), 
    modifie_par         INT NOT NULL, 
    motif               TEXT, 
    adresse_ip          VARCHAR(45), 
    date_modification   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign key constraint
    FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE,
    
    -- Indexes for performance
    INDEX idx_historique_note (note_id),
    INDEX idx_historique_modifieur (modifie_par),
    INDEX idx_historique_date (date_modification)
);

-- 8️⃣ GRADE ENTRY PROGRESS AND VALIDATION
-- Final validation & locking
CREATE TABLE progression_saisie ( 
    id                      INT PRIMARY KEY AUTO_INCREMENT, 
    matiere_id              INT NOT NULL, 
    periode_id              INT NOT NULL, 
    professeur_id           INT NOT NULL, 
    total_etudiants         INT NOT NULL, 
    total_notes_attendues   INT NOT NULL, 
    notes_saisies           INT DEFAULT 0, 
    pourcentage             DECIMAL(5,2) DEFAULT 0, 
    valide_par_prof         BOOLEAN DEFAULT FALSE, 
    date_validation         DATETIME, 
    date_mise_a_jour        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
    
    -- Composite unique key to prevent duplicate progress tracking
    UNIQUE KEY unique_progression (matiere_id, periode_id),
    
    -- Foreign key constraints
    FOREIGN KEY (matiere_id) REFERENCES matieres(id) ON DELETE CASCADE,
    FOREIGN KEY (periode_id) REFERENCES periodes(id) ON DELETE CASCADE,
    
    -- Indexes for performance
    INDEX idx_progression_matiere (matiere_id),
    INDEX idx_progression_periode (periode_id),
    INDEX idx_professeur (professeur_id),
    INDEX idx_valide (valide_par_prof)
);

-- =============================================
-- ADDITIONAL TABLES FOR COMPLETE FUNCTIONALITY
-- =============================================

-- PROFESSORS TABLE (Basic structure - will be linked to main user system)
CREATE TABLE professeurs (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    nom             VARCHAR(100) NOT NULL,
    prenom          VARCHAR(100) NOT NULL,
    email           VARCHAR(255) UNIQUE NOT NULL,
    telephone       VARCHAR(20),
    departement     VARCHAR(100),
    actif           BOOLEAN DEFAULT TRUE,
    date_creation   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_email (email),
    INDEX idx_actif (actif)
);

-- STUDENTS TABLE (Basic structure - will be linked to main student system)
CREATE TABLE etudiants (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    numero_etudiant VARCHAR(20) UNIQUE NOT NULL,
    nom             VARCHAR(100) NOT NULL,
    prenom          VARCHAR(100) NOT NULL,
    email           VARCHAR(255),
    date_naissance  DATE,
    actif           BOOLEAN DEFAULT TRUE,
    date_creation   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_numero_etudiant (numero_etudiant),
    INDEX idx_actif (actif)
);

-- =============================================
-- TRIGGERS FOR AUTOMATIC MAINTENANCE
-- =============================================

-- Trigger to automatically update progression_saisie when notes are inserted/updated
DELIMITER //

CREATE TRIGGER after_note_insert
AFTER INSERT ON notes
FOR EACH ROW
BEGIN
    -- Update progression_saisie table
    UPDATE progression_saisie 
    SET notes_saisies = (
        SELECT COUNT(*) 
        FROM notes n
        JOIN configuration_colonnes cc ON n.colonne_id = cc.id
        WHERE cc.matiere_id = (SELECT matiere_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND cc.periode_id = (SELECT periode_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND n.valeur IS NOT NULL
    ),
    pourcentage = (
        SELECT ROUND((COUNT(*) * 100.0) / NULLIF(total_notes_attendues, 0), 2)
        FROM notes n
        JOIN configuration_colonnes cc ON n.colonne_id = cc.id
        WHERE cc.matiere_id = (SELECT matiere_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND cc.periode_id = (SELECT periode_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND n.valeur IS NOT NULL
    ),
    date_mise_a_jour = CURRENT_TIMESTAMP
    WHERE matiere_id = (SELECT matiere_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
    AND periode_id = (SELECT periode_id FROM configuration_colonnes WHERE id = NEW.colonne_id);
END//

CREATE TRIGGER after_note_update
AFTER UPDATE ON notes
FOR EACH ROW
BEGIN
    -- Insert audit record if value changed
    IF OLD.valeur != NEW.valeur OR OLD.statut != NEW.statut THEN
        INSERT INTO historique_notes (
            note_id, ancienne_valeur, nouvelle_valeur, 
            ancien_statut, nouveau_statut, modifie_par, adresse_ip
        ) VALUES (
            NEW.id, OLD.valeur, NEW.valeur, 
            OLD.statut, NEW.statut, NEW.saisi_par, 
            COALESCE(@_ip_address, 'unknown')
        );
    END IF;
    
    -- Update progression_saisie table
    UPDATE progression_saisie 
    SET notes_saisies = (
        SELECT COUNT(*) 
        FROM notes n
        JOIN configuration_colonnes cc ON n.colonne_id = cc.id
        WHERE cc.matiere_id = (SELECT matiere_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND cc.periode_id = (SELECT periode_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND n.valeur IS NOT NULL
    ),
    pourcentage = (
        SELECT ROUND((COUNT(*) * 100.0) / NULLIF(total_notes_attendues, 0), 2)
        FROM notes n
        JOIN configuration_colonnes cc ON n.colonne_id = cc.id
        WHERE cc.matiere_id = (SELECT matiere_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND cc.periode_id = (SELECT periode_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND n.valeur IS NOT NULL
    ),
    date_mise_a_jour = CURRENT_TIMESTAMP
    WHERE matiere_id = (SELECT matiere_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
    AND periode_id = (SELECT periode_id FROM configuration_colonnes WHERE id = NEW.colonne_id);
END//

DELIMITER ;

-- =============================================
-- STORED PROCEDURES FOR COMMON OPERATIONS
-- =============================================

DELIMITER //

-- Procedure to initialize progression_saisie for a new subject/period assignment
CREATE PROCEDURE initialiser_progression_saisie(
    IN p_matiere_id INT,
    IN p_periode_id INT,
    IN p_professeur_id INT
)
BEGIN
    DECLARE v_total_etudiants INT;
    DECLARE v_total_notes_attendues INT;
    
    -- Calculate total students enrolled
    SELECT COUNT(*) INTO v_total_etudiants
    FROM inscriptions_matieres
    WHERE matiere_id = p_matiere_id 
    AND periode_id = p_periode_id
    AND dispense = FALSE;
    
    -- Calculate total expected notes (students × columns)
    SELECT COUNT(*) INTO v_total_notes_attendues
    FROM inscriptions_matieres im
    CROSS JOIN configuration_colonnes cc
    WHERE im.matiere_id = p_matiere_id 
    AND im.periode_id = p_periode_id
    AND cc.matiere_id = p_matiere_id
    AND cc.periode_id = p_periode_id
    AND im.dispense = FALSE
    AND cc.obligatoire = TRUE;
    
    -- Insert or update progression record
    INSERT INTO progression_saisie (
        matiere_id, periode_id, professeur_id, 
        total_etudiants, total_notes_attendues
    ) VALUES (
        p_matiere_id, p_periode_id, p_professeur_id,
        v_total_etudiants, v_total_notes_attendues
    ) ON DUPLICATE KEY UPDATE
        total_etudiants = v_total_etudiants,
        total_notes_attendues = v_total_notes_attendues,
        date_mise_a_jour = CURRENT_TIMESTAMP;
END//

DELIMITER ;

-- =============================================
-- SAMPLE DATA FOR TESTING
-- =============================================

-- Insert sample academic periods
INSERT INTO periodes (nom, code, annee_universitaire, type, date_debut_saisie, date_fin_saisie, statut) VALUES
('Automne 2024', 'AUT2024', '2024-2025', 'semestre', '2024-09-01 00:00:00', '2024-12-20 23:59:59', 'ouverte'),
('Printemps 2025', 'PRN2025', '2024-2025', 'semestre', '2025-01-15 00:00:00', '2025-05-15 23:59:59', 'a_venir'),
('Été 2025', 'ETE2025', '2024-2025', 'session', '2025-06-01 00:00:00', '2025-08-10 23:59:59', 'a_venir');

-- Insert sample subjects
INSERT INTO matieres (code, nom, coefficient, seuil_validation) VALUES
('MATH101', 'Mathématiques - Calcul I', 3.0, 10.00),
('PHYS201', 'Physique - Mécanique', 2.5, 10.00),
('CHEM301', 'Chimie - Chimie Organique', 2.0, 10.00),
('INFO101', 'Informatique - Programmation I', 3.0, 10.00);

-- Insert sample professors
INSERT INTO professeurs (nom, prenom, email, telephone, departement) VALUES
('Dupont', 'Jean', 'jean.dupont@university.edu', '0123456789', 'Mathématiques'),
('Martin', 'Marie', 'marie.martin@university.edu', '0123456790', 'Physique'),
('Bernard', 'Pierre', 'pierre.bernard@university.edu', '0123456791', 'Chimie');

-- Insert sample students
INSERT INTO etudiants (numero_etudiant, nom, prenom, email) VALUES
('STU001', 'Étudiant', 'Alpha', 'alpha.etudiant@university.edu'),
('STU002', 'Étudiant', 'Beta', 'beta.etudiant@university.edu'),
('STU003', 'Étudiant', 'Gamma', 'gamma.etudiant@university.edu'),
('STU004', 'Étudiant', 'Delta', 'delta.etudiant@university.edu'),
('STU005', 'Étudiant', 'Epsilon', 'epsilon.etudiant@university.edu');

-- =============================================
-- SCHEMA COMPLETION MESSAGE
-- =============================================

SELECT 'Professor Module Database Schema created successfully!' AS Message;
SELECT 'Tables created: periodes, matieres, affectations_profs, configuration_colonnes, inscriptions_matieres, notes, historique_notes, progression_saisie' AS Tables_Created;
SELECT 'Additional tables: professeurs, etudiants' AS Additional_Tables;
SELECT 'Triggers created: after_note_insert, after_note_update' AS Triggers_Created;
SELECT 'Procedures created: initialiser_progression_saisie' AS Procedures_Created;
SELECT 'Sample data inserted for testing' AS Sample_Data;