CREATE TABLE utilisateurs (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    nom             VARCHAR(100) NOT NULL,
    prenom          VARCHAR(100) NOT NULL,
    email           VARCHAR(150) UNIQUE NOT NULL,
    mot_de_passe    VARCHAR(255) NOT NULL,
    role            ENUM('admin', 'professeur', 'etudiant') NOT NULL,
    actif           BOOLEAN DEFAULT TRUE,
    date_creation   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE periodes (
    id                  INT PRIMARY KEY AUTO_INCREMENT,
    nom                 VARCHAR(100) NOT NULL,
    code                VARCHAR(20) UNIQUE NOT NULL,
    annee_universitaire VARCHAR(9) NOT NULL,
    type                ENUM('semestre', 'trimestre', 'session', 'rattrapage') NOT NULL,
    date_debut_saisie   DATETIME NOT NULL,
    date_fin_saisie     DATETIME NOT NULL,
    statut              ENUM('a_venir', 'ouverte', 'fermee', 'publiee') DEFAULT 'a_venir',
    date_publication    DATETIME,
    date_creation       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_statut (statut),
    INDEX idx_periode_active (date_debut_saisie, date_fin_saisie)
);

CREATE TABLE filieres (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    code            VARCHAR(20) UNIQUE NOT NULL,
    nom             VARCHAR(150) NOT NULL,
    niveau          VARCHAR(20),
    responsable_id  INT,
    date_creation   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (responsable_id) REFERENCES utilisateurs(id)
);

CREATE TABLE matieres (
    id                INT PRIMARY KEY AUTO_INCREMENT,
    code              VARCHAR(20) UNIQUE NOT NULL,
    nom               VARCHAR(150) NOT NULL,
    filiere_id        INT NOT NULL,
    coefficient       DECIMAL(3,1) DEFAULT 1,
    credits           INT,
    seuil_validation  DECIMAL(4,2) DEFAULT 10,
    date_creation     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (filiere_id) REFERENCES filieres(id),
    INDEX idx_code (code)
);

CREATE TABLE affectations_profs (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    professeur_id   INT NOT NULL,
    matiere_id      INT NOT NULL,
    periode_id      INT NOT NULL,
    groupe          VARCHAR(50),
    UNIQUE KEY unique_affectation (professeur_id, matiere_id, periode_id, groupe),
    FOREIGN KEY (professeur_id) REFERENCES utilisateurs(id),
    FOREIGN KEY (matiere_id) REFERENCES matieres(id),
    FOREIGN KEY (periode_id) REFERENCES periodes(id),
    INDEX idx_professeur (professeur_id),
    INDEX idx_matiere (matiere_id),
    INDEX idx_periode (periode_id)
);

CREATE TABLE configuration_colonnes (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    matiere_id      INT NOT NULL,
    periode_id      INT NOT NULL,
    nom_colonne     VARCHAR(50) NOT NULL,
    code_colonne    VARCHAR(20) NOT NULL,
    type            ENUM('note', 'bonus', 'malus', 'info') DEFAULT 'note',
    note_max        DECIMAL(5,2) DEFAULT 20,
    coefficient     DECIMAL(3,1) DEFAULT 1,
    obligatoire     BOOLEAN DEFAULT TRUE,
    ordre           INT NOT NULL,
    date_creation   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_colonne (matiere_id, periode_id, code_colonne),
    FOREIGN KEY (matiere_id) REFERENCES matieres(id),
    FOREIGN KEY (periode_id) REFERENCES periodes(id),
    INDEX idx_config_matiere (matiere_id),
    INDEX idx_config_periode (periode_id),
    INDEX idx_ordre (ordre)
);

CREATE TABLE inscriptions_matieres (
    id                  INT PRIMARY KEY AUTO_INCREMENT,
    etudiant_id         INT NOT NULL,
    matiere_id          INT NOT NULL,
    periode_id          INT NOT NULL,
    groupe              VARCHAR(50),
    dispense            BOOLEAN DEFAULT FALSE,
    date_inscription    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_inscription (etudiant_id, matiere_id, periode_id),
    FOREIGN KEY (etudiant_id) REFERENCES utilisateurs(id),
    FOREIGN KEY (matiere_id) REFERENCES matieres(id),
    FOREIGN KEY (periode_id) REFERENCES periodes(id),
    INDEX idx_inscription_etudiant (etudiant_id),
    INDEX idx_inscription_matiere (matiere_id),
    INDEX idx_inscription_periode (periode_id),
    INDEX idx_groupe (groupe)
);

CREATE TABLE notes (
    id                  INT PRIMARY KEY AUTO_INCREMENT,
    etudiant_id         INT NOT NULL,
    colonne_id          INT NOT NULL,
    valeur              DECIMAL(5,2),
    statut              ENUM('saisie', 'absent', 'dispense', 'defaillant') DEFAULT 'saisie',
    saisi_par           INT NOT NULL,
    date_saisie         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_modification   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_note (etudiant_id, colonne_id),
    FOREIGN KEY (colonne_id) REFERENCES configuration_colonnes(id) ON DELETE CASCADE,
    INDEX idx_notes_etudiant (etudiant_id),
    INDEX idx_notes_colonne (colonne_id),
    INDEX idx_saisi_par (saisi_par),
    INDEX idx_statut (statut)
);

CREATE TABLE historique_notes (
    id                  INT PRIMARY KEY AUTO_INCREMENT,
    note_id             INT NOT NULL,
    ancienne_valeur     DECIMAL(5,2),
    nouvelle_valeur     DECIMAL(5,2),
    ancien_statut       VARCHAR(20),
    nouveau_statut      VARCHAR(20),
    modifie_par         INT NOT NULL,
    motif               TEXT,
    adresse_ip          VARCHAR(45),
    date_modification   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE,
    INDEX idx_historique_note (note_id),
    INDEX idx_historique_modifieur (modifie_par),
    INDEX idx_historique_date (date_modification)
);

CREATE TABLE progression_saisie (
    id                      INT PRIMARY KEY AUTO_INCREMENT,
    matiere_id              INT NOT NULL,
    periode_id              INT NOT NULL,
    professeur_id           INT NOT NULL,
    total_etudiants         INT NOT NULL,
    total_notes_attendues   INT NOT NULL,
    notes_saisies           INT DEFAULT 0,
    pourcentage             DECIMAL(5,2) DEFAULT 0,
    valide_par_prof         BOOLEAN DEFAULT FALSE,
    date_validation         DATETIME,
    date_mise_a_jour        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_progression (matiere_id, periode_id),
    FOREIGN KEY (matiere_id) REFERENCES matieres(id) ON DELETE CASCADE,
    FOREIGN KEY (periode_id) REFERENCES periodes(id) ON DELETE CASCADE,
    INDEX idx_progression_periode (periode_id),
    INDEX idx_professeur (professeur_id),
    INDEX idx_valide (valide_par_prof)
);

CREATE TABLE formules (
    id                INT PRIMARY KEY AUTO_INCREMENT,
    matiere_id        INT NOT NULL,
    periode_id        INT NOT NULL,
    formule           TEXT NOT NULL,
    description       VARCHAR(255),
    date_creation     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_modification TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_formule (matiere_id, periode_id),
    FOREIGN KEY (matiere_id) REFERENCES matieres(id),
    FOREIGN KEY (periode_id) REFERENCES periodes(id)
);

CREATE TABLE templates_formules (
    id                INT PRIMARY KEY AUTO_INCREMENT,
    nom               VARCHAR(100) NOT NULL,
    description       TEXT,
    colonnes_requises JSON NOT NULL,
    formule           TEXT NOT NULL,
    categorie         VARCHAR(50),
    date_creation     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE moyennes (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    etudiant_id     INT NOT NULL,
    matiere_id      INT NOT NULL,
    periode_id      INT NOT NULL,
    valeur          DECIMAL(5,2),
    date_calcul     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_moyenne (etudiant_id, matiere_id, periode_id),
    FOREIGN KEY (etudiant_id) REFERENCES utilisateurs(id),
    FOREIGN KEY (matiere_id) REFERENCES matieres(id),
    FOREIGN KEY (periode_id) REFERENCES periodes(id),
    INDEX idx_moyenne_etudiant (etudiant_id),
    INDEX idx_moyenne_matiere (matiere_id),
    INDEX idx_moyenne_periode (periode_id)
);

CREATE VIEW professeurs AS
SELECT id, nom, prenom, email FROM utilisateurs WHERE role = 'professeur';

CREATE VIEW etudiants AS
SELECT id, nom, prenom, email FROM utilisateurs WHERE role = 'etudiant';

DELIMITER //
CREATE TRIGGER after_note_insert
AFTER INSERT ON notes
FOR EACH ROW
BEGIN
    UPDATE progression_saisie 
    SET notes_saisies = (
        SELECT COUNT(*) 
        FROM notes n
        JOIN configuration_colonnes cc ON n.colonne_id = cc.id
        WHERE cc.matiere_id = (SELECT matiere_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND cc.periode_id = (SELECT periode_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND n.valeur IS NOT NULL
    ),
    pourcentage = (
        SELECT ROUND((COUNT(*) * 100.0) / NULLIF(total_notes_attendues, 0), 2)
        FROM notes n
        JOIN configuration_colonnes cc ON n.colonne_id = cc.id
        WHERE cc.matiere_id = (SELECT matiere_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND cc.periode_id = (SELECT periode_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND n.valeur IS NOT NULL
    ),
    date_mise_a_jour = CURRENT_TIMESTAMP
    WHERE matiere_id = (SELECT matiere_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
    AND periode_id = (SELECT periode_id FROM configuration_colonnes WHERE id = NEW.colonne_id);
END//

CREATE TRIGGER after_note_update
AFTER UPDATE ON notes
FOR EACH ROW
BEGIN
    IF OLD.valeur != NEW.valeur OR OLD.statut != NEW.statut THEN
        INSERT INTO historique_notes (
            note_id, ancienne_valeur, nouvelle_valeur, 
            ancien_statut, nouveau_statut, modifie_par, adresse_ip
        ) VALUES (
            NEW.id, OLD.valeur, NEW.valeur, 
            OLD.statut, NEW.statut, NEW.saisi_par, 
            COALESCE(@_ip_address, 'unknown')
        );
    END IF;
    UPDATE progression_saisie 
    SET notes_saisies = (
        SELECT COUNT(*) 
        FROM notes n
        JOIN configuration_colonnes cc ON n.colonne_id = cc.id
        WHERE cc.matiere_id = (SELECT matiere_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND cc.periode_id = (SELECT periode_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND n.valeur IS NOT NULL
    ),
    pourcentage = (
        SELECT ROUND((COUNT(*) * 100.0) / NULLIF(total_notes_attendues, 0), 2)
        FROM notes n
        JOIN configuration_colonnes cc ON n.colonne_id = cc.id
        WHERE cc.matiere_id = (SELECT matiere_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND cc.periode_id = (SELECT periode_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
        AND n.valeur IS NOT NULL
    ),
    date_mise_a_jour = CURRENT_TIMESTAMP
    WHERE matiere_id = (SELECT matiere_id FROM configuration_colonnes WHERE id = NEW.colonne_id)
    AND periode_id = (SELECT periode_id FROM configuration_colonnes WHERE id = NEW.colonne_id);
END//
DELIMITER ;

CREATE TABLE historique_admin (
    id INT PRIMARY KEY AUTO_INCREMENT,
    admin_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    entite VARCHAR(100),
    entite_id INT,
    ancienne_valeur TEXT,
    nouvelle_valeur TEXT,
    justification TEXT,
    adresse_ip VARCHAR(45),
    date_action TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES utilisateurs(id)
);
