<?php
require_once __DIR__ . '/../../app/services/auth.php';
require_etudiant();
require_once __DIR__ . '/../../app/config/database.php';
$pdo = get_pdo();
$etudiantId = (int)($_SESSION['user']['id'] ?? 0);
$matiereId = (int)($_GET['matiere_id'] ?? 0);
$periodeId = (int)($_GET['periode_id'] ?? 0);
if ($matiereId <= 0 || $periodeId <= 0) {
    http_response_code(400);
    echo 'Paramètres manquants';
    exit;
}
$pst = $pdo->prepare("SELECT statut FROM periodes WHERE id = ?");
$pst->execute([$periodeId]);
$st = $pst->fetchColumn();
if ($st !== 'publiee') {
    http_response_code(403);
    echo 'Période non publiée';
    exit;
}
$stmt = $pdo->prepare("SELECT c.nom_colonne, n.valeur, n.statut FROM notes n JOIN configuration_colonnes c ON c.id = n.colonne_id WHERE n.etudiant_id = ? AND c.matiere_id = ? AND c.periode_id = ? ORDER BY c.ordre, c.nom_colonne");
$stmt->execute([$etudiantId, $matiereId, $periodeId]);
$rows = $stmt->fetchAll() ?: [];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Étudiant — Notes</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Notes détaillées</h2>
                </div>
            </div>
        </header>
        <main class="dashboard-main">
            <section class="subjects-section">
                <h3>Détails par colonnes</h3>
                <div class="subjects-table-container">
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Colonne</th>
                                <th>Valeur</th>
                                <th>Statut</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rows as $r): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($r['nom_colonne']); ?></td>
                                    <td><?php echo htmlspecialchars((string)$r['valeur']); ?></td>
                                    <td><?php echo htmlspecialchars((string)$r['statut']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>
</body>
</html>
