<?php
require_once __DIR__ . '/../../app/services/auth.php';
require_etudiant();
require_once __DIR__ . '/../../app/config/database.php';
$pdo = get_pdo();
$etudiantId = (int)($_SESSION['user']['id'] ?? 0);
$periodeId = isset($_GET['periode_id']) ? (int)$_GET['periode_id'] : 0;
$action = $_GET['action'] ?? '';
if ($action === 'transcript' && $periodeId > 0) {
    $pst = $pdo->prepare("SELECT statut, nom, code, date_publication FROM periodes WHERE id = ?");
    $pst->execute([$periodeId]);
    $per = $pst->fetch();
    if (!$per || $per['statut'] !== 'publiee') {
        http_response_code(403);
        echo 'Période non publiée';
        exit;
    }
    $st = $pdo->prepare("SELECT m.nom AS matiere, y.valeur AS moyenne,
        CASE WHEN y.valeur >= m.seuil_validation THEN 'Validé' ELSE 'Non validé' END AS decision,
        CASE WHEN y.valeur >= m.seuil_validation THEN m.credits ELSE 0 END AS credits_obtenus
        FROM moyennes y JOIN matieres m ON m.id = y.matiere_id
        WHERE y.etudiant_id = ? AND y.periode_id = ? ORDER BY m.nom");
    $st->execute([$etudiantId, $periodeId]);
    $rows = $st->fetchAll() ?: [];
    $timestamp = date('c');
    $payload = [
        'etudiant_id' => $etudiantId,
        'periode_id' => $periodeId,
        'periode' => ['nom'=>$per['nom'],'code'=>$per['code'],'date_publication'=>$per['date_publication']],
        'donnees' => $rows,
        'timestamp' => $timestamp
    ];
    $hash = hash('sha256', json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    header('Content-Type: text/html; charset=utf-8');
    header('Content-Disposition: attachment; filename="releve-'.$per['code'].'-'.$etudiantId.'.html"');
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Relevé de notes</title></head><body>';
    echo '<h1>Relevé de notes — '.$per['nom'].'</h1>';
    echo '<p>Étudiant: '.htmlspecialchars($_SESSION['user']['nom'] ?? '').' • ID: '.(int)$etudiantId.'</p>';
    echo '<p>Période: '.htmlspecialchars($per['nom']).' ('.htmlspecialchars($per['code']).')</p>';
    echo '<p>Publié le: '.htmlspecialchars((string)$per['date_publication']).'</p>';
    echo '<table border="1" cellspacing="0" cellpadding="6"><thead><tr><th>Matière</th><th>Moyenne</th><th>Décision</th><th>Crédits</th></tr></thead><tbody>';
    foreach ($rows as $r) {
        echo '<tr><td>'.htmlspecialchars((string)$r['matiere']).'</td><td>'.htmlspecialchars((string)$r['moyenne']).'</td><td>'.htmlspecialchars((string)$r['decision']).'</td><td>'.htmlspecialchars((string)$r['credits_obtenus']).'</td></tr>';
    }
    echo '</tbody></table>';
    echo '<p>Horodatage: '.htmlspecialchars($timestamp).'</p>';
    echo '<p>Hash de vérification (SHA-256): '.htmlspecialchars($hash).'</p>';
    echo '</body></html>';
    exit;
}
$pubStmt = $pdo->query("SELECT id, nom, code, date_publication FROM periodes WHERE statut = 'publiee' ORDER BY date_publication DESC");
$periodes = $pubStmt->fetchAll() ?: [];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Étudiant — Documents</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Documents officiels</h2>
                </div>
            </div>
        </header>
        <main class="dashboard-main">
            <section class="subjects-section">
                <h3>Documents disponibles</h3>
                <div class="subjects-table-container">
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Période</th>
                                <th>Code</th>
                                <th>Publié</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($periodes as $p): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($p['nom']); ?></td>
                                    <td><?php echo htmlspecialchars($p['code']); ?></td>
                                    <td><?php echo htmlspecialchars($p['date_publication'] ?? ''); ?></td>
                                    <td>
                                        <a class="action-button enter-grades" href="documents.php?action=transcript&periode_id=<?php echo (int)$p['id']; ?>">Relevé de notes</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>
</body>
</html>
