<?php
require_once __DIR__ . '/../../app/services/auth.php';
require_etudiant();
require_once __DIR__ . '/../../app/config/database.php';
$pdo = get_pdo();
$etudiantId = (int)($_SESSION['user']['id'] ?? 0);
$periodeId = (int)($_GET['periode_id'] ?? 0);
if ($periodeId <= 0) {
    http_response_code(400);
    echo 'Période manquante';
    exit;
}
$pst = $pdo->prepare("SELECT statut, nom FROM periodes WHERE id = ?");
$pst->execute([$periodeId]);
$per = $pst->fetch();
if (!$per || $per['statut'] !== 'publiee') {
    http_response_code(403);
    echo 'Période non publiée';
    exit;
}
$stmt = $pdo->prepare("SELECT y.matiere_id, m.nom AS matiere, y.valeur AS moyenne,
    CASE WHEN y.valeur >= m.seuil_validation THEN 'Validé' ELSE 'Non validé' END AS decision,
    CASE WHEN y.valeur >= m.seuil_validation THEN m.credits ELSE 0 END AS credits_obtenus
    FROM moyennes y JOIN matieres m ON m.id = y.matiere_id
    WHERE y.etudiant_id = ? AND y.periode_id = ? ORDER BY m.nom");
$stmt->execute([$etudiantId, $periodeId]);
$rows = $stmt->fetchAll() ?: [];
$sum = 0;
foreach ($rows as $r) { $sum += (int)($r['credits_obtenus'] ?? 0); }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Étudiant — Moyennes</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Moyennes publiées — <?php echo htmlspecialchars($per['nom']); ?></h2>
                </div>
            </div>
        </header>
        <main class="dashboard-main">
            <section class="subjects-section">
                <h3>Par matière</h3>
                <div class="subjects-table-container">
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Matière</th>
                                <th>Moyenne</th>
                                <th>Décision</th>
                                <th>Crédits obtenus</th>
                                <th>Notes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rows as $r): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($r['matiere']); ?></td>
                                    <td><?php echo htmlspecialchars((string)$r['moyenne']); ?></td>
                                    <td><?php echo htmlspecialchars((string)$r['decision']); ?></td>
                                    <td><?php echo htmlspecialchars((string)$r['credits_obtenus']); ?></td>
                                    <td><a class="action-button enter-grades" href="notes.php?matiere_id=<?php echo (int)$r['matiere_id']; ?>&periode_id=<?php echo (int)$periodeId; ?>">Détails</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <p>Crédits totaux obtenus : <strong><?php echo (int)$sum; ?></strong></p>
                </div>
            </section>
        </main>
    </div>
</body>
</html>
