<?php
require_once __DIR__ . '/../../app/services/auth.php';
require_etudiant();
require_once __DIR__ . '/../../app/config/database.php';
$pdo = get_pdo();
$etudiantId = (int)($_SESSION['user']['id'] ?? 0);
$pubStmt = $pdo->query("SELECT id, nom, code, date_publication FROM periodes WHERE statut = 'publiee' ORDER BY date_publication DESC");
$periodes = $pubStmt->fetchAll() ?: [];
$changes = [];
try {
    $sql = "SELECT h.date_modification, c.nom_colonne, h.ancienne_valeur, h.nouvelle_valeur, h.ancien_statut, h.nouveau_statut
            FROM historique_notes h
            JOIN notes n ON n.id = h.note_id
            JOIN configuration_colonnes c ON c.id = n.colonne_id
            WHERE n.etudiant_id = ?
            ORDER BY h.date_modification DESC";
    $st = $pdo->prepare($sql);
    $st->execute([$etudiantId]);
    $changes = $st->fetchAll() ?: [];
} catch (Throwable $e) {
    $changes = null;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Étudiant — Historique personnel</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Historique personnel</h2>
                </div>
            </div>
        </header>
        <main class="dashboard-main">
            <section class="subjects-section">
                <h3>Publications officielles</h3>
                <div class="subjects-table-container">
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Période</th>
                                <th>Code</th>
                                <th>Date de publication</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($periodes as $p): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($p['nom']); ?></td>
                                    <td><?php echo htmlspecialchars($p['code']); ?></td>
                                    <td><?php echo htmlspecialchars($p['date_publication'] ?? ''); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
            <section class="subjects-section">
                <h3>Changements exceptionnels</h3>
                <?php if ($changes === null): ?>
                    <p>Historique indisponible.</p>
                <?php else: ?>
                <div class="subjects-table-container">
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Colonne</th>
                                <th>Ancienne valeur</th>
                                <th>Nouvelle valeur</th>
                                <th>Ancien statut</th>
                                <th>Nouveau statut</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($changes as $c): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars((string)$c['date_modification']); ?></td>
                                    <td><?php echo htmlspecialchars((string)$c['nom_colonne']); ?></td>
                                    <td><?php echo htmlspecialchars((string)$c['ancienne_valeur']); ?></td>
                                    <td><?php echo htmlspecialchars((string)$c['nouvelle_valeur']); ?></td>
                                    <td><?php echo htmlspecialchars((string)$c['ancien_statut']); ?></td>
                                    <td><?php echo htmlspecialchars((string)$c['nouveau_statut']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </section>
        </main>
    </div>
</body>
</html>
