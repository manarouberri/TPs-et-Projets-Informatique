<?php
require_once __DIR__ . '/../../app/services/auth.php';
require_etudiant();
require_once __DIR__ . '/../../app/config/database.php';
$pdo = get_pdo();
$etudiantId = (int)($_SESSION['user']['id'] ?? 0);
$periodesStmt = $pdo->query("SELECT id, nom, code, date_publication FROM periodes WHERE statut = 'publiee' ORDER BY date_publication DESC");
$periodes = $periodesStmt->fetchAll() ?: [];
$sumStmt = $pdo->prepare("SELECT COALESCE(SUM(CASE WHEN y.valeur >= m.seuil_validation THEN m.credits ELSE 0 END),0)
    FROM moyennes y
    JOIN matieres m ON m.id = y.matiere_id
    WHERE y.etudiant_id = ?
      AND y.periode_id IN (SELECT id FROM periodes WHERE statut = 'publiee')");
$sumStmt->execute([$etudiantId]);
$creditsTotal = (int)$sumStmt->fetchColumn();
function periode_status(PDO $pdo, int $etudiantId, int $periodeId): string {
    $st = $pdo->prepare("SELECT y.valeur, m.seuil_validation
                         FROM moyennes y JOIN matieres m ON m.id = y.matiere_id
                         WHERE y.etudiant_id = ? AND y.periode_id = ?");
    $st->execute([$etudiantId, $periodeId]);
    $rows = $st->fetchAll() ?: [];
    if (!$rows) return 'Indisponible';
    foreach ($rows as $r) {
        if ((float)$r['valeur'] < (float)$r['seuil_validation']) {
            return 'Non validé';
        }
    }
    return 'Validé';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Étudiant — Tableau de bord</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Espace Étudiant</h2>
                </div>
                <div class="user-section">
                    <div class="user-info">
                        <span class="user-name"><?php echo htmlspecialchars($_SESSION['user']['nom'] ?? 'Étudiant'); ?></span>
                        <span class="user-email"><?php echo htmlspecialchars($_SESSION['user']['email'] ?? ''); ?></span>
                    </div>
                    <form method="POST" action="../login.php" class="logout-form">
                        <button type="submit" name="logout" class="logout-button">Déconnexion</button>
                    </form>
                </div>
            </div>
        </header>
        <main class="dashboard-main">
            <section class="subjects-section">
                <h3>Périodes publiées</h3>
                <p>Crédits obtenus (publiés) : <strong><?php echo (int)$creditsTotal; ?></strong></p>
                <div class="subjects-table-container">
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Période</th>
                                <th>Code</th>
                                <th>Date de publication</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($periodes as $p): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($p['nom']); ?></td>
                                    <td><?php echo htmlspecialchars($p['code']); ?></td>
                                    <td><?php echo htmlspecialchars($p['date_publication'] ?? ''); ?></td>
                                    <td>
                                        <?php 
                                            $ps = periode_status($pdo, $etudiantId, (int)$p['id']);
                                            $cls = $ps === 'Validé' ? 'validated' : ($ps === 'Rattrapage' ? 'pending' : ($ps === 'Non validé' ? 'locked' : ''));
                                            echo '<span class="status-badge ' . htmlspecialchars($cls) . '">' . htmlspecialchars($ps) . '</span>';
                                        ?>
                                    </td>
                                    <td>
                                        <a class="action-button enter-grades" href="moyennes.php?periode_id=<?php echo (int)$p['id']; ?>">Moyennes</a>
                                        <a class="action-button enter-grades" href="documents.php?periode_id=<?php echo (int)$p['id']; ?>">Documents</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>
</body>
</html>
