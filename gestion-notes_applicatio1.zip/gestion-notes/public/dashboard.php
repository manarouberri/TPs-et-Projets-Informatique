<?php
require_once __DIR__ . '/../app/services/auth.php';
require_professor();
$professor_name = $_SESSION['user']['nom'] ?? 'Professor';
$professor_email = $_SESSION['user']['email'] ?? '';
$stmt = $pdo->query("SELECT id, nom, code, type, statut, date_debut_saisie, date_fin_saisie FROM periodes ORDER BY date_debut_saisie DESC");
$periodes = $stmt->fetchAll();
$sql = "SELECT m.id AS matiere_id, m.code, m.nom, p.id AS periode_id, p.nom AS periode_nom, p.statut AS periode_statut, COUNT(im.etudiant_id) AS nb_etudiants, ps.pourcentage, ps.valide_par_prof FROM affectations_profs ap JOIN matieres m ON m.id = ap.matiere_id JOIN periodes p ON p.id = ap.periode_id LEFT JOIN inscriptions_matieres im ON im.matiere_id = m.id AND im.periode_id = p.id LEFT JOIN progression_saisie ps ON ps.matiere_id = m.id AND ps.periode_id = p.id WHERE ap.professeur_id = ? GROUP BY m.id, p.id ORDER BY p.date_debut_saisie DESC";
$stmt2 = $pdo->prepare($sql);
$stmt2->execute([$_SESSION['user']['id'] ?? 0]);
$matieres = $stmt2->fetchAll();
if (isset($_POST['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord Professeur - Système de Gestion des Notes</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Header -->
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Portail Professeur</h2>
                </div>
                <div class="user-section">
                    <div class="user-info">
                        <span class="user-name"><?php echo htmlspecialchars($professor_name); ?></span>
                        <span class="user-email"><?php echo htmlspecialchars($professor_email); ?></span>
                    </div>
                    <form method="POST" class="logout-form">
                        <button type="submit" name="logout" class="logout-button">Déconnexion</button>
                    </form>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="dashboard-main">
            <!-- Vue des périodes académiques -->
            <section class="periods-overview">
                <h3>Périodes académiques</h3>
                <div class="periods-grid">
                    <?php foreach ($periodes as $pr): ?>
                        <div class="period-card <?php echo $pr['statut']; ?>">
                            <h4><?php echo htmlspecialchars($pr['nom']); ?></h4>
                            <p class="period-status">Statut : <?php echo htmlspecialchars($pr['statut']); ?></p>
                            <p class="period-deadline">Du : <?php echo htmlspecialchars($pr['date_debut_saisie']); ?> • Au : <?php echo htmlspecialchars($pr['date_fin_saisie']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Assigned Subjects -->
            <section class="subjects-section">
                <h3>Vos matières attribuées</h3>
                <div class="subjects-table-container">
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Code matière</th>
                                <th>Intitulé</th>
                                <th>Période</th>
                                <th>Étudiants</th>
                                <th>Progression</th>
                                <th>Statut</th>
                                <th>Échéance</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($matieres as $row): ?>
                                <?php
                                $pourcentage = (float)($row['pourcentage'] ?? 0);
                                $valide = (bool)($row['valide_par_prof'] ?? false);
                                $periode_statut = $row['periode_statut'];
                                ?>
                                <tr class="subject-row">
                                    <td class="subject-code"><?php echo htmlspecialchars($row['code']); ?></td>
                                    <td class="subject-name"><?php echo htmlspecialchars($row['nom']); ?></td>
                                    <td class="academic-period"><?php echo htmlspecialchars($row['periode_nom']); ?></td>
                                    <td class="student-count"><?php echo (int)$row['nb_etudiants']; ?></td>
                                    <td class="progress">
                                        <div class="progress-bar">
                                            <div class="progress-fill" 
                                                 style="width: <?php echo $pourcentage; ?>%">
                                            </div>
                                        </div>
                                        <span class="progress-text">
                                            <?php echo round($pourcentage); ?>%
                                        </span>
                                    </td>
                                    <td class="status">
                                        <?php if ($periode_statut === 'fermee') { ?>
                                            <span class="status-badge locked">Verrouillé</span>
                                        <?php } elseif ($valide) { ?>
                                            <span class="status-badge validated">Validé</span>
                                        <?php } else { ?>
                                            <span class="status-badge pending">En cours</span>
                                        <?php } ?>
                                    </td>
                                    <td class="deadline"></td>
                                    <td class="action">
                                        <?php if ($periode_statut === 'ouverte' && !$valide) { ?>
                                            <a href="saisie_notes.php?matiere_id=<?php echo (int)$row['matiere_id']; ?>&periode_id=<?php echo (int)$row['periode_id']; ?>" 
                                               class="action-button enter-grades">
                                                Saisir les notes
                                            </a>
                                        <?php } elseif ($valide) { ?>
                                            <span class="action-button validated" disabled>
                                                Validé
                                            </span>
                                        <?php } else { ?>
                                            <span class="action-button locked" disabled>
                                                Verrouillé
                                            </span>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <!-- Statut du système -->
            <section class="system-status">
                <h3>Statut du système</h3>
                <div class="status-info">
                    <p><strong>Statut :</strong> <span class="status-indicator online">En ligne</span></p>
                    <p><strong>Dernière mise à jour :</strong> <?php echo date('Y-m-d H:i:s'); ?></p>
                </div>
            </section>
        </main>

        <!-- Footer -->
        <footer class="dashboard-footer">
            <p>&copy; 2024 Université — Système de Gestion des Notes. Tous droits réservés.</p>
            <p>Pour l’assistance technique, contactez le service informatique</p>
        </footer>
    </div>
</body>
</html>
