<?php
/**
 * Professor Module - Main Entry Point
 * Grade Management System
 * 
 * This is the main entry point for the professor module.
 * It handles the initial routing and session management.
 */

// Start session
session_start();

// Check if user is already logged in (single auth)
if (isset($_SESSION['user']) && isset($_SESSION['user']['role'])) {
    if ($_SESSION['user']['role'] === 'admin') {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: dashboard.php');
    }
    exit();
}
header('Location: login.php');
exit();
?>
