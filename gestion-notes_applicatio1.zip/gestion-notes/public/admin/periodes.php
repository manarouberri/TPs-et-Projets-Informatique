<?php
require_once __DIR__ . '/../../app/services/auth.php';
require_admin();
require_once __DIR__ . '/../../app/config/database.php';
$pdo = get_pdo();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration — Périodes académiques</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Administration — Périodes</h2>
                </div>
                <div class="user-section">
                    <div class="user-info">
                        <span class="user-name"><?php echo htmlspecialchars($_SESSION['user']['nom'] ?? 'Administrateur'); ?></span>
                        <span class="user-email"><?php echo htmlspecialchars($_SESSION['user']['email'] ?? ''); ?></span>
                    </div>
                    <form method="POST" action="../login.php" class="logout-form">
                        <button type="submit" name="logout" class="logout-button">Déconnexion</button>
                    </form>
                </div>
            </div>
        </header>
        <main class="dashboard-main">
            <section class="subjects-section">
                <h3>Gestion des périodes académiques</h3>
                <p>Créer, modifier, ouvrir, fermer et publier les périodes de saisie.</p>
                <div class="subjects-table-container" style="margin-bottom:12px;">
                    <h4>Créer une période</h4>
                    <form id="create-periode" method="POST" action="../api/admin/periodes/create.php" style="display:flex; gap:8px; flex-wrap:wrap;">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? ''); ?>">
                        <input type="text" name="nom" placeholder="Nom" required>
                        <input type="text" name="code" placeholder="Code" required>
                        <input type="text" name="annee_universitaire" placeholder="Année" required>
                        <input type="text" name="type" placeholder="Type" required>
                        <input type="date" name="date_debut_saisie" required>
                        <input type="date" name="date_fin_saisie" required>
                        <button type="submit" class="action-button enter-grades">Créer</button>
                    </form>
                </div>
                <div class="subjects-table-container">
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Nom</th>
                                <th>Code</th>
                                <th>Statut</th>
                                <th>Du</th>
                                <th>Au</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $stmt = $pdo->query("SELECT id, nom, code, statut, date_debut_saisie, date_fin_saisie FROM periodes ORDER BY date_debut_saisie DESC");
                            foreach ($stmt->fetchAll() as $p): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($p['nom']); ?></td>
                                    <td><?php echo htmlspecialchars($p['code']); ?></td>
                                    <td>
                                        <?php 
                                            $st = $p['statut'];
                                            $label = $st === 'ouverte' ? 'Ouverte' : ($st === 'a_venir' ? 'À venir' : ($st === 'fermee' ? 'Fermée' : ($st === 'publiee' ? 'Publiée' : $st)));
                                            $cls = $st;
                                            echo '<span class="status-badge ' . htmlspecialchars($cls) . '">' . htmlspecialchars($label) . '</span>';
                                        ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($p['date_debut_saisie']); ?></td>
                                    <td><?php echo htmlspecialchars($p['date_fin_saisie']); ?></td>
                                    <td>
                                        <form method="POST" action="../api/admin/periodes/open.php" style="display:inline;">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? ''); ?>">
                                            <input type="hidden" name="periode_id" value="<?php echo (int)$p['id']; ?>">
                                            <button class="action-button validated" <?php echo $p['statut'] !== 'a_venir' ? 'disabled' : ''; ?> onclick="return confirm('Ouvrir cette période ?')">Ouvrir</button>
                                        </form>
                                        <form method="POST" action="../api/admin/periodes/close.php" style="display:inline;">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? ''); ?>">
                                            <input type="hidden" name="periode_id" value="<?php echo (int)$p['id']; ?>">
                                            <button class="action-button locked" <?php echo $p['statut'] !== 'ouverte' ? 'disabled' : ''; ?> onclick="return confirm('Fermer cette période ?')">Fermer</button>
                                        </form>
                                        <form method="POST" action="../api/admin/periodes/publish.php" style="display:inline;">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? ''); ?>">
                                            <input type="hidden" name="periode_id" value="<?php echo (int)$p['id']; ?>">
                                            <button class="action-button enter-grades" <?php echo $p['statut'] !== 'fermee' ? 'disabled' : ''; ?> onclick="return confirm('Publier les résultats de cette période ?')">Publier</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
        <script>
            (function(){
                var form = document.getElementById('create-periode');
                if (form) {
                    form.addEventListener('submit', function(e){
                        e.preventDefault();
                        var fd = new FormData(form);
                        fetch(form.action, { method:'POST', body: fd })
                            .then(function(r){ return r.json().catch(function(){ return { error:'Réponse invalide' }; }); })
                            .then(function(data){
                                if (data && data.success) {
                                    alert('Période créée');
                                    window.location.reload();
                                } else {
                                    alert((data && data.error) ? data.error : 'Erreur création');
                                }
                            })
                            .catch(function(){ alert('Erreur réseau'); });
                    });
                }
            })();
        </script>
        <footer class="dashboard-footer">
            <p>&copy; Université — Module Administrateur</p>
        </footer>
    </div>
</body>
</html>
