<?php
require_once __DIR__ . '/../../app/services/auth.php';
require_admin();
require_once __DIR__ . '/../../app/config/database.php';
$pdo = get_pdo();
$csrf = $_SESSION['csrf_token'] ?? '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration — Supervision</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Administration — Supervision</h2>
                </div>
            </div>
        </header>
        <main class="dashboard-main">
            <section class="subjects-section">
                <h3>Supervision globale</h3>
                <div class="subjects-table-container">
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Filière</th>
                                <th>Matière</th>
                                <th>Professeur</th>
                                <th>Progression</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT ps.matiere_id, ps.periode_id, m.nom AS matiere, p.nom AS prof, ps.pourcentage, ps.valide_par_prof, (SELECT COUNT(*) FROM moyennes my WHERE my.matiere_id = ps.matiere_id AND my.periode_id = ps.periode_id) AS moyennes_count FROM progression_saisie ps JOIN matieres m ON m.id = ps.matiere_id JOIN professeurs p ON p.id = ps.professeur_id ORDER BY ps.date_mise_a_jour DESC";
                            $stmt = $pdo->query($sql);
                            foreach ($stmt->fetchAll() as $row): 
                                $pourc = round((float)$row['pourcentage']);
                                $valide = (bool)$row['valide_par_prof'];
                                $hasMoyennes = ((int)($row['moyennes_count'] ?? 0) > 0);
                            ?>
                                <tr>
                                    <td>—</td>
                                    <td><?php echo htmlspecialchars($row['matiere']); ?></td>
                                    <td><?php echo htmlspecialchars($row['nom'] ?? $row['prof']); ?></td>
                                    <td>
                                        <div class="progress-bar"><div class="progress-fill" style="width: <?php echo $pourc; ?>%"></div></div>
                                        <span class="progress-text"><?php echo $pourc; ?>%</span>
                                    </td>
                                    <td>
                                        <?php if ($valide) { ?>
                                            <span class="status-badge validated">Validé</span>
                                        <?php } else { ?>
                                            <span class="status-badge pending">En cours</span>
                                        <?php } ?>
                                    </td>
                                    <td>
                                        <button class="action-button enter-grades" onclick="return confirm('Envoyer un rappel au professeur ?')">Rappel</button>
                                        <?php if ($valide) { ?>
                                            <button class="action-button enter-grades" onclick="return confirm('Déverrouillage exceptionnel (justification requise) ?')">Déverrouiller</button>
                                        <?php } else { ?>
                                            <button class="action-button locked" disabled>Déverrouiller</button>
                                            <span class="status-badge locked">En cours — modification impossible</span>
                                        <?php } ?>
                                        <form method="POST" action="../api/admin/calcul/moyennes.php" style="display:inline;">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf); ?>">
                                            <input type="hidden" name="matiere_id" value="<?php echo (int)$row['matiere_id']; ?>">
                                            <input type="hidden" name="periode_id" value="<?php echo (int)$row['periode_id']; ?>">
                                            <button type="submit" class="action-button enter-grades">Calculer les moyennes</button>
                                        </form>
                                        <?php if ($hasMoyennes) { ?>
                                            <span class="status-badge validated">Moyennes calculées</span>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div id="msgCalc" style="margin-top:10px;"></div>
            </section>
        </main>
        <script>
            (function(){
                function show(type, text) {
                    var el = document.getElementById('msgCalc');
                    if (!el) return;
                    el.textContent = text;
                    el.style.color = type === 'success' ? '#0b7' : '#b00';
                }
                function handleSubmit(e) {
                    var form = e.target;
                    if (form.method.toUpperCase() !== 'POST') return;
                    if (form.action.indexOf('/api/admin/calcul/moyennes.php') === -1) return;
                    e.preventDefault();
                    var fd = new FormData(form);
                    fetch(form.action, { method:'POST', body: fd })
                        .then(function(r){ return r.json().catch(function(){ return { error:'Réponse invalide' }; }); })
                        .then(function(data){
                            if (data && data.success) {
                                var n = (data.count !== undefined) ? data.count : 0;
                                show('success','Calcul effectué: ' + n + ' moyennes');
                            } else {
                                var msg = (data && data.error) ? data.error : 'Erreur';
                                show('error', msg);
                            }
                        })
                        .catch(function(){ show('error', 'Erreur réseau'); });
                }
                var forms = document.querySelectorAll('form');
                forms.forEach(function(f){
                    f.addEventListener('submit', handleSubmit);
                });
            })();
        </script>
    </div>
</body>
</html>
