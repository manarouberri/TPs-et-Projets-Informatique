<?php
require_once __DIR__ . '/../../app/services/auth.php';
require_admin();
require_once __DIR__ . '/../../app/config/database.php';
$pdo = get_pdo();

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $professeurId = (int)($_POST['professeur_id'] ?? 0);
    $matiereId = (int)($_POST['matiere_id'] ?? 0);
    $periodeId = (int)($_POST['periode_id'] ?? 0);
    $groupe = trim($_POST['groupe'] ?? '');
    $csrf = $_POST['csrf_token'] ?? '';

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $csrf)) {
        $error = 'CSRF invalide.';
    } elseif ($professeurId <= 0 || $matiereId <= 0 || $periodeId <= 0) {
        $error = 'Tous les champs sont obligatoires.';
    } else {
        try {
            $stmt = $pdo->prepare(
                "INSERT INTO affectations_profs (professeur_id, matiere_id, periode_id, groupe) 
                 VALUES (?, ?, ?, ?)"
            );
            $stmt->execute([$professeurId, $matiereId, $periodeId, $groupe !== '' ? $groupe : null]);
            $message = 'Affectation créée avec succès.';
        } catch (PDOException $e) {
            if ((int)$e->errorInfo[1] === 1062) {
                $error = 'Cette affectation existe déjà.';
            } else {
                $error = 'Erreur lors de la création de l’affectation.';
            }
        }
    }
}

$profsStmt = $pdo->query("SELECT id, nom, prenom FROM utilisateurs WHERE role = 'professeur' AND actif = 1 ORDER BY nom, prenom");
$professeurs = $profsStmt->fetchAll();

$matStmt = $pdo->query("SELECT id, code, nom FROM matieres ORDER BY nom");
$matieres = $matStmt->fetchAll();

$perStmt = $pdo->query("SELECT id, nom, code FROM periodes ORDER BY date_debut_saisie DESC");
$periodes = $perStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration — Affectations</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Administration — Affectations</h2>
                </div>
            </div>
        </header>
        <main class="dashboard-main">
            <section class="subjects-section">
                <h3>Affecter un professeur</h3>
                <div class="subjects-table-container" style="margin-bottom:12px;">
                    <h4>Créer un profil professeur</h4>
                    <?php if ($message): ?>
                        <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
                    <?php endif; ?>
                    <?php if ($error): ?>
                        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>
                    <form id="create-prof" method="POST" action="../api/admin/professeurs/create.php" style="display:flex; gap:8px; flex-wrap:wrap;">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? ''); ?>">
                        <input type="text" name="nom" placeholder="Nom" required>
                        <input type="text" name="prenom" placeholder="Prénom">
                        <input type="email" name="email" placeholder="Email" required>
                        <input type="password" name="password" placeholder="Mot de passe initial" required>
                        <button type="submit" class="action-button enter-grades">Créer le professeur</button>
                    </form>
                </div>
                <?php if ($message): ?>
                    <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                <form class="assignment-form" method="POST" action="affectations.php" onsubmit="return confirm('Créer l’affectation ?');">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? ''); ?>">
                    <select name="professeur_id" required>
                        <option value="">Professeur</option>
                        <?php foreach ($professeurs as $p): ?>
                            <option value="<?php echo (int)$p['id']; ?>">
                                <?php echo htmlspecialchars(trim($p['nom'] . ' ' . $p['prenom'])); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <select name="matiere_id" required>
                        <option value="">Matière</option>
                        <?php foreach ($matieres as $m): ?>
                            <option value="<?php echo (int)$m['id']; ?>">
                                <?php echo htmlspecialchars($m['code'] . ' — ' . $m['nom']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <select name="periode_id" required>
                        <option value="">Période</option>
                        <?php foreach ($periodes as $pr): ?>
                            <option value="<?php echo (int)$pr['id']; ?>">
                                <?php echo htmlspecialchars($pr['nom'] . ' (' . $pr['code'] . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" name="groupe" placeholder="Groupe">
                    <button type="submit" class="action-button enter-grades">Affecter</button>
                </form>
                <div class="subjects-table-container">
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Professeur</th>
                                <th>Matière</th>
                                <th>Période</th>
                                <th>Groupe</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT u.nom AS prof_nom, u.prenom AS prof_prenom, m.nom AS matiere, pr.nom AS periode, ap.groupe 
                                    FROM affectations_profs ap 
                                    JOIN utilisateurs u ON u.id = ap.professeur_id 
                                    JOIN matieres m ON m.id = ap.matiere_id 
                                    JOIN periodes pr ON pr.id = ap.periode_id 
                                    ORDER BY pr.date_debut_saisie DESC, u.nom";
                            $stmt = $pdo->query($sql);
                            foreach ($stmt->fetchAll() as $row): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars(trim($row['prof_nom'] . ' ' . $row['prof_prenom'])); ?></td>
                                    <td><?php echo htmlspecialchars($row['matiere']); ?></td>
                                    <td><?php echo htmlspecialchars($row['periode']); ?></td>
                                    <td><?php echo htmlspecialchars($row['groupe']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
        <script>
            (function(){
                var form = document.getElementById('create-prof');
                if (form) {
                    form.addEventListener('submit', function(e){
                        e.preventDefault();
                        var fd = new FormData(form);
                        fetch(form.action, { method:'POST', body: fd })
                            .then(function(r){ return r.json().catch(function(){ return { error:'Réponse invalide' }; }); })
                            .then(function(data){
                                if (data && data.success) {
                                    alert('Professeur créé avec succès');
                                    window.location.reload();
                                } else {
                                    alert((data && data.error) ? data.error : 'Erreur création');
                                }
                            })
                            .catch(function(){ alert('Erreur réseau'); });
                    });
                }
            })();
        </script>
    </div>
</body>
</html>
