<?php
require_once __DIR__ . '/../../app/services/auth.php';
require_admin();
require_once __DIR__ . '/../../app/config/database.php';
$pdo = get_pdo();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration — Matières</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Administration — Matières</h2>
                </div>
            </div>
        </header>
        <main class="dashboard-main">
            <section class="subjects-section">
                <h3>Gestion des matières</h3>
                <div class="subjects-table-container" style="margin-bottom:12px;">
                    <h4>Ajouter une matière</h4>
                    <?php
                        $filieres = $pdo->query("SELECT id, code, nom FROM filieres ORDER BY nom")->fetchAll();
                    ?>
                    <form id="create-matiere" method="POST" action="../api/admin/matieres/create.php" style="display:flex; gap:8px; flex-wrap:wrap;">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? ''); ?>">
                        <input type="text" name="code" placeholder="Code" required>
                        <input type="text" name="nom" placeholder="Intitulé" required>
                        <select name="filiere_id" required>
                            <option value="">Filière</option>
                            <?php foreach ($filieres as $f): ?>
                                <option value="<?php echo (int)$f['id']; ?>"><?php echo htmlspecialchars($f['code'].' — '.$f['nom']); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="number" step="0.1" min="0.1" name="coefficient" placeholder="Coefficient" value="1.0">
                        <input type="number" min="0" name="credits" placeholder="Crédits">
                        <input type="number" step="0.1" min="0" name="seuil_validation" placeholder="Seuil" value="10.0">
                        <button type="submit" class="action-button enter-grades">Créer</button>
                    </form>
                </div>
                <div class="subjects-table-container">
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Intitulé</th>
                                <th>Coefficient</th>
                                <th>Crédits</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $stmt = $pdo->query("SELECT id, code, nom, coefficient, credits, seuil_validation FROM matieres ORDER BY nom");
                            foreach ($stmt->fetchAll() as $m): ?>
                                <tr data-id="<?php echo (int)$m['id']; ?>">
                                    <td><span class="view"><?php echo htmlspecialchars($m['code']); ?></span></td>
                                    <td>
                                        <span class="view"><?php echo htmlspecialchars($m['nom']); ?></span>
                                        <input class="edit" type="text" value="<?php echo htmlspecialchars($m['nom']); ?>" style="display:none;">
                                    </td>
                                    <td>
                                        <span class="view"><?php echo htmlspecialchars($m['coefficient']); ?></span>
                                        <input class="edit" type="number" step="0.1" min="0" value="<?php echo htmlspecialchars($m['coefficient']); ?>" style="display:none;">
                                    </td>
                                    <td>
                                        <span class="view"><?php echo htmlspecialchars($m['credits'] ?? ''); ?></span>
                                        <input class="edit" type="number" min="0" value="<?php echo htmlspecialchars($m['credits'] ?? ''); ?>" style="display:none;">
                                    </td>
                                    <td>
                                        <button class="action-button enter-grades btn-edit">Modifier</button>
                                        <button class="action-button enter-grades btn-save" style="display:none;">Enregistrer</button>
                                        <button class="action-button locked btn-cancel" style="display:none;">Annuler</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
        <script>
            (function(){
                var form = document.getElementById('create-matiere');
                if (form) {
                    form.addEventListener('submit', function(e){
                        e.preventDefault();
                        var fd = new FormData(form);
                        fetch(form.action, { method:'POST', body: fd })
                            .then(function(r){ return r.json().catch(function(){ return { error:'Réponse invalide' }; }); })
                            .then(function(data){
                                if (data && data.success) {
                                    alert('Matière créée');
                                    window.location.reload();
                                } else {
                                    alert((data && data.error) ? data.error : 'Erreur création');
                                }
                            })
                            .catch(function(){ alert('Erreur réseau'); });
                    });
                }
                document.querySelectorAll('.btn-edit').forEach(function(btn){
                    btn.addEventListener('click', function(){
                        var tr = this.closest('tr');
                        tr.querySelectorAll('.view').forEach(function(el){ el.style.display = 'none'; });
                        tr.querySelectorAll('.edit').forEach(function(el){ el.style.display = ''; });
                        tr.querySelector('.btn-edit').style.display = 'none';
                        tr.querySelector('.btn-save').style.display = '';
                        tr.querySelector('.btn-cancel').style.display = '';
                    });
                });
                document.querySelectorAll('.btn-cancel').forEach(function(btn){
                    btn.addEventListener('click', function(){
                        var tr = this.closest('tr');
                        tr.querySelectorAll('.view').forEach(function(el){ el.style.display = ''; });
                        tr.querySelectorAll('.edit').forEach(function(el){ el.style.display = 'none'; });
                        tr.querySelector('.btn-edit').style.display = '';
                        tr.querySelector('.btn-save').style.display = 'none';
                        tr.querySelector('.btn-cancel').style.display = 'none';
                    });
                });
                document.querySelectorAll('.btn-save').forEach(function(btn){
                    btn.addEventListener('click', function(){
                        var tr = this.closest('tr');
                        var id = tr.getAttribute('data-id');
                        var inputs = tr.querySelectorAll('input.edit');
                        var nom = inputs[0].value.trim();
                        var coefficient = inputs[1].value !== '' ? inputs[1].value : '';
                        var credits = inputs[2].value !== '' ? inputs[2].value : '';
                        var fd = new FormData();
                        fd.append('csrf_token', '<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? ''); ?>');
                        fd.append('id', id);
                        fd.append('nom', nom);
                        fd.append('coefficient', coefficient);
                        fd.append('credits', credits);
                        fetch('../api/admin/matieres/update.php', { method:'POST', body: fd })
                            .then(function(r){ return r.json().catch(function(){ return { error:'Réponse invalide' }; }); })
                            .then(function(data){
                                if (data && data.success) {
                                    alert('Matière mise à jour');
                                    window.location.reload();
                                } else {
                                    alert((data && data.error) ? data.error : 'Erreur mise à jour');
                                }
                            })
                            .catch(function(){ alert('Erreur réseau'); });
                    });
                });
            })();
        </script>
    </div>
</body>
</html>
