<?php
require_once __DIR__ . '/../../app/services/auth.php';
require_admin();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration — Système de Gestion des Notes</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Module Administrateur</h2>
                </div>
                <div class="user-section">
                    <div class="user-info">
                        <span class="user-name"><?php echo htmlspecialchars($_SESSION['user']['nom'] ?? 'Administrateur'); ?></span>
                        <span class="user-email"><?php echo htmlspecialchars($_SESSION['user']['email'] ?? ''); ?></span>
                    </div>
                    <form method="POST" action="../login.php" class="logout-form">
                        <button type="submit" name="logout" class="logout-button">Déconnexion</button>
                    </form>
                </div>
            </div>
        </header>
        <main class="dashboard-main">
            <section class="subjects-section">
                <h3>Vue d’ensemble</h3>
                <p>Configurer, contrôler et sécuriser le système de notes sans intervenir dans la saisie académique.</p>
            </section>
            <section class="subjects-section">
                <h3>Actions</h3>
                <div class="subjects-table-container">
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Fonction</th>
                                <th>Description</th>
                                <th>Accès</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Périodes académiques</td>
                                <td>Créer, ouvrir, fermer, publier</td>
                                <td><a class="action-button enter-grades" href="periodes.php">Gérer</a></td>
                            </tr>
                            <tr>
                                <td>Filières & matières</td>
                                <td>Organiser par filière et niveau</td>
                                <td><a class="action-button enter-grades" href="filieres.php">Gérer</a></td>
                            </tr>
                            <tr>
                                <td>Affectations</td>
                                <td>Associer professeurs aux matières</td>
                                <td><a class="action-button enter-grades" href="affectations.php">Gérer</a></td>
                            </tr>
                            <tr>
                                <td>Colonnes d’évaluation</td>
                                <td>Définir structure : Quiz, TP, Examens</td>
                                <td><a class="action-button enter-grades" href="colonnes.php">Gérer</a></td>
                            </tr>
                            <tr>
                                <td>Formules</td>
                                <td>Définir calculs d’agrégation (sans eval)</td>
                                <td><a class="action-button enter-grades" href="formules.php">Gérer</a></td>
                            </tr>
                            <tr>
                                <td>Supervision</td>
                                <td>Suivre la progression de saisie</td>
                                <td><a class="action-button enter-grades" href="supervision.php">Consulter</a></td>
                            </tr>
                            <tr>
                                <td>Publication</td>
                                <td>Publier les résultats</td>
                                <td><a class="action-button enter-grades" href="publication.php">Publier</a></td>
                            </tr>
                            <tr>
                                <td>Déverrouillage exceptionnel</td>
                                <td>Autoriser une modification post-validation avec justification</td>
                                <td><a class="action-button enter-grades" href="periodes.php#unlock">Déverrouiller</a></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
        <footer class="dashboard-footer">
            <p>&copy; Université — Module Administrateur</p>
        </footer>
    </div>
</body>
</html>
