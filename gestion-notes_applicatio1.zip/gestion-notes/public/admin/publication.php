<?php
require_once __DIR__ . '/../../app/services/auth.php';
require_admin();
require_once __DIR__ . '/../../app/config/database.php';
$pdo = get_pdo();

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf_token'];

$sql = "SELECT pr.id, pr.nom, pr.date_debut_saisie, pr.date_fin_saisie, pr.statut,
               COUNT(ap.id) AS total_assign,
               SUM(CASE WHEN ps.valide_par_prof = 1 THEN 1 ELSE 0 END) AS valides
        FROM periodes pr
        LEFT JOIN affectations_profs ap ON ap.periode_id = pr.id
        LEFT JOIN progression_saisie ps 
               ON ps.matiere_id = ap.matiere_id AND ps.professeur_id = ap.professeur_id
        GROUP BY pr.id, pr.nom, pr.date_debut_saisie, pr.date_fin_saisie, pr.statut
        ORDER BY pr.date_debut_saisie DESC";
$stmt = $pdo->query($sql);
$periodes = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration — Publication</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Administration — Publication des résultats</h2>
                </div>
            </div>
        </header>
        <main class="dashboard-main">
            <section class="subjects-section">
                <h3>Périodes prêtes à publier</h3>
                <p>La publication rend le système en lecture seule pour tous les utilisateurs.</p>
                <div class="subjects-table-container">
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Période</th>
                                <th>Fenêtre</th>
                                <th>Matières affectées</th>
                                <th>Validées</th>
                                <th>État</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($periodes as $p): 
                                $total = (int)($p['total_assign'] ?? 0);
                                $valides = (int)($p['valides'] ?? 0);
                                $statut = $p['statut'] ?? '';
                                $ready = ($total > 0 && $valides === $total && $statut === 'fermee');
                                $isPublished = ($statut === 'publiee' || $statut === 'publiée');
                                $etatLabel = $isPublished ? 'Publiée' : ($ready ? 'Prête à publier' : 'Non prête');
                                $window = '';
                                if (!empty($p['date_debut_saisie']) || !empty($p['date_fin_saisie'])) {
                                    $deb = $p['date_debut_saisie'] ? date('d/m/Y', strtotime($p['date_debut_saisie'])) : '';
                                    $fin = $p['date_fin_saisie'] ? date('d/m/Y', strtotime($p['date_fin_saisie'])) : '';
                                    $window = trim($deb . ' — ' . $fin, ' —');
                                }
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($p['nom']); ?></td>
                                <td><?php echo htmlspecialchars($window ?: 'N/D'); ?></td>
                                <td><?php echo htmlspecialchars($total); ?></td>
                                <td><?php echo htmlspecialchars($valides); ?></td>
                                <td>
                                    <span class="status-badge <?php echo $ready ? 'validated' : ($isPublished ? 'locked' : 'pending'); ?>">
                                        <?php echo $etatLabel; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($ready && !$isPublished): ?>
                                        <form method="POST" action="api/admin/publish.php" onsubmit="return confirm('Confirmer la publication ? Cette action rendra le système en lecture seule et ne pourra pas être annulée.');">
                                            <input type="hidden" name="csrf_token" value="<?php echo $csrf; ?>">
                                            <input type="hidden" name="periode_id" value="<?php echo (int)$p['id']; ?>">
                                            <button type="submit" class="action-button validated">Publier</button>
                                        </form>
                                    <?php else: ?>
                                        <button class="action-button locked" disabled>Publier</button>
                                        <?php if ($isPublished): ?>
                                            <span class="status-badge locked">Publiée — lecture seule</span>
                                        <?php else: ?>
                                            <span class="status-badge locked">Non prête — publication impossible</span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
            <section class="subjects-section">
                <h3>Confirmation forte</h3>
                <p>Avant de publier, vérifiez que toutes les matières sont validées. La publication fige les données et déclenche le mode lecture seule global.</p>
            </section>
        </main>
        <footer class="dashboard-footer">
            <p>&copy; Université — Module Administrateur</p>
        </footer>
    </div>
</body>
</html>
