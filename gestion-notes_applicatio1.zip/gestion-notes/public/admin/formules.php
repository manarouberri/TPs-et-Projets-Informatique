<?php
require_once __DIR__ . '/../../app/services/auth.php';
require_admin();
require_once __DIR__ . '/../../app/config/database.php';
$pdo = get_pdo();
$csrf = $_SESSION['csrf_token'] ?? '';
$matiereId = isset($_GET['matiere_id']) ? (int)$_GET['matiere_id'] : 0;
$periodeId = isset($_GET['periode_id']) ? (int)$_GET['periode_id'] : 0;
$matieres = $pdo->query("SELECT id, code, nom FROM matieres ORDER BY nom")->fetchAll();
$periodes = $pdo->query("SELECT id, nom, code FROM periodes ORDER BY date_debut_saisie DESC")->fetchAll();
$cols = [];
$existing = null;
if ($matiereId > 0 && $periodeId > 0) {
    $stmt = $pdo->prepare("SELECT code_colonne FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ? ORDER BY ordre");
    $stmt->execute([$matiereId, $periodeId]);
    $cols = array_map(function($r){ return $r['code_colonne']; }, $stmt->fetchAll());
    $stmt = $pdo->prepare("SELECT formule, description FROM formules WHERE matiere_id = ? AND periode_id = ?");
    $stmt->execute([$matiereId, $periodeId]);
    $existing = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration — Formules</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Administration — Formules</h2>
                </div>
            </div>
        </header>
        <main class="dashboard-main">
            <section class="subjects-section">
                <h3>Définition des formules</h3>
                <form class="selection-form" method="GET" action="formules.php" style="display:flex; gap:8px; margin-bottom:12px;">
                    <select name="matiere_id" required>
                        <option value="">Matière</option>
                        <?php foreach ($matieres as $m): ?>
                            <option value="<?php echo (int)$m['id']; ?>" <?php echo $matiereId===(int)$m['id']?'selected':''; ?>>
                                <?php echo htmlspecialchars($m['code'].' — '.$m['nom']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <select name="periode_id" required>
                        <option value="">Période</option>
                        <?php foreach ($periodes as $p): ?>
                            <option value="<?php echo (int)$p['id']; ?>" <?php echo $periodeId===(int)$p['id']?'selected':''; ?>>
                                <?php echo htmlspecialchars($p['nom'].' ('.$p['code'].')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="action-button enter-grades">Afficher</button>
                </form>
                <?php if ($matiereId > 0 && $periodeId > 0): ?>
                    <div id="msg" style="margin-bottom:10px;"></div>
                    <div class="editor">
                        <form id="formula-form" style="display:flex; flex-direction:column; gap:8px;">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf); ?>">
                            <input type="hidden" name="matiere_id" value="<?php echo (int)$matiereId; ?>">
                            <input type="hidden" name="periode_id" value="<?php echo (int)$periodeId; ?>">
                            <textarea name="formule" rows="8" style="width:100%" placeholder="Saisir la formule (langage sécurisé)"><?php echo htmlspecialchars($existing['formule'] ?? ''); ?></textarea>
                            <input type="text" name="description" placeholder="Description" value="<?php echo htmlspecialchars($existing['description'] ?? ''); ?>">
                            <div class="actions" style="display:flex; gap:8px;">
                                <button type="button" id="btn-test" class="action-button enter-grades">Tester la formule</button>
                                <button type="button" id="btn-save" class="action-button validated">Valider</button>
                                <button type="button" id="btn-calc" class="action-button enter-grades">Calculer les moyennes</button>
                            </div>
                        </form>
                    </div>
                    <div class="subjects-table-container">
                        <table class="subjects-table">
                            <thead>
                                <tr>
                                    <th>Colonnes disponibles</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td><?php echo htmlspecialchars(implode(', ', $cols)); ?></td></tr>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="subjects-table-container">
                        <table class="subjects-table"><tbody><tr><td>Sélectionnez matière et période.</td></tr></tbody></table>
                    </div>
                <?php endif; ?>
            </section>
        </main>
        <?php if ($matiereId > 0 && $periodeId > 0): ?>
        <script>
            (function(){
                function show(type, text) {
                    var el = document.getElementById('msg');
                    if (!el) return;
                    el.textContent = text;
                    el.style.color = type === 'success' ? '#0b7' : '#b00';
                }
                function post(url, form) {
                    var fd = new FormData(form);
                    return fetch(url, { method:'POST', body: fd }).then(function(r){ return r.json().catch(function(){ return { error:'Réponse invalide' }; }); });
                }
                var form = document.getElementById('formula-form');
                document.getElementById('btn-test').addEventListener('click', function(){
                    post('../api/admin/formules/test.php', form).then(function(data){
                        if (data && data.success) show('success','Formule valide');
                        else show('error', (data && data.error) ? data.error : 'Formule invalide');
                    }).catch(function(){ show('error','Erreur réseau'); });
                });
                document.getElementById('btn-save').addEventListener('click', function(){
                    post('../api/admin/formules/save.php', form).then(function(data){
                        if (data && data.success) show('success','Formule enregistrée');
                        else show('error', (data && data.error) ? data.error : 'Erreur enregistrement');
                    }).catch(function(){ show('error','Erreur réseau'); });
                });
                document.getElementById('btn-calc').addEventListener('click', function(){
                    post('../api/admin/calcul/moyennes.php', form).then(function(data){
                        if (data && data.success) {
                            var n = (data.count !== undefined) ? data.count : 0;
                            show('success','Calcul effectué: ' + n + ' moyennes');
                        } else {
                            show('error', (data && data.error) ? data.error : 'Erreur calcul');
                        }
                    }).catch(function(){ show('error','Erreur réseau'); });
                });
            })();
        </script>
        <?php endif; ?>
    </div>
</body>
</html>
