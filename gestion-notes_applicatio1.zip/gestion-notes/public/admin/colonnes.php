<?php
require_once __DIR__ . '/../../app/services/auth.php';
require_admin();
require_once __DIR__ . '/../../app/config/database.php';
$pdo = get_pdo();
$csrf = $_SESSION['csrf_token'] ?? '';
$matiereId = isset($_GET['matiere_id']) ? (int)$_GET['matiere_id'] : 0;
$periodeId = isset($_GET['periode_id']) ? (int)$_GET['periode_id'] : 0;

$matieres = $pdo->query("SELECT id, code, nom FROM matieres ORDER BY nom")->fetchAll();
$periodes = $pdo->query("SELECT id, nom, code FROM periodes ORDER BY date_debut_saisie DESC")->fetchAll();

$colonnes = [];
if ($matiereId > 0 && $periodeId > 0) {
    $stmt = $pdo->prepare("SELECT id, nom_colonne, code_colonne, type, note_max, coefficient, obligatoire, ordre FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ? ORDER BY ordre");
    $stmt->execute([$matiereId, $periodeId]);
    $colonnes = $stmt->fetchAll();
    $stp = $pdo->prepare("SELECT statut FROM periodes WHERE id = ?");
    $stp->execute([$periodeId]);
    $periodeStatut = $stp->fetchColumn();
    $stb = $pdo->prepare("SELECT COUNT(*) FROM notes WHERE colonne_id IN (SELECT id FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ?)");
    $stb->execute([$matiereId, $periodeId]);
    $blocked = ((int)$stb->fetchColumn() > 0) || ($periodeStatut === 'publiee');
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration — Colonnes de notation</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Administration — Colonnes</h2>
                </div>
            </div>
        </header>
        <main class="dashboard-main">
            <section class="subjects-section">
                <h3>Configuration des colonnes</h3>
                <form class="selection-form" method="GET" action="colonnes.php" style="display:flex; gap:8px; margin-bottom:12px;">
                    <select name="matiere_id" required>
                        <option value="">Matière</option>
                        <?php foreach ($matieres as $m): ?>
                            <option value="<?php echo (int)$m['id']; ?>" <?php echo $matiereId===(int)$m['id']?'selected':''; ?>>
                                <?php echo htmlspecialchars($m['code'].' — '.$m['nom']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <select name="periode_id" required>
                        <option value="">Période</option>
                        <?php foreach ($periodes as $p): ?>
                            <option value="<?php echo (int)$p['id']; ?>" <?php echo $periodeId===(int)$p['id']?'selected':''; ?>>
                                <?php echo htmlspecialchars($p['nom'].' ('.$p['code'].')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="action-button enter-grades">Afficher</button>
                </form>
                <?php if ($matiereId > 0 && $periodeId > 0): ?>
                    <?php if (!empty($blocked)): ?>
                        <div style="margin:8px 0;">
                            <span class="status-badge locked">En cours / Publiée — modification impossible</span>
                        </div>
                    <?php endif; ?>
                    <div class="actions" style="display:flex; gap:8px; margin-bottom:12px;">
                        <form method="POST" action="../api/admin/colonnes/create.php" style="display:flex; gap:8px; flex-wrap:wrap;">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf); ?>">
                            <input type="hidden" name="matiere_id" value="<?php echo (int)$matiereId; ?>">
                            <input type="hidden" name="periode_id" value="<?php echo (int)$periodeId; ?>">
                            <input type="text" name="nom_colonne" placeholder="Nom" required>
                            <input type="text" name="code_colonne" placeholder="Code" required>
                            <select name="type">
                                <option value="note">note</option>
                                <option value="bonus">bonus</option>
                                <option value="malus">malus</option>
                                <option value="info">info</option>
                            </select>
                            <input type="number" step="0.01" min="0.01" name="note_max" placeholder="Max" required>
                            <input type="number" step="0.1" min="0.1" name="coefficient" placeholder="Coef" required>
                            <label><input type="checkbox" name="obligatoire" value="1" checked> Obligatoire</label>
                            <input type="number" name="ordre" placeholder="Ordre" value="<?php echo count($colonnes)+1; ?>">
                            <button type="submit" class="action-button enter-grades" onclick="return confirm('Ajouter cette colonne ?')">Ajouter</button>
                        </form>
                        <form method="POST" action="../api/admin/colonnes/duplicate.php" style="display:flex; gap:8px; align-items:center;">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf); ?>">
                            <input type="hidden" name="matiere_id" value="<?php echo (int)$matiereId; ?>">
                            <label>Dupliquer depuis</label>
                            <select name="src_periode_id" required>
                                <option value="">Période source</option>
                                <?php foreach ($periodes as $p): ?>
                                    <option value="<?php echo (int)$p['id']; ?>"><?php echo htmlspecialchars($p['nom'].' ('.$p['code'].')'); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="hidden" name="dest_periode_id" value="<?php echo (int)$periodeId; ?>">
                            <button type="submit" class="action-button enter-grades" onclick="return confirm('Dupliquer la configuration depuis la période sélectionnée ?')">Dupliquer</button>
                        </form>
                    </div>
                <?php endif; ?>
                <div class="subjects-table-container">
                    <div id="msg" style="margin-bottom:10px;"></div>
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Nom</th>
                                <th>Code</th>
                                <th>Type</th>
                                <th>Note max</th>
                                <th>Coefficient</th>
                                <th>Obligatoire</th>
                                <th>Ordre</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($matiereId > 0 && $periodeId > 0): ?>
                                <?php foreach ($colonnes as $idx => $c): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($c['nom_colonne']); ?></td>
                                        <td><?php echo htmlspecialchars($c['code_colonne']); ?></td>
                                        <td><?php echo htmlspecialchars($c['type']); ?></td>
                                        <td><?php echo htmlspecialchars($c['note_max']); ?></td>
                                        <td><?php echo htmlspecialchars($c['coefficient']); ?></td>
                                        <td><?php echo $c['obligatoire'] ? 'Oui' : 'Non'; ?></td>
                                        <td>
                                            <form method="POST" action="../api/admin/colonnes/reorder.php" style="display:inline;">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf); ?>">
                                                <input type="hidden" name="matiere_id" value="<?php echo (int)$matiereId; ?>">
                                                <input type="hidden" name="periode_id" value="<?php echo (int)$periodeId; ?>">
                                                <?php
                                                $order = array_column($colonnes, 'id');
                                                if ($idx > 0) {
                                                    $swap = $order;
                                                    $tmp = $swap[$idx-1]; $swap[$idx-1] = $swap[$idx]; $swap[$idx] = $tmp;
                                                    foreach ($swap as $oid) {
                                                        echo '<input type="hidden" name="order[]" value="'.(int)$oid.'">';
                                                    }
                                                    echo '<button type="submit" class="action-button enter-grades">↑</button>';
                                                }
                                                ?>
                                            </form>
                                            <form method="POST" action="../api/admin/colonnes/reorder.php" style="display:inline;">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf); ?>">
                                                <input type="hidden" name="matiere_id" value="<?php echo (int)$matiereId; ?>">
                                                <input type="hidden" name="periode_id" value="<?php echo (int)$periodeId; ?>">
                                                <?php
                                                if ($idx < count($colonnes)-1) {
                                                    $swap = $order;
                                                    $tmp = $swap[$idx+1]; $swap[$idx+1] = $swap[$idx]; $swap[$idx] = $tmp;
                                                    foreach ($swap as $oid) {
                                                        echo '<input type="hidden" name="order[]" value="'.(int)$oid.'">';
                                                    }
                                                    echo '<button type="submit" class="action-button enter-grades">↓</button>';
                                                }
                                                ?>
                                            </form>
                                        </td>
                                        <td>
                                            <form method="POST" action="../api/admin/colonnes/update.php" style="display:flex; gap:6px; flex-wrap:wrap;" onsubmit="return confirm('Modifier cette colonne ?');">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf); ?>">
                                                <input type="hidden" name="id" value="<?php echo (int)$c['id']; ?>">
                                                <input type="text" name="nom_colonne" placeholder="Nom" value="<?php echo htmlspecialchars($c['nom_colonne']); ?>">
                                                <input type="number" step="0.01" min="0.01" name="note_max" placeholder="Max" value="<?php echo htmlspecialchars($c['note_max']); ?>">
                                                <input type="number" step="0.1" min="0.1" name="coefficient" placeholder="Coef" value="<?php echo htmlspecialchars($c['coefficient']); ?>">
                                                <select name="obligatoire">
                                                    <option value="1" <?php echo $c['obligatoire']?'selected':''; ?>>Obligatoire</option>
                                                    <option value="0" <?php echo !$c['obligatoire']?'selected':''; ?>>Optionnelle</option>
                                                </select>
                                                <button type="submit" class="action-button enter-grades">Modifier</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="8">Sélectionnez une matière et une période pour afficher les colonnes.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
        <script>
            (function(){
                function show(type, text) {
                    var el = document.getElementById('msg');
                    if (!el) return;
                    el.textContent = text;
                    el.style.color = type === 'success' ? '#0b7' : '#b00';
                }
                function handleSubmit(e) {
                    var form = e.target;
                    if (form.method.toUpperCase() !== 'POST') return;
                    e.preventDefault();
                    var fd = new FormData(form);
                    fetch(form.action, { method:'POST', body: fd })
                        .then(function(r){ return r.json().catch(function(){ return { error:'Réponse invalide' }; }); })
                        .then(function(data){
                            if (data && data.success) {
                                show('success', 'Opération réussie');
                                var qs = window.location.search;
                                setTimeout(function(){ window.location.href = window.location.pathname + qs; }, 600);
                            } else {
                                var msg = (data && data.error) ? data.error : 'Erreur';
                                show('error', msg);
                            }
                        })
                        .catch(function(){ show('error', 'Erreur réseau'); });
                }
                var forms = document.querySelectorAll('form');
                forms.forEach(function(f){
                    if (f.action.indexOf('/api/admin/colonnes/') !== -1) {
                        f.addEventListener('submit', handleSubmit);
                    }
                });
            })();
        </script>
    </div>
</body>
</html>
