<?php
require_once __DIR__ . '/../../app/services/auth.php';
require_admin();
require_once __DIR__ . '/../../app/config/database.php';
$pdo = get_pdo();
$filters = [
    'admin_id' => isset($_GET['admin_id']) ? (int)$_GET['admin_id'] : null,
    'entite' => isset($_GET['entite']) ? trim($_GET['entite']) : null,
    'periode_id' => isset($_GET['periode_id']) ? (int)$_GET['periode_id'] : null,
    'date_min' => isset($_GET['date_min']) ? trim($_GET['date_min']) : null,
    'date_max' => isset($_GET['date_max']) ? trim($_GET['date_max']) : null,
];
$where = [];
$params = [];
if ($filters['admin_id']) { $where[] = 'ha.admin_id = ?'; $params[] = $filters['admin_id']; }
if ($filters['entite']) { $where[] = 'ha.entite = ?'; $params[] = $filters['entite']; }
if ($filters['periode_id']) { $where[] = "(ha.entite = 'periode' AND ha.entite_id = ?)"; $params[] = $filters['periode_id']; }
if ($filters['date_min']) { $where[] = 'ha.date_action >= ?'; $params[] = $filters['date_min']; }
if ($filters['date_max']) { $where[] = 'ha.date_action <= ?'; $params[] = $filters['date_max']; }
$sql = "SELECT ha.id, u.nom, u.prenom, ha.action, ha.entite, ha.entite_id, ha.justification, ha.adresse_ip, ha.date_action FROM historique_admin ha JOIN utilisateurs u ON u.id = ha.admin_id";
if ($where) { $sql .= " WHERE ".implode(' AND ', $where); }
$sql .= " ORDER BY ha.date_action DESC LIMIT 200";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration — Audit</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
        .filters { display:flex; gap:8px; margin-bottom:12px; }
        .filters input, .filters select { padding:6px; }
        .subjects-table td pre { white-space:pre-wrap; max-width:480px; overflow:auto; }
    </style>
    </head>
<body>
    <div class="dashboard-container">
        
        <header class="dashboard-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>Système de Gestion des Notes</h1>
                    <h2>Administration — Audit</h2>
                </div>
            </div>
        </header>
        <main class="dashboard-main">
            <section class="subjects-section">
                <h3>Historique des actions administrateur</h3>
                <form class="filters" method="GET" action="audit.php">
                    <input type="number" name="admin_id" placeholder="Admin ID" value="<?php echo htmlspecialchars($filters['admin_id'] ?? ''); ?>">
                    <select name="entite">
                        <option value="">Entité</option>
                        <?php foreach (['periode','filiere','matiere','colonne','colonne_set','formule','affectation'] as $e): ?>
                            <option value="<?php echo $e; ?>" <?php echo ($filters['entite']===$e?'selected':''); ?>><?php echo ucfirst($e); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="number" name="periode_id" placeholder="ID période" value="<?php echo htmlspecialchars($filters['periode_id'] ?? ''); ?>">
                    <input type="datetime-local" name="date_min" value="<?php echo htmlspecialchars($filters['date_min'] ?? ''); ?>">
                    <input type="datetime-local" name="date_max" value="<?php echo htmlspecialchars($filters['date_max'] ?? ''); ?>">
                    <button type="submit" class="action-button enter-grades">Filtrer</button>
                </form>
                <div class="subjects-table-container">
                    <table class="subjects-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Admin</th>
                                <th>Action</th>
                                <th>Entité</th>
                                <th>Entité ID</th>
                                <th>Justification</th>
                                <th>IP</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rows as $r): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($r['date_action']); ?></td>
                                    <td><?php echo htmlspecialchars(trim($r['nom'].' '.$r['prenom'])); ?></td>
                                    <td><?php echo htmlspecialchars($r['action']); ?></td>
                                    <td><?php echo htmlspecialchars($r['entite']); ?></td>
                                    <td><?php echo htmlspecialchars((string)$r['entite_id']); ?></td>
                                    <td><?php echo htmlspecialchars((string)$r['justification']); ?></td>
                                    <td><?php echo htmlspecialchars((string)$r['adresse_ip']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>
</body>
</html>
