<?php
require_once __DIR__ . '/../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../app/config/database.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$periodeId = (int)($_POST['periode_id'] ?? 0);
if ($periodeId <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Identifiant période manquant']);
    exit;
}
require_once __DIR__ . '/admin/periodes/publish.php';
