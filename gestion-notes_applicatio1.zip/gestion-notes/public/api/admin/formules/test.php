<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
require_once __DIR__ . '/../../../../app/services/FormulaParser.php';
$pdo = get_pdo();
$matiereId = (int)($_GET['matiere_id'] ?? 0);
$periodeId = (int)($_GET['periode_id'] ?? 0);
$formule = trim($_GET['formule'] ?? '');
if ($matiereId <= 0 || $periodeId <= 0 || $formule === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Paramètres manquants']);
    exit;
}
$stmt = $pdo->prepare("SELECT code_colonne FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ?");
$stmt->execute([$matiereId, $periodeId]);
$codes = array_map(function($r){ return $r['code_colonne']; }, $stmt->fetchAll());
$allowedFuncs = ['MAX','MIN','MOYENNE','SI','ABS'];
$s = $formule;
$par = 0;
for ($i = 0; $i < strlen($s); $i++) {
    $ch = $s[$i];
    if (!(ctype_alnum($ch) || strpos('+-*/().,_ ', $ch) !== false)) {
        http_response_code(400);
        echo json_encode(['error' => 'Caractère invalide']);
        exit;
    }
    if ($ch === '(') $par++;
    if ($ch === ')') { $par--; if ($par < 0) { http_response_code(400); echo json_encode(['error'=>'Parenthèses invalides']); exit; } }
}
if ($par !== 0) { http_response_code(400); echo json_encode(['error'=>'Parenthèses non équilibrées']); exit; }
$tokens = preg_split('/([^A-Za-z0-9_]+)/', $s, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
$idents = [];
$unknown = [];
for ($i = 0; $i < count($tokens); $i++) {
    $t = $tokens[$i];
    if (preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $t)) {
        if (in_array(strtoupper($t), $allowedFuncs, true)) {
            $next = $tokens[$i+1] ?? '';
            if ($next !== '(') { http_response_code(400); echo json_encode(['error'=>'Fonction sans parenthèses']); exit; }
            continue;
        }
        if (!is_numeric($t)) {
            if (!in_array($t, $codes, true)) { $unknown[] = $t; } else { $idents[] = $t; }
        }
    } else {
        if ($t === ',' || $t === '(' || $t === ')' || $t === '+' || $t === '-' || $t === '*' || $t === '/' || trim($t) === '') { }
        else { http_response_code(400); echo json_encode(['error'=>'Jeton invalide']); exit; }
    }
}
if ($unknown) { http_response_code(400); echo json_encode(['error'=>'Références inconnues', 'details'=>$unknown]); exit; }
try {
    $parser = new FormulaParser();
    if (!$parser->validerFormule($formule)) { http_response_code(400); echo json_encode(['error'=>'Formule invalide']); exit; }
    $parser->evaluer($formule, []);
    echo json_encode(['success'=>true]);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['error'=>'Formule invalide']);
}
