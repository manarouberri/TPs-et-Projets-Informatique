<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
require_once __DIR__ . '/../../../../app/services/FormulaParser.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$matiereId = (int)($_POST['matiere_id'] ?? 0);
$periodeId = (int)($_POST['periode_id'] ?? 0);
$formule = trim($_POST['formule'] ?? '');
$description = isset($_POST['description']) ? trim($_POST['description']) : null;
if ($matiereId <= 0 || $periodeId <= 0 || $formule === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Champs requis manquants']);
    exit;
}
$stmt = $pdo->prepare("SELECT code_colonne FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ?");
$stmt->execute([$matiereId, $periodeId]);
$codes = array_map(function($r){ return $r['code_colonne']; }, $stmt->fetchAll());
$allowedFuncs = ['MAX','MIN','MOYENNE','SI','ABS'];
$s = $formule;
$par = 0;
for ($i = 0; $i < strlen($s); $i++) {
    $ch = $s[$i];
    if (!(ctype_alnum($ch) || strpos('+-*/().,_ ', $ch) !== false)) {
        http_response_code(400);
        echo json_encode(['error' => 'Caractère invalide']);
        exit;
    }
    if ($ch === '(') $par++;
    if ($ch === ')') { $par--; if ($par < 0) { http_response_code(400); echo json_encode(['error'=>'Parenthèses invalides']); exit; } }
}
if ($par !== 0) { http_response_code(400); echo json_encode(['error'=>'Parenthèses non équilibrées']); exit; }
$tokens = preg_split('/([^A-Za-z0-9_]+)/', $s, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
for ($i = 0; $i < count($tokens); $i++) {
    $t = $tokens[$i];
    if (preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $t)) {
        if (in_array(strtoupper($t), $allowedFuncs, true)) {
            $next = $tokens[$i+1] ?? '';
            if ($next !== '(') { http_response_code(400); echo json_encode(['error'=>'Fonction sans parenthèses']); exit; }
            continue;
        }
        if (!is_numeric($t)) {
            if (!in_array($t, $codes, true)) {
                http_response_code(400);
                echo json_encode(['error' => 'Référence inconnue: '.$t]);
                exit;
            }
        }
    } else {
        if ($t === ',' || $t === '(' || $t === ')' || $t === '+' || $t === '-' || $t === '*' || $t === '/' || trim($t) === '') { }
        else { http_response_code(400); echo json_encode(['error'=>'Jeton invalide']); exit; }
    }
}
$parser = new FormulaParser();
if (!$parser->validerFormule($formule)) {
    http_response_code(400);
    echo json_encode(['error' => 'Formule invalide']);
    exit;
}
$placeholders = [];
foreach ($codes as $c) { $placeholders[$c] = 0.0; }
try {
    $parser->evaluer($formule, $placeholders);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['error' => 'Formule non évaluable']);
    exit;
}
$stmt = $pdo->prepare("INSERT INTO formules (matiere_id, periode_id, formule, description) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE formule = VALUES(formule), description = VALUES(description), date_modification = CURRENT_TIMESTAMP");
$stmt->execute([$matiereId, $periodeId, $formule, $description]);
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$pre = $pdo->prepare("SELECT id, formule, description FROM formules WHERE matiere_id = ? AND periode_id = ?");
$pre->execute([$matiereId, $periodeId]);
$row = $pre->fetch();
$ancienne = json_encode(['formule'=>$row['formule'], 'description'=>$row['description']]);
$nouvelle = json_encode(['formule'=>$formule, 'description'=>$description]);
$log = $pdo->prepare("INSERT INTO historique_admin (admin_id, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, justification, adresse_ip) VALUES (?, 'CONFIG_FORMULE', 'formule', ?, ?, ?, NULL, ?)");
$log->execute([$_SESSION['user']['id'], (int)$row['id'], $ancienne, $nouvelle, $ip]);
echo json_encode(['success' => true]);
