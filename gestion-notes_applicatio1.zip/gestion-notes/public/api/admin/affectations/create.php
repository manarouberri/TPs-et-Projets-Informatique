<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$prof = (int)($_POST['professeur_id'] ?? 0);
$matiere = (int)($_POST['matiere_id'] ?? 0);
$periode = (int)($_POST['periode_id'] ?? 0);
$groupe = trim($_POST['groupe'] ?? '');
if ($prof <= 0 || $matiere <= 0 || $periode <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Champs requis manquants']);
    exit;
}
try {
    $stmt = $pdo->prepare("INSERT INTO affectations_profs (professeur_id, matiere_id, periode_id, groupe) VALUES (?, ?, ?, ?)");
    $stmt->execute([$prof, $matiere, $periode, $groupe !== '' ? $groupe : null]);
    $id = (int)$pdo->lastInsertId();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $nouvelle = json_encode(['professeur_id'=>$prof,'matiere_id'=>$matiere,'periode_id'=>$periode,'groupe'=>$groupe !== '' ? $groupe : null]);
    $stmt = $pdo->prepare("INSERT INTO historique_admin (admin_id, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, justification, adresse_ip) VALUES (?, 'AFFECTATION_CREATE', 'affectation', ?, NULL, ?, NULL, ?)");
    $stmt->execute([$_SESSION['user']['id'], $id, $nouvelle, $ip]);
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    http_response_code(409);
    echo json_encode(['error' => 'Affectation existante']);
}
