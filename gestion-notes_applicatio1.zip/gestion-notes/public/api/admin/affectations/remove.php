<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$id = (int)($_POST['affectation_id'] ?? 0);
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Identifiant requis']);
    exit;
}
$stmt = $pdo->prepare("SELECT matiere_id, periode_id FROM affectations_profs WHERE id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch();
if (!$row) {
    http_response_code(404);
    echo json_encode(['error' => 'Affectation introuvable']);
    exit;
}
$matiereId = (int)$row['matiere_id'];
$periodeId = (int)$row['periode_id'];
$stmt = $pdo->prepare("SELECT COUNT(*) FROM notes WHERE colonne_id IN (SELECT id FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ?)");
$stmt->execute([$matiereId, $periodeId]);
$count = (int)$stmt->fetchColumn();
if ($count > 0) {
    http_response_code(409);
    echo json_encode(['error' => 'Suppression interdite : saisie commencée']);
    exit;
}
$stmt = $pdo->prepare("DELETE FROM affectations_profs WHERE id = ?");
$stmt->execute([$id]);
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$ancienne = json_encode($row);
$stmt = $pdo->prepare("INSERT INTO historique_admin (admin_id, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, justification, adresse_ip) VALUES (?, 'AFFECTATION_REMOVE', 'affectation', ?, ?, NULL, NULL, ?)");
$stmt->execute([$_SESSION['user']['id'], $id, $ancienne, $ip]);
echo json_encode(['success' => true]);
