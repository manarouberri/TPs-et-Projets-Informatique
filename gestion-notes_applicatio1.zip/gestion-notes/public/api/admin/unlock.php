<?php
require_once __DIR__ . '/../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../app/config/database.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$matiereId = (int)($_POST['matiere_id'] ?? 0);
$periodeId = (int)($_POST['periode_id'] ?? 0);
$justification = trim($_POST['justification'] ?? '');
if ($matiereId <= 0 || $periodeId <= 0 || $justification === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Paramètres manquants']);
    exit;
}
$pdo->beginTransaction();
try {
    $pre = $pdo->prepare("SELECT statut FROM periodes WHERE id = ?");
    $pre->execute([$periodeId]);
    $old = $pre->fetchColumn();
    $stmt = $pdo->prepare("UPDATE progression_saisie SET valide_par_prof = 0, date_validation = NULL WHERE matiere_id = ? AND periode_id = ?");
    $stmt->execute([$matiereId, $periodeId]);
    $stmt = $pdo->prepare("UPDATE periodes SET statut = 'ouverte' WHERE id = ?");
    $stmt->execute([$periodeId]);
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $ancienne = $old;
    $nouvelle = 'ouverte';
    $stmt = $pdo->prepare("INSERT INTO historique_admin (admin_id, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, justification, adresse_ip) VALUES (?, 'UNLOCK_PERIODE', 'periode', ?, ?, ?, ?, ?)");
    $stmt->execute([$_SESSION['user']['id'], $periodeId, $ancienne, $nouvelle, $justification, $ip]);
    $pdo->commit();
    echo json_encode(['success' => true]);
} catch (Throwable $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Erreur déverrouillage']);
}
