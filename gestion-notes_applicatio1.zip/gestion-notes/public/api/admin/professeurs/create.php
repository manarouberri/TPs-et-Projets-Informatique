<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$nom = trim($_POST['nom'] ?? '');
$prenom = trim($_POST['prenom'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
if ($nom === '' || $email === '' || $password === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Nom, email et mot de passe requis']);
    exit;
}
try {
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("SELECT id FROM utilisateurs WHERE email = ?");
    $stmt->execute([$email]);
    $exists = $stmt->fetch();
    if ($exists) {
        throw new Exception('Email déjà utilisé');
    }
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $ins = $pdo->prepare("INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role, actif) VALUES (?, ?, ?, ?, 'professeur', 1)");
    $ins->execute([$nom, $prenom, $email, $hash]);
    $userId = (int)$pdo->lastInsertId();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $nouvelle = json_encode(['utilisateur_id'=>$userId,'role'=>'professeur','email'=>$email]);
    $audit = $pdo->prepare("INSERT INTO historique_admin (admin_id, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, justification, adresse_ip) VALUES (?, 'PROFESSEUR_CREATE', 'professeur', ?, NULL, ?, NULL, ?)");
    $audit->execute([$_SESSION['user']['id'], $userId, $nouvelle, $ip]);
    $pdo->commit();
    echo json_encode(['success' => true, 'professeur_id' => $userId]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(409);
    echo json_encode(['error' => $e->getMessage()]);
}
