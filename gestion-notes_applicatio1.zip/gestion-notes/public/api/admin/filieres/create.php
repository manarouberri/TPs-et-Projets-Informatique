<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$code = trim($_POST['code'] ?? '');
$nom = trim($_POST['nom'] ?? '');
$niveau = trim($_POST['niveau'] ?? '');
$responsable_id = isset($_POST['responsable_id']) ? (int)$_POST['responsable_id'] : null;
if ($code === '' || $nom === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Code et nom requis']);
    exit;
}
try {
    $stmt = $pdo->prepare("INSERT INTO filieres (code, nom, niveau, responsable_id) VALUES (?, ?, ?, ?)");
    $stmt->execute([$code, $nom, $niveau !== '' ? $niveau : null, $responsable_id]);
    $id = (int)$pdo->lastInsertId();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $nouvelle = json_encode(['code'=>$code,'nom'=>$nom,'niveau'=>$niveau,'responsable_id'=>$responsable_id]);
    $stmt = $pdo->prepare("INSERT INTO historique_admin (admin_id, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, justification, adresse_ip) VALUES (?, 'FILIERE_CREATE', 'filiere', ?, NULL, ?, NULL, ?)");
    $stmt->execute([$_SESSION['user']['id'], $id, $nouvelle, $ip]);
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    http_response_code(409);
    echo json_encode(['error' => 'Code déjà utilisé']);
}
