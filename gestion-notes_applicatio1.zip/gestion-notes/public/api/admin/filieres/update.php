<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$id = (int)($_POST['id'] ?? 0);
$nom = trim($_POST['nom'] ?? '');
$niveau = isset($_POST['niveau']) ? trim($_POST['niveau']) : null;
if ($id <= 0 || $nom === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Champs requis manquants']);
    exit;
}
try {
    $snap = $pdo->prepare("SELECT * FROM filieres WHERE id = ?");
    $snap->execute([$id]);
    $oldRow = $snap->fetch();
    $stmt = $pdo->prepare("UPDATE filieres SET nom = ?, niveau = ? WHERE id = ?");
    $stmt->execute([$nom, ($niveau === '' ? null : $niveau), $id]);
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $ancienne = json_encode($oldRow);
    $newSnap = $pdo->prepare("SELECT * FROM filieres WHERE id = ?");
    $newSnap->execute([$id]);
    $nouvelle = json_encode($newSnap->fetch());
    $stmt = $pdo->prepare("INSERT INTO historique_admin (admin_id, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, justification, adresse_ip) VALUES (?, 'FILIERE_UPDATE', 'filiere', ?, ?, ?, NULL, ?)");
    $stmt->execute([$_SESSION['user']['id'], $id, $ancienne, $nouvelle, $ip]);
    echo json_encode(['success' => true]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur mise à jour']);
}
