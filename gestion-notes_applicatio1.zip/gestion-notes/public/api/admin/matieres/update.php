<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$id = (int)($_POST['id'] ?? 0);
$nom = trim($_POST['nom'] ?? '');
$coefficient = isset($_POST['coefficient']) ? (float)$_POST['coefficient'] : null;
$credits = isset($_POST['credits']) ? (int)$_POST['credits'] : null;
$seuil = isset($_POST['seuil_validation']) ? (float)$_POST['seuil_validation'] : null;
if ($id <= 0 || $nom === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Champs requis manquants']);
    exit;
}
try {
    $snap = $pdo->prepare("SELECT * FROM matieres WHERE id = ?");
    $snap->execute([$id]);
    $oldRow = $snap->fetch();
    $stmt = $pdo->prepare("UPDATE matieres SET nom = ?, coefficient = COALESCE(?, coefficient), credits = COALESCE(?, credits), seuil_validation = COALESCE(?, seuil_validation) WHERE id = ?");
    $stmt->execute([$nom, $coefficient, $credits, $seuil, $id]);
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $ancienne = json_encode($oldRow);
    $newSnap = $pdo->prepare("SELECT * FROM matieres WHERE id = ?");
    $newSnap->execute([$id]);
    $nouvelle = json_encode($newSnap->fetch());
    $stmt = $pdo->prepare("INSERT INTO historique_admin (admin_id, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, justification, adresse_ip) VALUES (?, 'MATIERE_UPDATE', 'matiere', ?, ?, ?, NULL, ?)");
    $stmt->execute([$_SESSION['user']['id'], $id, $ancienne, $nouvelle, $ip]);
    echo json_encode(['success' => true]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur mise à jour']);
}
