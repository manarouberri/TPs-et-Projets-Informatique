<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$code = trim($_POST['code'] ?? '');
$nom = trim($_POST['nom'] ?? '');
$filiere_id = (int)($_POST['filiere_id'] ?? 0);
$coefficient = (float)($_POST['coefficient'] ?? 1.0);
$credits = isset($_POST['credits']) ? (int)$_POST['credits'] : null;
$seuil = isset($_POST['seuil_validation']) ? (float)$_POST['seuil_validation'] : 10.0;
if ($code === '' || $nom === '' || $filiere_id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Champs requis manquants']);
    exit;
}
try {
    $stmt = $pdo->prepare("INSERT INTO matieres (code, nom, filiere_id, coefficient, credits, seuil_validation) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$code, $nom, $filiere_id, $coefficient, $credits, $seuil]);
    $id = (int)$pdo->lastInsertId();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $nouvelle = json_encode(['code'=>$code,'nom'=>$nom,'filiere_id'=>$filiere_id,'coefficient'=>$coefficient,'credits'=>$credits,'seuil_validation'=>$seuil]);
    $stmt = $pdo->prepare("INSERT INTO historique_admin (admin_id, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, justification, adresse_ip) VALUES (?, 'MATIERE_CREATE', 'matiere', ?, NULL, ?, NULL, ?)");
    $stmt->execute([$_SESSION['user']['id'], $id, $nouvelle, $ip]);
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    http_response_code(409);
    echo json_encode(['error' => 'Code déjà utilisé']);
}
