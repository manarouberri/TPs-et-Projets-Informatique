<?php
require_once __DIR__ . '/../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../app/config/database.php';
$pdo = get_pdo();
$stmt = $pdo->query("SELECT m.nom AS matiere, u.nom AS prof_nom, u.prenom AS prof_prenom, ps.pourcentage, ps.valide_par_prof, pr.date_fin_saisie FROM progression_saisie ps JOIN matieres m ON m.id = ps.matiere_id JOIN utilisateurs u ON u.id = ps.professeur_id JOIN periodes pr ON pr.id = ps.periode_id ORDER BY ps.date_mise_a_jour DESC");
$rows = $stmt->fetchAll();
$data = [];
$now = new DateTime();
foreach ($rows as $r) {
    $fin = $r['date_fin_saisie'] ? new DateTime($r['date_fin_saisie']) : null;
    $alert = false;
    if ($fin) {
        $diff = $fin->getTimestamp() - $now->getTimestamp();
        if ($diff < 3 * 24 * 3600 && !$r['valide_par_prof']) {
            $alert = true;
        }
    }
    $data[] = [
        'matiere' => $r['matiere'],
        'prof' => trim($r['prof_nom'].' '.$r['prof_prenom']),
        'pourcentage' => (float)$r['pourcentage'],
        'valide' => (bool)$r['valide_par_prof'],
        'alert' => $alert
    ];
}
echo json_encode(['success' => true, 'data' => $data]);
