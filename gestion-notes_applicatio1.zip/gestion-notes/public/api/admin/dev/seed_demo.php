<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
$pdo = get_pdo();
header('Content-Type: application/json; charset=utf-8');
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
function upsert(PDO $pdo, string $sqlSelect, array $selParams, string $sqlInsert, array $insParams): array {
    $st = $pdo->prepare($sqlSelect);
    $st->execute($selParams);
    $row = $st->fetch();
    if ($row) return ['id' => (int)$row['id'], 'created' => false];
    $ins = $pdo->prepare($sqlInsert);
    $ins->execute($insParams);
    return ['id' => (int)$pdo->lastInsertId(), 'created' => true];
}
try {
    $pdo->beginTransaction();
    // 1) Filière
    $filiere = upsert(
        $pdo,
        "SELECT id FROM filieres WHERE code = ?",
        ['CS'],
        "INSERT INTO filieres (code, nom, niveau) VALUES (?, ?, ?)",
        ['CS', 'Computer Science', 'Licence']
    );
    $filiereId = $filiere['id'];
    // 2) Matières
    $alg = upsert(
        $pdo,
        "SELECT id FROM matieres WHERE code = ?",
        ['ALG'],
        "INSERT INTO matieres (code, nom, filiere_id, coefficient, credits, seuil_validation) VALUES (?, ?, ?, ?, ?, ?)",
        ['ALG', 'Algorithmics', $filiereId, 1.0, 6, 10.0]
    );
    $dbs = upsert(
        $pdo,
        "SELECT id FROM matieres WHERE code = ?",
        ['DB'],
        "INSERT INTO matieres (code, nom, filiere_id, coefficient, credits, seuil_validation) VALUES (?, ?, ?, ?, ?, ?)",
        ['DB', 'Databases', $filiereId, 1.0, 6, 10.0]
    );
    // 3) Période (publiée)
    $per = upsert(
        $pdo,
        "SELECT id FROM periodes WHERE code = ?",
        ['S1-2025'],
        "INSERT INTO periodes (nom, code, annee_universitaire, type, date_debut_saisie, date_fin_saisie, statut, date_publication) VALUES (?, ?, ?, ?, ?, ?, 'publiee', NOW())",
        ['Semestre 1', 'S1-2025', '2025-2026', 'semestre', date('Y-m-d H:i:s', strtotime('-60 days')), date('Y-m-d H:i:s', strtotime('-30 days'))]
    );
    $periodeId = $per['id'];
    // 4) Colonnes pour chaque matière
    $cols = [
        ['nom' => 'DS', 'code' => 'DS', 'ordre' => 1, 'max' => 20, 'coef' => 1],
        ['nom' => 'TP', 'code' => 'TP', 'ordre' => 2, 'max' => 20, 'coef' => 1],
        ['nom' => 'EXAM', 'code' => 'EX', 'ordre' => 3, 'max' => 20, 'coef' => 2],
    ];
    foreach ([$alg['id'], $dbs['id']] as $matId) {
        foreach ($cols as $c) {
            $sel = $pdo->prepare("SELECT id FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ? AND code_colonne = ?");
            $sel->execute([$matId, $periodeId, $c['code']]);
            if (!$sel->fetch()) {
                $ins = $pdo->prepare("INSERT INTO configuration_colonnes (matiere_id, periode_id, nom_colonne, code_colonne, type, note_max, coefficient, obligatoire, ordre) VALUES (?, ?, ?, ?, 'note', ?, ?, 1, ?)");
                $ins->execute([$matId, $periodeId, $c['nom'], $c['code'], $c['max'], $c['coef'], $c['ordre']]);
            }
        }
    }
    // 5) Professeurs (2)
    $teacherPass = password_hash('Teacher123!', PASSWORD_BCRYPT);
    $t1 = upsert(
        $pdo,
        "SELECT id FROM utilisateurs WHERE email = ?",
        ['teacher1@university.local'],
        "INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role, actif) VALUES (?, ?, ?, ?, 'professeur', 1)",
        ['Ada', 'Lovelace', 'teacher1@university.local', $teacherPass]
    );
    $t2 = upsert(
        $pdo,
        "SELECT id FROM utilisateurs WHERE email = ?",
        ['teacher2@university.local'],
        "INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role, actif) VALUES (?, ?, ?, ?, 'professeur', 1)",
        ['Edsger', 'Dijkstra', 'teacher2@university.local', $teacherPass]
    );
    // 6) Affectations
    $aff = $pdo->prepare("INSERT IGNORE INTO affectations_profs (professeur_id, matiere_id, periode_id, groupe) VALUES (?, ?, ?, NULL)");
    $aff->execute([$t1['id'], $alg['id'], $periodeId]);
    $aff->execute([$t2['id'], $dbs['id'], $periodeId]);
    // 7) Étudiants (10)
    $studentPassHash = password_hash('Student123!', PASSWORD_BCRYPT);
    $studentIds = [];
    for ($i = 1; $i <= 10; $i++) {
        $email = sprintf('student%02d@university.local', $i);
        $stu = upsert(
            $pdo,
            "SELECT id FROM utilisateurs WHERE email = ?",
            [$email],
            "INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role, actif) VALUES (?, ?, ?, ?, 'etudiant', 1)",
            ['Student', (string)$i, $email, $studentPassHash]
        );
        $studentIds[] = $stu['id'];
    }
    // 8) Inscriptions aux matières
    $enr = $pdo->prepare("INSERT IGNORE INTO inscriptions_matieres (etudiant_id, matiere_id, periode_id, groupe, dispense) VALUES (?, ?, ?, NULL, 0)");
    foreach ($studentIds as $sid) {
        $enr->execute([$sid, $alg['id'], $periodeId]);
        $enr->execute([$sid, $dbs['id'], $periodeId]);
    }
    // 9) Notes de démonstration pour student01
    $firstStudent = $studentIds[0] ?? null;
    if ($firstStudent) {
        foreach ([['mat'=>$alg['id'],'prof'=>$t1['id']], ['mat'=>$dbs['id'],'prof'=>$t2['id']]] as $pair) {
            $cfg = $pdo->prepare("SELECT id, code_colonne FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ? ORDER BY ordre");
            $cfg->execute([$pair['mat'], $periodeId]);
            $colsRows = $cfg->fetchAll();
            foreach ($colsRows as $cr) {
                $val = $cr['code_colonne'] === 'EX' ? 14.0 : 12.0;
                $insN = $pdo->prepare("INSERT IGNORE INTO notes (etudiant_id, colonne_id, valeur, statut, saisi_par) VALUES (?, ?, ?, 'saisie', ?)");
                $insN->execute([$firstStudent, (int)$cr['id'], $val, $pair['prof']]);
            }
        }
        // Moyennes simples (valeur)
        $avgAlg = 12.0 * 1 + 12.0 * 1 + 14.0 * 2;
        $avgAlg = round($avgAlg / (1 + 1 + 2), 2);
        $avgDb = $avgAlg;
        $insM = $pdo->prepare("INSERT IGNORE INTO moyennes (etudiant_id, matiere_id, periode_id, valeur) VALUES (?, ?, ?, ?)");
        $insM->execute([$firstStudent, $alg['id'], $periodeId, $avgAlg]);
        $insM->execute([$firstStudent, $dbs['id'], $periodeId, $avgDb]);
    }
    $pdo->commit();
    echo json_encode([
        'success' => true,
        'periode_code' => 'S1-2025',
        'filiere_code' => 'CS',
        'matieres' => ['ALG','DB'],
        'teachers' => ['teacher1@university.local','teacher2@university.local'],
        'students' => array_map(fn($i) => sprintf('student%02d@university.local', $i), range(1,10)),
        'test_student' => ['email' => 'student01@university.local', 'password' => 'Student123!']
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Seed échec: '.$e->getMessage()]);
}
