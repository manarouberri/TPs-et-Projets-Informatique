<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$nom = trim($_POST['nom'] ?? '');
$code = trim($_POST['code'] ?? '');
$annee = trim($_POST['annee_universitaire'] ?? '');
$type = trim($_POST['type'] ?? '');
$debut = trim($_POST['date_debut_saisie'] ?? '');
$fin = trim($_POST['date_fin_saisie'] ?? '');
if ($nom === '' || $code === '' || $annee === '' || $type === '' || $debut === '' || $fin === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Champs requis manquants']);
    exit;
}
try {
    $stmt = $pdo->prepare("INSERT INTO periodes (nom, code, annee_universitaire, type, date_debut_saisie, date_fin_saisie, statut) VALUES (?, ?, ?, ?, ?, ?, 'a_venir')");
    $stmt->execute([$nom, $code, $annee, $type, $debut, $fin]);
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    http_response_code(409);
    echo json_encode(['error' => 'Période déjà existante']);
}
