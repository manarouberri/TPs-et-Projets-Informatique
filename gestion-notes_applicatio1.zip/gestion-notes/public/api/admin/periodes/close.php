<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$periodeId = (int)($_POST['periode_id'] ?? 0);
if ($periodeId <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Identifiant période manquant']);
    exit;
}
try {
    $st0 = $pdo->prepare("SELECT statut FROM periodes WHERE id = ?");
    $st0->execute([$periodeId]);
    $old = $st0->fetchColumn();
    $stmt = $pdo->prepare("UPDATE periodes SET statut = 'fermee' WHERE id = ?");
    $stmt->execute([$periodeId]);
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $stmt = $pdo->prepare("INSERT INTO historique_admin (admin_id, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, justification, adresse_ip) VALUES (?, 'CLOSE_PERIODE', 'periode', ?, ?, 'fermee', NULL, ?)");
    $stmt->execute([$_SESSION['user']['id'], $periodeId, $old, $ip]);
    echo json_encode(['success' => true]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur fermeture']);
}
