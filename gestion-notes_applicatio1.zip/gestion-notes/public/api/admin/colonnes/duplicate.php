<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$matiereId = (int)($_POST['matiere_id'] ?? 0);
$srcPeriodeId = (int)($_POST['src_periode_id'] ?? 0);
$destPeriodeId = (int)($_POST['dest_periode_id'] ?? 0);
if ($matiereId <= 0 || $srcPeriodeId <= 0 || $destPeriodeId <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Paramètres manquants']);
    exit;
}
$stmt = $pdo->prepare("SELECT COUNT(*) FROM notes WHERE colonne_id IN (SELECT id FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ?)");
$stmt->execute([$matiereId, $destPeriodeId]);
if ((int)$stmt->fetchColumn() > 0) {
    http_response_code(409);
    echo json_encode(['error' => 'Duplication interdite : saisie en cours dans la période cible']);
    exit;
}
$src = $pdo->prepare("SELECT nom_colonne, code_colonne, type, note_max, coefficient, obligatoire, ordre FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ? ORDER BY ordre");
$src->execute([$matiereId, $srcPeriodeId]);
$rows = $src->fetchAll();
if (!$rows) {
    http_response_code(404);
    echo json_encode(['error' => 'Aucune colonne à copier']);
    exit;
}
$existing = $pdo->prepare("SELECT code_colonne FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ?");
$existing->execute([$matiereId, $destPeriodeId]);
$exists = array_map(fn($r) => $r['code_colonne'], $existing->fetchAll());
$pdo->beginTransaction();
try {
    $ancienne = json_encode($exists);
    foreach ($rows as $r) {
        if (in_array($r['code_colonne'], $exists, true)) {
            continue;
        }
        $ins = $pdo->prepare("INSERT INTO configuration_colonnes (matiere_id, periode_id, nom_colonne, code_colonne, type, note_max, coefficient, obligatoire, ordre) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $ins->execute([$matiereId, $destPeriodeId, $r['nom_colonne'], $r['code_colonne'], $r['type'], $r['note_max'], $r['coefficient'], (int)$r['obligatoire'], (int)$r['ordre']]);
        $exists[] = $r['code_colonne'];
    }
    $newSet = $pdo->prepare("SELECT id, nom_colonne, code_colonne, ordre FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ? ORDER BY ordre");
    $newSet->execute([$matiereId, $destPeriodeId]);
    $nouvelle = json_encode($newSet->fetchAll());
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $log = $pdo->prepare("INSERT INTO historique_admin (admin_id, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, justification, adresse_ip) VALUES (?, 'COLONNES_DUPLICATE', 'colonne_set', ?, ?, ?, NULL, ?)");
    $log->execute([$_SESSION['user']['id'], $matiereId, $ancienne, $nouvelle, $ip]);
    $pdo->commit();
    echo json_encode(['success' => true]);
} catch (Throwable $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Erreur duplication']);
}
