<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$matiereId = (int)($_POST['matiere_id'] ?? 0);
$periodeId = (int)($_POST['periode_id'] ?? 0);
$nom = trim($_POST['nom_colonne'] ?? '');
$code = trim($_POST['code_colonne'] ?? '');
$type = trim($_POST['type'] ?? 'note');
$noteMax = (float)($_POST['note_max'] ?? 20);
$coef = (float)($_POST['coefficient'] ?? 1);
$obligatoire = isset($_POST['obligatoire']) ? (int)$_POST['obligatoire'] : 1;
$ordre = (int)($_POST['ordre'] ?? 1);
if ($matiereId <= 0 || $periodeId <= 0 || $nom === '' || $code === '' || $noteMax <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Champs requis manquants']);
    exit;
}
$stmt = $pdo->prepare("SELECT COUNT(*) FROM notes WHERE colonne_id IN (SELECT id FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ?)");
$stmt->execute([$matiereId, $periodeId]);
if ((int)$stmt->fetchColumn() > 0) {
    http_response_code(409);
    echo json_encode(['error' => 'Modification interdite : saisie en cours']);
    exit;
}
try {
    $stmt = $pdo->prepare("INSERT INTO configuration_colonnes (matiere_id, periode_id, nom_colonne, code_colonne, type, note_max, coefficient, obligatoire, ordre) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$matiereId, $periodeId, $nom, $code, $type, $noteMax, $coef, $obligatoire ? 1 : 0, $ordre]);
    $id = (int)$pdo->lastInsertId();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $nouvelle = json_encode(['matiere_id'=>$matiereId,'periode_id'=>$periodeId,'nom_colonne'=>$nom,'code_colonne'=>$code,'type'=>$type,'note_max'=>$noteMax,'coefficient'=>$coef,'obligatoire'=>$obligatoire?1:0,'ordre'=>$ordre]);
    $stmt = $pdo->prepare("INSERT INTO historique_admin (admin_id, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, justification, adresse_ip) VALUES (?, 'COLONNE_CREATE', 'colonne', ?, NULL, ?, NULL, ?)");
    $stmt->execute([$_SESSION['user']['id'], $id, $nouvelle, $ip]);
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    http_response_code(409);
    echo json_encode(['error' => 'Code colonne déjà utilisé']);
}
