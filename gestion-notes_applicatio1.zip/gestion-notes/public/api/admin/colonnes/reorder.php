<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$matiereId = (int)($_POST['matiere_id'] ?? 0);
$periodeId = (int)($_POST['periode_id'] ?? 0);
$order = $_POST['order'] ?? [];
if ($matiereId <= 0 || $periodeId <= 0 || !is_array($order) || count($order) === 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Paramètres invalides']);
    exit;
}
$stmt = $pdo->prepare("SELECT COUNT(*) FROM notes WHERE colonne_id IN (SELECT id FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ?)");
$stmt->execute([$matiereId, $periodeId]);
if ((int)$stmt->fetchColumn() > 0) {
    http_response_code(409);
    echo json_encode(['error' => 'Modification interdite : saisie en cours']);
    exit;
}
$pdo->beginTransaction();
try {
    $oldOrders = $pdo->prepare("SELECT id, ordre FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ? ORDER BY ordre");
    $oldOrders->execute([$matiereId, $periodeId]);
    $ancienne = json_encode($oldOrders->fetchAll());
    $ordre = 1;
    foreach ($order as $colId) {
        $id = (int)$colId;
        $stmt = $pdo->prepare("UPDATE configuration_colonnes SET ordre = ? WHERE id = ? AND matiere_id = ? AND periode_id = ?");
        $stmt->execute([$ordre, $id, $matiereId, $periodeId]);
        $ordre++;
    }
    $newOrders = $pdo->prepare("SELECT id, ordre FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ? ORDER BY ordre");
    $newOrders->execute([$matiereId, $periodeId]);
    $nouvelle = json_encode($newOrders->fetchAll());
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $log = $pdo->prepare("INSERT INTO historique_admin (admin_id, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, justification, adresse_ip) VALUES (?, 'COLONNES_REORDER', 'colonne_set', ?, ?, ?, NULL, ?)");
    $log->execute([$_SESSION['user']['id'], $matiereId, $ancienne, $nouvelle, $ip]);
    $pdo->commit();
    echo json_encode(['success' => true]);
} catch (Throwable $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Erreur réordonnancement']);
}
