<?php
require_once __DIR__ . '/../../../../app/middleware/RequireAdmin.php';
require_admin();
require_once __DIR__ . '/../../../../app/config/database.php';
require_once __DIR__ . '/../../../../app/services/CalculMoyenneService.php';
$pdo = get_pdo();
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['error' => 'CSRF invalide']);
    exit;
}
$matiereId = (int)($_POST['matiere_id'] ?? 0);
$periodeId = (int)($_POST['periode_id'] ?? 0);
if ($matiereId <= 0 || $periodeId <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Paramètres manquants']);
    exit;
}
try {
    $service = new CalculMoyenneService();
    $result = $service->calculerPourMatierePeriode($matiereId, $periodeId);
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $nouvelle = json_encode(['matiere_id' => $matiereId, 'periode_id' => $periodeId, 'count' => (int)($result['count'] ?? 0)]);
    $stmt = $pdo->prepare("INSERT INTO historique_admin (admin_id, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, justification, adresse_ip) VALUES (?, 'CALCUL_MOYENNES', 'calcul', ?, NULL, ?, NULL, ?)");
    $stmt->execute([$_SESSION['user']['id'], $periodeId, $nouvelle, $ip]);
    echo json_encode(['success' => true, 'count' => (int)($result['count'] ?? 0)]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur calcul moyennes']);
}
