<?php
declare(strict_types=1);

require_once '../../app/services/auth.php';
require_once '../../app/config/database.php';

require_professor();
$pdo = get_pdo();

header('Content-Type: application/json; charset=utf-8');

$etudiantId = (int)($_GET['etudiant_id'] ?? 0);
$colonneId = (int)($_GET['colonne_id'] ?? 0);
$profId = (int)($_SESSION['user']['id'] ?? 0);

if ($etudiantId <= 0 || $colonneId <= 0 || $profId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Paramètres invalides']);
    exit;
}

$stmt = $pdo->prepare("SELECT matiere_id, periode_id FROM configuration_colonnes WHERE id = ?");
$stmt->execute([$colonneId]);
$cfg = $stmt->fetch();
if (!$cfg) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Colonne inconnue']);
    exit;
}

$stmt = $pdo->prepare("SELECT 1 FROM affectations_profs WHERE professeur_id = ? AND matiere_id = ? AND periode_id = ?");
$stmt->execute([$profId, $cfg['matiere_id'], $cfg['periode_id']]);
if (!$stmt->fetch()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Accès interdit']);
    exit;
}

$stmt = $pdo->prepare("SELECT id FROM notes WHERE etudiant_id = ? AND colonne_id = ?");
$stmt->execute([$etudiantId, $colonneId]);
$note = $stmt->fetch();
if (!$note) {
    echo json_encode(['success' => true, 'history' => []]);
    exit;
}
$noteId = (int)$note['id'];

$sql = "SELECT h.date_modification, p.nom AS utilisateur_nom, h.ancienne_valeur, h.nouvelle_valeur, h.ancien_statut, h.nouveau_statut, h.adresse_ip FROM historique_notes h JOIN professeurs p ON p.id = h.modifie_par WHERE h.note_id = ? ORDER BY h.date_modification DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$noteId]);
$rows = $stmt->fetchAll() ?: [];

echo json_encode(['success' => true, 'history' => $rows]);

