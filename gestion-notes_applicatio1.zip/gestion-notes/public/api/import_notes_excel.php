<?php
declare(strict_types=1);

require_once '../../app/services/auth.php';
require_once '../../app/config/database.php';

require_professor();
$pdo = get_pdo();

header('Content-Type: application/json; charset=utf-8');

function json_error(int $code, string $message, array $extra = []): void {
    http_response_code($code);
    echo json_encode(['success' => false, 'error' => $message] + $extra);
    exit;
}

if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    json_error(403, 'CSRF invalide');
}

$matiereId = (int)($_POST['matiere_id'] ?? 0);
$periodeId = (int)($_POST['periode_id'] ?? 0);
$profId    = (int)($_SESSION['user']['id'] ?? 0);

if ($matiereId <= 0 || $periodeId <= 0 || $profId <= 0) {
    json_error(400, 'Paramètres invalides');
}

$stmt = $pdo->prepare("SELECT 1 FROM affectations_profs WHERE professeur_id = ? AND matiere_id = ? AND periode_id = ?");
$stmt->execute([$profId, $matiereId, $periodeId]);
if (!$stmt->fetch()) {
    json_error(403, 'Accès interdit');
}

$stmt = $pdo->prepare("SELECT statut FROM periodes WHERE id = ?");
$stmt->execute([$periodeId]);
$periode = $stmt->fetch();
if (!$periode || ($periode['statut'] ?? '') !== 'ouverte') {
    json_error(409, 'Période non ouverte');
}

$stmt = $pdo->prepare("SELECT valide_par_prof FROM progression_saisie WHERE matiere_id = ? AND periode_id = ?");
$stmt->execute([$matiereId, $periodeId]);
$progression = $stmt->fetch();
if ($progression && (int)$progression['valide_par_prof'] === 1) {
    json_error(409, 'Import interdit : notes validées');
}

$fileField = null;
if (isset($_FILES['excel_file'])) {
    $fileField = $_FILES['excel_file'];
} elseif (isset($_FILES['file'])) {
    $fileField = $_FILES['file'];
}
if (!$fileField) {
    json_error(400, 'Aucun fichier fourni');
}

$allowedMime = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
$maxSize = 8 * 1024 * 1024;
$originalName = $fileField['name'] ?? '';
$mime = $fileField['type'] ?? '';
$size = (int)($fileField['size'] ?? 0);
$tmpName = $fileField['tmp_name'] ?? '';

if (!in_array($mime, $allowedMime, true)) {
    json_error(415, 'Format Excel invalide (XLSX uniquement)');
}
if ($size <= 0 || $size > $maxSize) {
    json_error(413, 'Fichier trop volumineux (max 8MB)');
}
if (!preg_match('/\\.xlsx$/i', $originalName)) {
    json_error(415, 'Extension de fichier non autorisée (XLSX requis)');
}
if (!is_uploaded_file($tmpName)) {
    json_error(400, 'Téléversement invalide');
}

$tmpDir = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'gestion_notes_imports';
if (!is_dir($tmpDir)) {
    @mkdir($tmpDir, 0700, true);
}
$destPath = $tmpDir . DIRECTORY_SEPARATOR . uniqid('import_', true) . '.xlsx';
if (!move_uploaded_file($tmpName, $destPath)) {
    json_error(500, 'Impossible de déplacer le fichier');
}

function read_xlsx_rows(string $filePath): array {
    $rows = [];
    $zip = new ZipArchive();
    if ($zip->open($filePath) !== true) {
        throw new RuntimeException('Impossible d’ouvrir le fichier XLSX');
    }
    $sharedStrings = [];
    $ssIndex = $zip->locateName('xl/sharedStrings.xml', ZipArchive::FL_NODIR);
    if ($ssIndex !== false) {
        $ssXml = $zip->getFromIndex($ssIndex);
        $doc = new DOMDocument();
        $doc->loadXML($ssXml);
        foreach ($doc->getElementsByTagName('si') as $si) {
            $text = '';
            foreach ($si->getElementsByTagName('t') as $t) {
                $text .= $t->textContent;
            }
            $sharedStrings[] = $text;
        }
    }
    $sheetIndex = $zip->locateName('xl/worksheets/sheet1.xml', ZipArchive::FL_NODIR);
    if ($sheetIndex === false) {
        throw new RuntimeException('Feuille active introuvable (sheet1.xml)');
    }
    $sheetXml = $zip->getFromIndex($sheetIndex);
    $zip->close();
    $doc = new DOMDocument();
    $doc->loadXML($sheetXml);
    $sheetData = $doc->getElementsByTagName('sheetData')->item(0);
    if (!$sheetData) return [];
    foreach ($sheetData->getElementsByTagName('row') as $row) {
        $rowArr = [];
        foreach ($row->getElementsByTagName('c') as $c) {
            $ref = $c->getAttribute('r');
            if (preg_match('/^([A-Z]+)(\\d+)$/', $ref, $m)) {
                $colLetters = $m[1];
                $colIndex = 0;
                for ($i = 0; $i < strlen($colLetters); $i++) {
                    $colIndex = $colIndex * 26 + (ord($colLetters[$i]) - 64);
                }
                $colIndex--; // zero-based
            } else {
                $colIndex = count($rowArr);
            }
            $type = $c->getAttribute('t');
            $valueNode = $c->getElementsByTagName('v')->item(0);
            $isNode = $c->getElementsByTagName('is')->item(0);
            $value = '';
            if ($type === 's' && $valueNode) {
                $idx = (int)$valueNode->textContent;
                $value = $sharedStrings[$idx] ?? '';
            } elseif ($isNode) {
                $t = $isNode->getElementsByTagName('t')->item(0);
                $value = $t ? $t->textContent : '';
            } elseif ($valueNode) {
                $value = $valueNode->textContent;
            } else {
                $value = '';
            }
            $rowArr[$colIndex] = $value;
        }
        if (!empty($rowArr)) {
            ksort($rowArr);
            $rows[] = array_values($rowArr);
        }
    }
    return $rows;
}

try {
    $rows = read_xlsx_rows($destPath);
} catch (Throwable $e) {
    @unlink($destPath);
    json_error(422, 'Lecture Excel échouée: ' . $e->getMessage());
}
@unlink($destPath);

if (count($rows) < 2) {
    json_error(422, 'Fichier vide ou sans données');
}

$headers = array_map(static function ($v) { return trim((string)$v); }, $rows[0]);

$stmt = $pdo->prepare("SELECT id, code_colonne, note_max, obligatoire FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ? ORDER BY ordre");
$stmt->execute([$matiereId, $periodeId]);
$configCols = $stmt->fetchAll();
if (!$configCols) {
    json_error(422, 'Aucune configuration de colonnes trouvée');
}

$requiredCodes = array_map(static fn($c) => $c['code_colonne'], $configCols);
$allowedHeaders = array_merge(['numero_etudiant'], $requiredCodes);
foreach ($requiredCodes as $code) {
    $allowedHeaders[] = 'statut_' . $code;
}
foreach ($requiredCodes as $code) {
    if (!in_array($code, $headers, true)) {
        json_error(422, "Colonne manquante : {$code}");
    }
}
foreach ($headers as $h) {
    if (!in_array($h, $allowedHeaders, true)) {
        json_error(422, "Colonne non autorisée : {$h}");
    }
}

$headerIndex = [];
foreach ($headers as $i => $h) {
    $headerIndex[$h] = $i;
}

$errors = [];
$imported = 0;

try {
    $pdo->beginTransaction();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $pdo->exec("SET @_ip_address = " . $pdo->quote($ip));

    $enrollStmt = $pdo->prepare("SELECT dispense FROM inscriptions_matieres WHERE etudiant_id = ? AND matiere_id = ? AND periode_id = ?");
    $studentByNumStmt = $pdo->prepare("SELECT id FROM etudiants WHERE numero_etudiant = ?");
    $selectNoteStmt = $pdo->prepare("SELECT id, valeur, statut FROM notes WHERE etudiant_id = ? AND colonne_id = ? FOR UPDATE");
    $insertNoteStmt = $pdo->prepare("INSERT INTO notes (etudiant_id, colonne_id, valeur, statut, saisi_par) VALUES (?, ?, ?, ?, ?)");
    $updateNoteStmt = $pdo->prepare("UPDATE notes SET valeur = ?, statut = ?, saisi_par = ? WHERE id = ?");

    $colMap = [];
    foreach ($configCols as $c) {
        $colMap[$c['code_colonne']] = [
            'id' => (int)$c['id'],
            'max' => (float)$c['note_max'],
            'obligatoire' => (int)$c['obligatoire'] === 1
        ];
    }

    for ($r = 1; $r < count($rows); $r++) {
        $row = $rows[$r];
        $numIdx = $headerIndex['numero_etudiant'] ?? null;
        if ($numIdx === null) {
            $errors[] = ['row' => $r + 1, 'message' => 'Colonne numero_etudiant introuvable'];
            continue;
        }
        $numero = trim((string)($row[$numIdx] ?? ''));
        if ($numero === '') {
            $errors[] = ['row' => $r + 1, 'message' => 'Numéro étudiant manquant'];
            continue;
        }

        $studentByNumStmt->execute([$numero]);
        $stu = $studentByNumStmt->fetch();
        if (!$stu) {
            $errors[] = ['row' => $r + 1, 'message' => "Étudiant inconnu: {$numero}"];
            continue;
        }
        $etudiantId = (int)$stu['id'];

        $enrollStmt->execute([$etudiantId, $matiereId, $periodeId]);
        $enroll = $enrollStmt->fetch();
        if (!$enroll) {
            $errors[] = ['row' => $r + 1, 'message' => 'Étudiant non inscrit à la matière'];
            continue;
        }
        $dispense = (int)($enroll['dispense'] ?? 0) === 1;

        foreach ($requiredCodes as $code) {
            $gradeIdx = $headerIndex[$code] ?? null;
            $statusIdx = $headerIndex['statut_' . $code] ?? null;
            $statusCell = $statusIdx !== null ? strtoupper(trim((string)($row[$statusIdx] ?? ''))) : '';
            $dbStatus = 'saisie';
            $value = null;

            if ($dispense || $statusCell === 'DIS') {
                $dbStatus = 'dispense';
                $value = null;
            } elseif ($statusCell === 'ABS') {
                $dbStatus = 'absent';
                $value = null;
            } elseif ($statusCell === 'DEF') {
                $dbStatus = 'defaillant';
                $value = null;
            } else {
                $raw = trim((string)($gradeIdx !== null ? ($row[$gradeIdx] ?? '') : ''));
                if ($raw === '') {
                    if ($colMap[$code]['obligatoire']) {
                        $errors[] = ['row' => $r + 1, 'message' => "Note manquante pour {$code}"];
                    }
                    continue;
                }
                if (!is_numeric($raw)) {
                    $errors[] = ['row' => $r + 1, 'message' => "Valeur non numérique pour {$code}"];
                    continue;
                }
                $num = (float)$raw;
                if ($num < 0 || $num > $colMap[$code]['max']) {
                    $errors[] = ['row' => $r + 1, 'message' => "Note hors bornes pour {$code} (0-" . $colMap[$code]['max'] . ")"];
                    continue;
                }
                $value = $num;
                $dbStatus = 'saisie';
            }

            $colId = $colMap[$code]['id'];
            $selectNoteStmt->execute([$etudiantId, $colId]);
            $note = $selectNoteStmt->fetch();
            if ($note) {
                $oldVal = $note['valeur'];
                $oldSt = $note['statut'];
                $shouldUpdate = ($oldVal !== $value) || ($oldSt !== $dbStatus);
                if ($shouldUpdate) {
                    $updateNoteStmt->execute([$value, $dbStatus, $profId, $note['id']]);
                    $imported++;
                }
            } else {
                $insertNoteStmt->execute([$etudiantId, $colId, $value, $dbStatus, $profId]);
                $imported++;
            }
        }
    }

    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_error(500, 'Erreur lors de l’import: ' . $e->getMessage());
}

echo json_encode([
    'success' => true,
    'imported' => $imported,
    'errors' => count($errors),
    'details' => $errors
]);

