<?php
declare(strict_types=1);

require_once '../../app/services/auth.php';
require_once '../../app/config/database.php';

require_professor();
$pdo = get_pdo();

header('Content-Type: application/json; charset=utf-8');

if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'CSRF invalide']);
    exit;
}

$matiereId = (int)($_POST['matiere_id'] ?? 0);
$periodeId = (int)($_POST['periode_id'] ?? 0);
$etudiantId = (int)($_POST['etudiant_id'] ?? 0);
$colonneId = (int)($_POST['colonne_id'] ?? 0);
$rawValeur = $_POST['valeur'] ?? null;
$rawStatut = strtoupper(trim((string)($_POST['statut'] ?? '')));
$profId = (int)($_SESSION['user']['id'] ?? 0);

if ($matiereId <= 0 || $periodeId <= 0 || $etudiantId <= 0 || $colonneId <= 0 || $profId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Paramètres invalides']);
    exit;
}

$stmt = $pdo->prepare("SELECT statut FROM periodes WHERE id = ?");
$stmt->execute([$periodeId]);
$periode = $stmt->fetch();
if (!$periode || ($periode['statut'] ?? '') !== 'ouverte') {
    http_response_code(409);
    echo json_encode(['success' => false, 'error' => 'Modification interdite']);
    exit;
}

$stmt = $pdo->prepare("SELECT 1 FROM affectations_profs WHERE professeur_id = ? AND matiere_id = ? AND periode_id = ?");
$stmt->execute([$profId, $matiereId, $periodeId]);
if (!$stmt->fetch()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Accès interdit']);
    exit;
}

$stmt = $pdo->prepare("SELECT id, code_colonne, note_max, obligatoire FROM configuration_colonnes WHERE id = ? AND matiere_id = ? AND periode_id = ?");
$stmt->execute([$colonneId, $matiereId, $periodeId]);
$colCfg = $stmt->fetch();
if (!$colCfg) {
    http_response_code(422);
    echo json_encode(['success' => false, 'error' => 'Colonne inconnue']);
    exit;
}

$stmt = $pdo->prepare("SELECT dispense FROM inscriptions_matieres WHERE etudiant_id = ? AND matiere_id = ? AND periode_id = ?");
$stmt->execute([$etudiantId, $matiereId, $periodeId]);
$enroll = $stmt->fetch();
if (!$enroll) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Étudiant non inscrit']);
    exit;
}
$dispense = (int)($enroll['dispense'] ?? 0) === 1;

$dbStatus = 'saisie';
$valeur = null;
if ($dispense || $rawStatut === 'DIS') {
    $dbStatus = 'dispense';
    $valeur = null;
} elseif ($rawStatut === 'ABS') {
    $dbStatus = 'absent';
    $valeur = null;
} elseif ($rawStatut === 'DEF') {
    $dbStatus = 'defaillant';
    $valeur = null;
} else {
    $raw = trim((string)$rawValeur);
    if ($raw === '') {
        if ((int)$colCfg['obligatoire'] === 1) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => 'Note manquante']);
            exit;
        }
        $valeur = null;
    } else {
        if (!is_numeric($raw)) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => 'Valeur non numérique']);
            exit;
        }
        $num = (float)$raw;
        $max = (float)$colCfg['note_max'];
        if ($num < 0 || $num > $max) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => 'Note hors bornes']);
            exit;
        }
        $valeur = $num;
        $dbStatus = 'saisie';
    }
}

try {
    $pdo->beginTransaction();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $pdo->exec("SET @_ip_address = " . $pdo->quote($ip));

    $stmt = $pdo->prepare("SELECT id, valeur, statut FROM notes WHERE etudiant_id = ? AND colonne_id = ? FOR UPDATE");
    $stmt->execute([$etudiantId, $colonneId]);
    $note = $stmt->fetch();

    if ($note) {
        $changed = ($note['valeur'] !== $valeur) || ($note['statut'] !== $dbStatus);
        if ($changed) {
            $upd = $pdo->prepare("UPDATE notes SET valeur = ?, statut = ?, saisi_par = ? WHERE id = ?");
            $upd->execute([$valeur, $dbStatus, $profId, $note['id']]);
        } else {
            $ins = $pdo->prepare("INSERT INTO historique_notes (note_id, ancienne_valeur, nouvelle_valeur, ancien_statut, nouveau_statut, modifie_par, adresse_ip) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $ins->execute([$note['id'], $note['valeur'], $valeur, $note['statut'], $dbStatus, $profId, $ip]);
        }
    } else {
        $insNote = $pdo->prepare("INSERT INTO notes (etudiant_id, colonne_id, valeur, statut, saisi_par) VALUES (?, ?, ?, ?, ?)");
        $insNote->execute([$etudiantId, $colonneId, $valeur, $dbStatus, $profId]);
        $newNoteId = (int)$pdo->lastInsertId();
        $insHist = $pdo->prepare("INSERT INTO historique_notes (note_id, ancienne_valeur, nouvelle_valeur, ancien_statut, nouveau_statut, modifie_par, adresse_ip) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $insHist->execute([$newNoteId, null, $valeur, null, $dbStatus, $profId, $ip]);
    }

    $pdo->commit();

    $stmt = $pdo->prepare("SELECT pourcentage FROM progression_saisie WHERE matiere_id = ? AND periode_id = ?");
    $stmt->execute([$matiereId, $periodeId]);
    $prog = $stmt->fetch();
    $pourcentage = $prog ? (float)$prog['pourcentage'] : 0.0;

    echo json_encode([
        'success' => true,
        'progression' => $pourcentage,
        'valeur' => $valeur,
        'statut' => $dbStatus
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erreur serveur']);
}

