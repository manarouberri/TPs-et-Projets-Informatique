<?php
require_once '../../app/services/auth.php';
require_once '../../app/config/database.php';

require_professor();

// 2️⃣ CSRF verification
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    exit(json_encode(['error' => 'CSRF invalide']));
}

// 3️⃣ Received parameters
$matiereId = (int) $_POST['matiere_id'];
$periodeId = (int) $_POST['periode_id'];
$profId    = $_SESSION['user']['id'];

// 4️⃣ Teacher–subject assignment verification
$sql = "
SELECT 1
FROM affectations_profs
WHERE professeur_id = ?
AND matiere_id = ?
AND periode_id = ?
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$profId, $matiereId, $periodeId]);

if (!$stmt->fetch()) {
    http_response_code(403);
    exit(json_encode(['error' => 'Accès interdit']));
}

// 5️⃣ Open period verification
$sql = "SELECT statut FROM periodes WHERE id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$periodeId]);
$periode = $stmt->fetch();

if ($periode['statut'] !== 'ouverte') {
    http_response_code(409);
    exit(json_encode(['error' => 'Période déjà verrouillée']));
}

// 6️⃣ Completeness verification
$sql = "
SELECT total_notes_attendues, notes_saisies
FROM progression_saisie
WHERE matiere_id = ?
AND periode_id = ?
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$matiereId, $periodeId]);
$progression = $stmt->fetch();

if (!$progression || $progression['notes_saisies'] < $progression['total_notes_attendues']) {
    http_response_code(422);
    exit(json_encode([
        'error' => 'Saisie incomplète',
        'details' => [
            'saisies' => $progression['notes_saisies'] ?? 0,
            'attendues' => $progression['total_notes_attendues'] ?? 0
        ]
    ]));
}

try {
    // 7️⃣ Transactional locking
    $pdo->beginTransaction();

    // 8️⃣ Grade locking (Optional: update status only if supported by enum, or skip if business rule differs)
    // Note: The schema defines enum('saisie', 'absent', 'dispense', 'defaillant')
    // 'verrouille' is NOT in the enum. We will skip modifying 'statut' here to avoid DB error,
    // relying instead on 'valide_par_prof' in progression_saisie as the lock mechanism.
    /*
    $sql = "
    UPDATE notes n
    JOIN configuration_colonnes c ON c.id = n.colonne_id
    SET n.statut = 'verrouille'
    WHERE c.matiere_id = ?
    AND c.periode_id = ?
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$matiereId, $periodeId]);
    */

    // 9️⃣ Progression validation
    $sql = "
    UPDATE progression_saisie
    SET valide_par_prof = 1,
        date_validation = NOW()
    WHERE matiere_id = ?
    AND periode_id = ?
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$matiereId, $periodeId]);

    // 🔟 Secure commit
    $pdo->commit();

    // 1️⃣1️⃣ JSON response
    echo json_encode([
        'success' => true,
        'message' => 'Saisie validée et verrouillée'
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    exit(json_encode(['error' => 'Erreur lors de la validation: ' . $e->getMessage()]));
}
