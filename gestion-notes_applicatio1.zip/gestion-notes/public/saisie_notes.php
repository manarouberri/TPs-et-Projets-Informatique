<?php
require_once __DIR__ . '/../app/services/auth.php';
require_once __DIR__ . '/../app/config/database.php';
require_professor();
$pdo = $pdo ?? get_pdo();
$matiereId = isset($_GET['matiere_id']) ? (int)$_GET['matiere_id'] : 0;
$periodeId = isset($_GET['periode_id']) ? (int)$_GET['periode_id'] : 0;
$profId = $_SESSION['user']['id'];
$stmt = $pdo->prepare("SELECT 1 FROM affectations_profs WHERE professeur_id = ? AND matiere_id = ? AND periode_id = ?");
$stmt->execute([$profId, $matiereId, $periodeId]);
if (!$stmt->fetch()) {
    exit('Accès non autorisé');
}
$stmt = $pdo->prepare("SELECT code, nom FROM matieres WHERE id = ?");
$stmt->execute([$matiereId]);
$matiere = $stmt->fetch() ?: ['code' => '', 'nom' => ''];
$stmt = $pdo->prepare("SELECT nom, statut, date_debut_saisie, date_fin_saisie FROM periodes WHERE id = ?");
$stmt->execute([$periodeId]);
$periode = $stmt->fetch() ?: ['nom' => '', 'statut' => 'fermee', 'date_debut_saisie' => '', 'date_fin_saisie' => ''];
$verrouille = ($periode['statut'] !== 'ouverte');
$stmt = $pdo->prepare("SELECT valide_par_prof, pourcentage FROM progression_saisie WHERE matiere_id = ? AND periode_id = ?");
$stmt->execute([$matiereId, $periodeId]);
$progression = $stmt->fetch() ?: ['valide_par_prof' => 0, 'pourcentage' => 0];
$finalise = (int)($progression['valide_par_prof'] ?? 0) === 1;
$progressPct = (float)($progression['pourcentage'] ?? 0);
$stmt = $pdo->prepare("SELECT id, nom_colonne, code_colonne, type, note_max, obligatoire, ordre FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ? ORDER BY ordre");
$stmt->execute([$matiereId, $periodeId]);
$colonnes = $stmt->fetchAll();
$stmt = $pdo->prepare("SELECT e.id AS etudiant_id, e.nom, e.prenom, im.dispense FROM inscriptions_matieres im JOIN etudiants e ON e.id = im.etudiant_id WHERE im.matiere_id = ? AND im.periode_id = ? ORDER BY e.nom, e.prenom");
$stmt->execute([$matiereId, $periodeId]);
$etudiants = $stmt->fetchAll();
$stmt = $pdo->prepare("SELECT etudiant_id, colonne_id, valeur, statut FROM notes WHERE colonne_id IN (SELECT id FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ?)");
$stmt->execute([$matiereId, $periodeId]);
$notesBrutes = $stmt->fetchAll();
$notes = [];
foreach ($notesBrutes as $n) {
    $notes[$n['etudiant_id']][$n['colonne_id']] = ['valeur' => $n['valeur'], 'statut' => $n['statut']];
}
if (isset($_POST['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saisie des notes - <?php echo htmlspecialchars($matiere['code'] . ' - ' . $matiere['nom']); ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="grade-entry-container">
        <!-- Header -->
        <header class="grade-entry-header">
            <div class="header-content">
                <div class="breadcrumb-section">
                    <a href="dashboard.php" class="breadcrumb-link">Tableau de bord</a>
                    <span class="breadcrumb-separator">&gt;</span>
                    <span class="breadcrumb-current"><?php echo htmlspecialchars($matiere['nom']); ?></span>
                </div>
                <div class="user-section">
                    <span class="user-name"><?php echo htmlspecialchars($_SESSION['user']['nom']); ?></span>
                    <form method="POST" class="logout-form">
                        <button type="submit" name="logout" class="logout-button">Déconnexion</button>
                    </form>
                </div>
            </div>
        </header>

        <!-- Subject Information -->
        <section class="subject-info">
            <div class="info-header">
                <h2><?php echo htmlspecialchars($matiere['code'] . ' - ' . $matiere['nom']); ?></h2>
                <div class="subject-meta">
                    <span class="academic-period"><?php echo htmlspecialchars($periode['nom']); ?></span>
                    <span class="student-count"><?php echo count($etudiants); ?> étudiants</span>
                    <span class="deadline">Du : <?php echo htmlspecialchars($periode['date_debut_saisie']); ?> • Au : <?php echo htmlspecialchars($periode['date_fin_saisie']); ?></span>
                </div>
            </div>
            
            <div class="subject-status">
                <span class="status-badge <?php echo $periode['statut']; ?>">
                    Période : <?php echo htmlspecialchars($periode['statut']); ?>
                </span>
                <span class="status-badge pending">En cours</span>
            </div>
        </section>

        <!-- Messages -->
        <?php if (!empty($success_message)): ?>
            <div class="success-message">
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <!-- Grade Entry Form -->
        <form method="POST" class="grade-entry-form">
            <div class="table-container">
                <table class="grades-table">
                    <thead>
                        <tr>
                            <th rowspan="2" class="student-info-header">Étudiant</th>
                            <?php foreach ($colonnes as $c): ?>
                                <th class="grade-column-header" colspan="2">
                                    <?php echo htmlspecialchars($c['nom_colonne']); ?>
                                    <div class="column-meta">(Max : <?php echo htmlspecialchars($c['note_max']); ?>)</div>
                                </th>
                            <?php endforeach; ?>
                            <th rowspan="2" class="status-header">Statut</th>
                        </tr>
                        <tr>
                            <?php foreach ($colonnes as $c): ?>
                                <th class="grade-input-header">Note</th>
                                <th class="status-input-header">Statut</th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($etudiants as $e):
                            $student_grades = $notes[$e['etudiant_id']] ?? [];
                        ?>
                            <tr class="student-row">
                                <td class="student-name">
                                    <?php echo htmlspecialchars($e['nom'] . ' ' . $e['prenom']); ?>
                                </td>
                                <?php foreach ($colonnes as $c): 
                                    $cell = $student_grades[$c['id']] ?? null;
                                    $grade_value = $cell['valeur'] ?? '';
                                    $statut_raw = $cell['statut'] ?? '';
                                    $status_value = ($statut_raw === 'absent' ? 'ABS' : ($statut_raw === 'defaillant' ? 'DEF' : ($statut_raw === 'dispense' ? 'DIS' : '')));
                                ?>
                                    <td class="grade-cell">
                                        <input type="number" 
                                               name="grades[<?php echo (int)$e['etudiant_id']; ?>][<?php echo (int)$c['id']; ?>]"
                                               value="<?php echo $grade_value !== '' ? htmlspecialchars($grade_value) : ''; ?>"
                                               min="0" 
                                               max="<?php echo htmlspecialchars($c['note_max']); ?>"
                                               step="0.1"
                                               class="grade-input"
                                               <?php echo ($verrouille || $e['dispense']) ? 'readonly' : ''; ?>>
                                        <button type="button" class="history-button" onclick="openHistory(<?php echo (int)$e['etudiant_id']; ?>, <?php echo (int)$c['id']; ?>)">Historique</button>
                                    </td>
                                    <td class="status-cell">
                                        <select name="status[<?php echo (int)$e['etudiant_id']; ?>][<?php echo (int)$c['id']; ?>]" 
                                                class="status-select"
                                                <?php echo ($verrouille || $e['dispense']) ? 'disabled' : ''; ?>>
                                            <option value="">Normal</option>
                                            <option value="ABS" <?php echo $status_value === 'ABS' ? 'selected' : ''; ?>>ABS (Absent)</option>
                                            <option value="DEF" <?php echo $status_value === 'DEF' ? 'selected' : ''; ?>>DEF (Ajourné)</option>
                                            <option value="DIS" <?php echo $status_value === 'DIS' ? 'selected' : ''; ?>>DIS (Dispensé)</option>
                                        </select>
                                    </td>
                                <?php endforeach; ?>
                                <td class="overall-status">
                                    <?php 
                                    $has_abs = false;
                                    $has_def = false;
                                    $has_dis = false;
                                    $has_empty = false;
                                    
                                    foreach ($colonnes as $c2) {
                                        $cell2 = $student_grades[$c2['id']] ?? null;
                                        $val = $cell2['valeur'] ?? '';
                                        $st = $cell2['statut'] ?? '';
                                        if ($st === 'absent') $has_abs = true;
                                        elseif ($st === 'defaillant') $has_def = true;
                                        elseif ($st === 'dispense') $has_dis = true;
                                        elseif ($val === null || $val === '') $has_empty = true;
                                    }
                                    
                                    if ($has_dis) echo '<span class="status-badge DIS">DIS</span>';
                                    elseif ($has_abs) echo '<span class="status-badge ABS">ABS</span>';
                                    elseif ($has_def) echo '<span class="status-badge DEF">DEF</span>';
                                    elseif ($has_empty) echo '<span class="status-badge incomplete">Incomplet</span>';
                                    else echo '<span class="status-badge complete">Complet</span>';
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Action Buttons -->
            <div class="form-actions">
                <?php if (!$verrouille): ?>
                    <!-- Hidden CSRF token for JS fetch calls -->
                    <input type="hidden" id="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? ''); ?>">
                    
                    <button type="button" class="save-button" onclick="saveAllGrades()">
                        Enregistrer les notes
                    </button>
                    
                    <button type="button" onclick="importExcel()" class="import-button" id="import-btn" <?php echo $finalise ? 'disabled' : ''; ?>>
                        Importer depuis Excel
                    </button>
                    
                    <button type="button" class="validate-button" onclick="validateFinalGrades()">
                        Valider toutes les notes
                    </button>
                <?php else: ?>
                    <div class="locked-message">
                        <strong>⚠ La saisie des notes est actuellement verrouillée.</strong>
                        <p>La période académique est fermée ou la date limite est dépassée.</p>
                    </div>
                <?php endif; ?>
            </div>
        </form>

        <!-- Hidden file input for Excel import -->
        <form method="POST" enctype="multipart/form-data" id="excel-import-form" style="display: none;">
            <input type="file" name="excel_file" id="excel-file-input" accept=".xlsx" onchange="submitExcelForm()">
            <input type="hidden" name="import_excel" value="1">
        </form>
        
        <!-- Import Feedback -->
        <div class="import-feedback">
            <div class="progress-wrapper">
                <div class="progress-label">Progression de l’import</div>
                <div class="progress-bar">
                    <div class="progress-fill" id="import-progress" style="width: <?php echo number_format($progressPct, 2); ?>%;"></div>
                </div>
                <div class="progress-stats">
                    <span id="import-stats">Validé : <?php echo number_format($progressPct, 2); ?>%</span>
                </div>
            </div>
            <div class="error-summary" id="import-errors" style="display: none;">
                <h4>Erreurs d’import</h4>
                <ul id="import-error-list"></ul>
            </div>
        </div>
        
        <div id="history-modal" class="modal" style="display:none;">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Historique</h3>
                    <button type="button" class="modal-close" onclick="closeHistory()">×</button>
                </div>
                <div class="modal-body">
                    <table class="history-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Utilisateur</th>
                                <th>Ancienne</th>
                                <th>Nouvelle</th>
                                <th>Ancien statut</th>
                                <th>Nouveau statut</th>
                                <th>IP</th>
                            </tr>
                        </thead>
                        <tbody id="history-body"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        const matiereId = <?php echo $matiereId; ?>;
        const periodeId = <?php echo $periodeId; ?>;
        const csrfToken = document.getElementById('csrf_token').value;

        function importExcel() {
            if (document.getElementById('import-btn').disabled) {
                alert('Import désactivé : notes déjà validées.');
                return;
            }
            if (confirm('Confirmer l’import Excel des notes ?')) {
                document.getElementById('excel-file-input').click();
            }
        }

        function submitExcelForm() {
            const fileInput = document.getElementById('excel-file-input');
            if (!fileInput.files || fileInput.files.length === 0) return;
            const file = fileInput.files[0];
            const formData = new FormData();
            formData.append('csrf_token', csrfToken);
            formData.append('matiere_id', matiereId);
            formData.append('periode_id', periodeId);
            formData.append('excel_file', file);
            
            const importBtn = document.getElementById('import-btn');
            importBtn.disabled = true;
            
            fetch('api/import_notes_excel.php', {
                method: 'POST',
                body: formData
            }).then(r => r.json())
              .then(data => {
                importBtn.disabled = false;
                if (data.success) {
                    const total = (data.imported || 0) + (data.errors || 0);
                    const pct = total > 0 ? Math.round((data.imported * 100) / total) : 0;
                    document.getElementById('import-progress').style.width = pct + '%';
                    document.getElementById('import-stats').textContent = `Importés : ${data.imported} • Erreurs : ${data.errors}`;
                    
                    const errorsBox = document.getElementById('import-errors');
                    const errorList = document.getElementById('import-error-list');
                    errorList.innerHTML = '';
                    if (Array.isArray(data.details) && data.details.length > 0) {
                        data.details.forEach(e => {
                            const li = document.createElement('li');
                            li.textContent = `Ligne ${e.row} : ${e.message}`;
                            errorList.appendChild(li);
                        });
                        errorsBox.style.display = 'block';
                    } else {
                        errorsBox.style.display = 'none';
                    }
                    
                    alert('Import terminé.');
                    // Refresh to reflect updated values and progression
                    location.reload();
                } else {
                    alert('Import échoué: ' + (data.error || 'Erreur inconnue'));
                    if (data.details) {
                        const errorsBox = document.getElementById('import-errors');
                        const errorList = document.getElementById('import-error-list');
                        errorList.innerHTML = '';
                        (data.details || []).forEach(e => {
                            const li = document.createElement('li');
                            li.textContent = `Row ${e.row}: ${e.message}`;
                            errorList.appendChild(li);
                        });
                        errorsBox.style.display = 'block';
                    }
                }
              })
              .catch(err => {
                importBtn.disabled = false;
                alert('Erreur réseau durant l’import.');
                console.error(err);
              });
        }
        
        // Save a single grade cell (can be called on blur/change)
        function saveGrade(etudiantId, colonneId, value, status = null) {
            const formData = new FormData();
            formData.append('csrf_token', csrfToken);
            formData.append('matiere_id', matiereId);
            formData.append('periode_id', periodeId);
            formData.append('etudiant_id', etudiantId);
            formData.append('colonne_id', colonneId);
            formData.append('valeur', value);
            if (status) formData.append('statut', status);

            fetch('api/save_note.php', {
                method: 'POST',
                body: formData
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    console.log('Enregistré. Progression : ' + data.progression + '%');
                } else {
                    console.error('Échec de l’enregistrement', data);
                    alert('Erreur lors de l’enregistrement de la note : ' + (data.error || 'Erreur inconnue'));
                }
            })
            .catch(err => console.error('Network error', err));
        }
        
        function openHistory(etudiantId, colonneId) {
            const url = `api/get_history.php?etudiant_id=${encodeURIComponent(etudiantId)}&colonne_id=${encodeURIComponent(colonneId)}`;
            fetch(url, { method: 'GET' })
                .then(r => r.json())
                .then(data => {
                    if (!data.success) {
                        alert('Unable to load history');
                        return;
                    }
                    const body = document.getElementById('history-body');
                    body.innerHTML = '';
                    (data.history || []).forEach(row => {
                        const tr = document.createElement('tr');
                        const tdDate = document.createElement('td'); tdDate.textContent = row.date_modification;
                        const tdUser = document.createElement('td'); tdUser.textContent = row.utilisateur_nom;
                        const tdOld = document.createElement('td'); tdOld.textContent = row.ancienne_valeur ?? '';
                        const tdNew = document.createElement('td'); tdNew.textContent = row.nouvelle_valeur ?? '';
                        const tdOldS = document.createElement('td'); tdOldS.textContent = row.ancien_statut ?? '';
                        const tdNewS = document.createElement('td'); tdNewS.textContent = row.nouveau_statut ?? '';
                        const tdIP = document.createElement('td'); tdIP.textContent = row.adresse_ip ?? '';
                        tr.appendChild(tdDate);
                        tr.appendChild(tdUser);
                        tr.appendChild(tdOld);
                        tr.appendChild(tdNew);
                        tr.appendChild(tdOldS);
                        tr.appendChild(tdNewS);
                        tr.appendChild(tdIP);
                        body.appendChild(tr);
                    });
                    document.getElementById('history-modal').style.display = 'block';
                })
                .catch(err => {
                    alert('Network error loading history');
                    console.error(err);
                });
        }
        function closeHistory() {
            document.getElementById('history-modal').style.display = 'none';
        }
        
        // Save all logic (iterates inputs or submits form - simplified here to save on demand)
        function saveAllGrades() {
            // In a real app, this might iterate all inputs and save changes
            alert('Automatic saving is enabled on cell change. Use "Validate" to finalize.');
        }

        // Final Validation Logic
        function validateFinalGrades() {
            if (confirm("Valider définitivement les notes ? Cette action est irréversible.")) {
                const formData = new FormData();
                formData.append('csrf_token', csrfToken);
                formData.append('matiere_id', matiereId);
                formData.append('periode_id', periodeId);

                fetch('api/validate_notes.php', {
                    method: 'POST',
                    body: formData
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload();
                    } else {
                        alert('Validation failed: ' + (data.error || 'Unknown error') + (data.details ? '\nSaisies: ' + data.details.saisies + '/' + data.details.attendues : ''));
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('Network error during validation.');
                });
            }
        }

        // Add real-time validation for grade inputs and auto-save on change
        document.addEventListener('DOMContentLoaded', function() {
            // Grade inputs
            const gradeInputs = document.querySelectorAll('.grade-input');
            gradeInputs.forEach(input => {
                input.addEventListener('input', function() {
                    const maxGrade = parseFloat(this.getAttribute('max'));
                    const value = parseFloat(this.value);
                    if (value > maxGrade) this.value = maxGrade;
                    if (value < 0) this.value = 0;
                });
                
                input.addEventListener('change', function() {
                    // Extract IDs from name="grades[etudiant_id][colonne_id]"
                    const name = this.name;
                    const matches = name.match(/grades\[(\d+)\]\[(\d+)\]/);
                    if (matches) {
                        const etudiantId = matches[1];
                        const colonneId = matches[2];
                        saveGrade(etudiantId, colonneId, this.value);
                    }
                });
            });

            // Status selects
            const statusSelects = document.querySelectorAll('.status-select');
            statusSelects.forEach(select => {
                select.addEventListener('change', function() {
                    const name = this.name;
                    const matches = name.match(/status\[(\d+)\]\[(\d+)\]/);
                    if (matches) {
                        const etudiantId = matches[1];
                        const colonneId = matches[2];
                        // Find corresponding grade input
                        const gradeInput = document.querySelector(`input[name="grades[${etudiantId}][${colonneId}]"]`);
                        const gradeVal = gradeInput ? gradeInput.value : '';
                        
                        // If status is not normal (empty), we might want to clear grade or keep it?
                        // The API handles status priority over value.
                        saveGrade(etudiantId, colonneId, gradeVal, this.value);
                    }
                });
            });
        });
    </script>
</body>
</html>
