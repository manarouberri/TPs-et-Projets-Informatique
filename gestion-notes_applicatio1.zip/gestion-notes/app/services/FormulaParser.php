<?php
class InvalidFormulaException extends Exception {}
class FormulaParser {
    private $operateurs = ['+', '-', '*', '/', '(', ')', ','];
    private $fonctions = ['MAX', 'MIN', 'MOYENNE', 'SI', 'ABS'];
    public function evaluer($formule, $valeurs) {
        if (!$this->validerFormule($formule)) {
            throw new InvalidFormulaException('Formule invalide');
        }
        $expression = $this->substituerVariables($formule, $valeurs);
        $tokens = $this->tokenize($expression);
        $rpn = $this->versRPN($tokens);
        return $this->evaluerRPN($rpn);
    }
    public function validerFormule($formule) {
        $pattern = '/^[A-Za-z0-9_+\-*\/().,%\s]+$/';
        if (!preg_match($pattern, $formule)) {
            return false;
        }
        $compteur = 0;
        $chars = str_split($formule);
        foreach ($chars as $char) {
            if ($char === '(') $compteur++;
            if ($char === ')') { $compteur--; if ($compteur < 0) return false; }
        }
        if ($compteur !== 0) return false;
        $tokens = $this->tokenize($formule);
        foreach ($tokens as $t) {
            if (is_array($t)) continue;
            if (is_numeric($t)) continue;
            if ($t === null) continue;
            if (in_array($t, ['+', '-', '*', '/', '(', ')', ','], true)) continue;
            if (preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $t)) continue;
            return false;
        }
        return true;
    }
    public function substituerVariables($formule, $valeurs) {
        foreach ($valeurs as $nom => $valeur) {
            if ($valeur === 'ABS' || $valeur === null) {
                $valeur = 'NULL';
            }
            $formule = preg_replace('/\b' . preg_quote((string)$nom, '/') . '\b/', (string)$valeur, $formule);
        }
        return $formule;
    }
    private function tokenize($expression) {
        $tokens = [];
        $i = 0;
        $len = strlen($expression);
        while ($i < $len) {
            $ch = $expression[$i];
            if (ctype_space($ch)) { $i++; continue; }
            if (ctype_digit($ch) || ($ch === '.' && $i+1<$len && ctype_digit($expression[$i+1]))) {
                $start = $i;
                $i++;
                while ($i < $len && (ctype_digit($expression[$i]) || $expression[$i] === '.')) $i++;
                $num = substr($expression, $start, $i - $start);
                $tokens[] = (float)$num;
                continue;
            }
            if (ctype_alpha($ch) || $ch === '_') {
                $start = $i;
                $i++;
                while ($i < $len && (ctype_alnum($expression[$i]) || $expression[$i] === '_')) $i++;
                $ident = substr($expression, $start, $i - $start);
                $tokens[] = $ident;
                continue;
            }
            if (in_array($ch, ['+', '-', '*', '/', '(', ')', ','], true)) {
                $tokens[] = $ch;
                $i++;
                continue;
            }
            throw new InvalidFormulaException('Caractère invalide');
        }
        return $tokens;
    }
    private function versRPN($tokens) {
        $precedence = ['+' => 1, '-' => 1, '*' => 2, '/' => 2];
        $output = [];
        $stack = [];
        $funcStack = [];
        for ($i = 0; $i < count($tokens); $i++) {
            $t = $tokens[$i];
            if (is_float($t) || $t === null || $t === 'NULL') {
                $output[] = $t === 'NULL' ? null : $t;
                continue;
            }
            if (is_string($t) && preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $t)) {
                $next = $tokens[$i+1] ?? null;
                if (in_array($t, $this->fonctions, true) && $next === '(') {
                    $stack[] = $t;
                    $funcStack[] = ['name' => $t, 'args' => 1];
                    continue;
                }
                $output[] = $t;
                continue;
            }
            if ($t === ',') {
                while (!empty($stack) && end($stack) !== '(') {
                    $output[] = array_pop($stack);
                }
                if (!empty($funcStack)) {
                    $funcStack[count($funcStack)-1]['args']++;
                }
                continue;
            }
            if ($t === '(') {
                $stack[] = $t;
                continue;
            }
            if ($t === ')') {
                while (!empty($stack) && end($stack) !== '(') {
                    $output[] = array_pop($stack);
                }
                if (empty($stack)) throw new InvalidFormulaException('Parenthèses invalides');
                array_pop($stack);
                if (!empty($stack) && in_array(end($stack), $this->fonctions, true)) {
                    $funcName = array_pop($stack);
                    $funcInfo = array_pop($funcStack);
                    $output[] = ['type' => 'FUNC', 'name' => $funcName, 'argc' => $funcInfo['args']];
                }
                continue;
            }
            if (in_array($t, ['+', '-', '*', '/'], true)) {
                while (!empty($stack)) {
                    $top = end($stack);
                    if (in_array($top, ['+', '-', '*', '/'], true) && $precedence[$top] >= $precedence[$t]) {
                        $output[] = array_pop($stack);
                    } else {
                        break;
                    }
                }
                $stack[] = $t;
                continue;
            }
            throw new InvalidFormulaException('Token invalide');
        }
        while (!empty($stack)) {
            $top = array_pop($stack);
            if ($top === '(' || $top === ')') throw new InvalidFormulaException('Parenthèses invalides');
            $output[] = $top;
        }
        return $output;
    }
    private function evaluerRPN($rpn) {
        $stack = [];
        foreach ($rpn as $t) {
            if (is_float($t) || $t === null) {
                $stack[] = $t;
                continue;
            }
            if (is_string($t) && preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $t)) {
                $stack[] = null;
                continue;
            }
            if (is_string($t) && in_array($t, ['+', '-', '*', '/'], true)) {
                $b = array_pop($stack);
                $a = array_pop($stack);
                if ($a === null || $b === null) { $stack[] = null; continue; }
                if ($t === '+') $stack[] = $a + $b;
                elseif ($t === '-') $stack[] = $a - $b;
                elseif ($t === '*') $stack[] = $a * $b;
                elseif ($t === '/') { if ((float)$b === 0.0) { $stack[] = null; } else { $stack[] = $a / $b; } }
                continue;
            }
            if (is_array($t) && $t['type'] === 'FUNC') {
                $argc = (int)$t['argc'];
                $args = [];
                for ($i = 0; $i < $argc; $i++) {
                    $args[] = array_pop($stack);
                }
                $args = array_reverse($args);
                if ($t['name'] === 'ABS') {
                    $v = $args[0];
                    $stack[] = $v === null ? null : abs($v);
                } elseif ($t['name'] === 'MAX') {
                    $vals = array_filter($args, function($v){ return $v !== null; });
                    $stack[] = empty($vals) ? null : max($vals);
                } elseif ($t['name'] === 'MIN') {
                    $vals = array_filter($args, function($v){ return $v !== null; });
                    $stack[] = empty($vals) ? null : min($vals);
                } elseif ($t['name'] === 'MOYENNE') {
                    $vals = array_filter($args, function($v){ return $v !== null; });
                    $stack[] = empty($vals) ? null : array_sum($vals) / count($vals);
                } elseif ($t['name'] === 'SI') {
                    $cond = $args[0];
                    $stack[] = ($cond !== null && (float)$cond != 0.0) ? $args[1] : $args[2];
                } else {
                    throw new InvalidFormulaException('Fonction inconnue');
                }
                continue;
            }
            throw new InvalidFormulaException('Token RPN invalide');
        }
        if (count($stack) !== 1) throw new InvalidFormulaException('Expression invalide');
        return $stack[0];
    }
}
