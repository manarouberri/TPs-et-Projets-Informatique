<?php
require_once __DIR__ . '/FormulaEvaluator.php';
require_once __DIR__ . '/../config/database.php';
class CalculMoyenneService {
    private $pdo;
    private $evaluator;
    public function __construct() {
        $this->pdo = get_pdo();
        $this->evaluator = new FormulaEvaluator();
    }
    public function calculerPourMatierePeriode($matiereId, $periodeId) {
        $formule = $this->evaluator->getFormule($matiereId, $periodeId);
        if (!$formule) return ['count' => 0];
        $st = $this->pdo->prepare("SELECT im.etudiant_id FROM inscriptions_matieres im WHERE im.matiere_id = ? AND im.periode_id = ? AND im.dispense = 0");
        $st->execute([$matiereId, $periodeId]);
        $etudiants = array_map(function($r){ return (int)$r['etudiant_id']; }, $st->fetchAll());
        $done = 0;
        foreach ($etudiants as $etudiantId) {
            $moy = $this->evaluator->evaluerPourEtudiant($etudiantId, $matiereId, $periodeId);
            if ($moy === null) continue;
            $ins = $this->pdo->prepare("INSERT INTO moyennes (etudiant_id, matiere_id, periode_id, valeur, date_calcul) VALUES (?, ?, ?, ?, NOW()) ON DUPLICATE KEY UPDATE valeur = VALUES(valeur), date_calcul = NOW()");
            try {
                $ins->execute([$etudiantId, $matiereId, $periodeId, $moy]);
                $done++;
            } catch (Throwable $e) { }
        }
        return ['count' => $done];
    }
}
