<?php
require_once __DIR__ . '/FormulaParser.php';
require_once __DIR__ . '/../config/database.php';
class FormulaEvaluator {
    private $pdo;
    private $parser;
    public function __construct() {
        $this->pdo = get_pdo();
        $this->parser = new FormulaParser();
    }
    public function getFormule($matiereId, $periodeId) {
        $st = $this->pdo->prepare("SELECT formule FROM formules WHERE matiere_id = ? AND periode_id = ?");
        $st->execute([$matiereId, $periodeId]);
        $row = $st->fetch();
        return $row ? $row['formule'] : null;
    }
    public function getCodes($matiereId, $periodeId) {
        $st = $this->pdo->prepare("SELECT code_colonne FROM configuration_colonnes WHERE matiere_id = ? AND periode_id = ? ORDER BY ordre");
        $st->execute([$matiereId, $periodeId]);
        return array_map(function($r){ return $r['code_colonne']; }, $st->fetchAll());
    }
    public function getNotesPourEtudiant($etudiantId, $matiereId, $periodeId) {
        $sql = "SELECT cc.code_colonne AS code, n.valeur, n.statut 
                FROM configuration_colonnes cc 
                LEFT JOIN notes n ON n.colonne_id = cc.id AND n.etudiant_id = ? 
                WHERE cc.matiere_id = ? AND cc.periode_id = ? 
                ORDER BY cc.ordre";
        $st = $this->pdo->prepare($sql);
        $st->execute([$etudiantId, $matiereId, $periodeId]);
        $vals = [];
        foreach ($st->fetchAll() as $r) {
            if ($r['statut'] === 'absent' || $r['statut'] === 'dispense' || $r['statut'] === 'defaillant') {
                $vals[$r['code']] = null;
            } else {
                $vals[$r['code']] = isset($r['valeur']) ? (float)$r['valeur'] : null;
            }
        }
        return $vals;
    }
    public function evaluerPourEtudiant($etudiantId, $matiereId, $periodeId) {
        $formule = $this->getFormule($matiereId, $periodeId);
        if (!$formule) return null;
        if (!$this->parser->validerFormule($formule)) return null;
        $vals = $this->getNotesPourEtudiant($etudiantId, $matiereId, $periodeId);
        return $this->parser->evaluer($formule, $vals);
    }
}
