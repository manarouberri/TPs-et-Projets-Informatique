<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../config/database.php';
function require_professor(): void {
    if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] ?? '') !== 'professeur') {
        header('Location: /gestion-notes/public/login.php');
        exit();
    }
}
function require_admin(): void {
    if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] ?? '') !== 'admin') {
        header('Location: /gestion-notes/public/login.php');
        exit();
    }
}
function require_etudiant(): void {
    if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] ?? '') !== 'etudiant') {
        header('Location: /gestion-notes/public/login.php');
        exit();
    }
}
$pdo = get_pdo();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
