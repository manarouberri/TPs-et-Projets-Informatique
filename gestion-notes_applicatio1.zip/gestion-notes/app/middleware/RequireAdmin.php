<?php
session_start();
function require_admin(): void {
    if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] ?? '') !== 'admin') {
        http_response_code(403);
        exit('Accès administrateur requis');
    }
}
