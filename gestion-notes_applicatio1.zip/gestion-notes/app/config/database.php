<?php
declare(strict_types=1);

function get_pdo(): PDO {
    $host = getenv('DB_HOST') ?: 'localhost';
    $db   = getenv('DB_NAME') ?: 'gestion_notes';
    $user = getenv('DB_USER') ?: 'root';
    $pass = getenv('DB_PASS') ?: 'root';
    $port = getenv('DB_PORT') ?: '3306';
    $charset = 'utf8mb4';
    $dsn = "mysql:host={$host};port={$port};dbname={$db};charset={$charset}";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    try {
        return new PDO($dsn, $user, $pass, $options);
    } catch (PDOException $e) {
        $candidates = [];
        $candidates[] = [$host, '3306', $user, $pass];
        $candidates[] = [$host, '8889', $user, $pass];
        $candidates[] = [$host, $port, $user, ''];
        foreach ($candidates as [$h, $p, $u, $pw]) {
            try {
                $dsn2 = "mysql:host={$h};port={$p};dbname={$db};charset={$charset}";
                return new PDO($dsn2, $u, $pw, $options);
            } catch (PDOException $e2) {
            }
        }
        http_response_code(500);
        exit('Database connection error');
    }
}
