# 🌐 TP1 — Formulaires HTML

Un petit projet HTML5 simple pour pratiquer la création de **formulaires** (connexion + commentaire).

## 🧠 Objectifs
- Comprendre la structure d’un formulaire HTML5  
- Utiliser les attributs `required`, `maxlength`, `placeholder`, etc.  
- Améliorer la présentation avec un peu de **CSS moderne**

## 🖼️ Aperçu
![Screenshot](https://via.placeholder.com/720x400.png?text=Formulaire+HTML5)

## 💻 Contenu
- `index.html` : page principale avec deux formulaires  
## 👩‍💻 Auteur
Projet réalisé par **Manar ouberri** 🧠
