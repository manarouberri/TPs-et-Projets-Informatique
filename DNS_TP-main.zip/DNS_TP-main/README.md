# 🖥️ Serveur DNS BIND9 - Installation & Rapport LaTex

## 📋 Table des Matières
- [Description](#-description)
- [Fonctionnalités](#-fonctionnalités)
- [Installation](#-installation)
- [Utilisation](#-utilisation)
- [Structure du Projet](#-structure-du-projet)
- [Capture d'Écran](#-capture-décran)
- [Contribution](#-contribution)
- [Licence](#-licence)
- [Auteur](#-auteur)

## 🎯 Description
Projet complet d'installation et configuration d'un serveur DNS BIND9 sous Linux Ubuntu, accompagné d'un rapport professionnel rédigé en LaTeX. Ce projet a été réalisé dans le cadre d'un cours d'administration système.

## ✨ Fonctionnalités
- ✅ Installation automatisée de BIND9
- ✅ Configuration DNS complète (zones directes/inverses)
- ✅ Tests de validation avec dig, nslookup, host
- ✅ Scripts d'automatisation
- ✅ Rapport LaTeX professionnel avec :
  - Mise en page colorée et moderne
  - Code source syntaxiquement coloré
  - Tableaux et figures organisés
  - Annexes techniques complètes
- ✅ Documentation exhaustive

## 🚀 Installation

### Prérequis
```bash
# Système d'exploitation
Ubuntu 22.04 LTS ou supérieur

# Paquets nécessaires
sudo apt update
sudo apt install -y git bind9 bind9utils texlive-latex-base make
Cloner le dépôt
bash
git clone https://github.com/manaroberri/dns-bind9-project.git
cd dns-bind9-project
Installation du serveur DNS
bash
# Exécuter le script d'installation
chmod +x scripts/install-dns.sh
sudo ./scripts/install-dns.sh
📖 Utilisation
Configuration du DNS
bash
# Vérifier la configuration
sudo named-checkconf

# Redémarrer BIND9
sudo systemctl restart bind9

# Tester le DNS
dig @localhost www.entreprise.local
Génération du rapport PDF
bash
# Compilation LaTeX
make pdf

# Ou manuellement
pdflatex -shell-escape rapport-dns.tex
pdflatex -shell-escape rapport-dns.tex
Commandes Make disponibles
bash
make          # Compile tout
make pdf      # Génère le PDF
make clean    # Nettoie les fichiers temporaires
make view     # Ouvre le PDF
make all      # Compile et ouvre
📁 Structure du Projet
text
dns-bind9-project/
├── 📄 README.md                    # Ce fichier
├── 📄 rapport-dns.tex              # Document LaTeX principal
├── 🖼️ images/                     # Dossier des images
│   ├── bind9-status.png           # Capture d'écran principale
│   └── dns-architecture.png       # Schéma d'architecture
├── 📁 scripts/                     # Scripts d'automatisation
│   ├── install-dns.sh             # Installation BIND9
│   ├── configure-zones.sh         # Configuration DNS
│   └── test-dns.sh               # Tests de validation
├── 📁 config/                      # Fichiers de configuration
│   ├── named.conf.options        # Configuration BIND9
│   ├── db.entreprise.local       # Zone DNS directe
│   └── db.192.168.1              # Zone DNS inverse
├
read.ma simple et profissioneele
markdown
# 🖥️ DNS BIND9 - Installation & Rapport LaTeX

![Linux](https://img.shields.io/badge/Ubuntu-22.04_LTS-E95420?logo=ubuntu&logoColor=white)
![BIND9](https://img.shields.io/badge/BIND9-9.18-FF6C37)
![LaTeX](https://img.shields.io/badge/LaTeX-Professional-008080?logo=latex)
![License](https://img.shields.io/badge/License-MIT-blue.svg)

## 📋 Description
Projet d'installation d'un serveur DNS BIND9 sous Linux avec rapport technique en LaTeX. Réalisé par **Manar Oberri** pour un cours d'administration système.

## ✨ Fonctionnalités
- ✅ Installation automatisée BIND9
- ✅ Configuration DNS complète
- ✅ Tests de validation
- ✅ Rapport LaTeX professionnel
- ✅ Scripts d'automatisation

## 🚀 Installation Rapide
```bash
# Cloner le projet
git clone https://github.com/manaroberri/dns-bind9-project.git
cd dns-bind9-project

# Installer BIND9
sudo ./scripts/install.sh

# Générer le rapport
make pdf
📖 Utilisation
Configurer le DNS
bash
sudo systemctl restart bind9
dig @localhost www.entreprise.local
Générer le PDF
bash
# Avec Make
make all

# Manuellement
pdflatex rapport-dns.tex
pdflatex rapport-dns.tex
📁 Structure
text
dns-bind9-project/
├── rapport-dns.tex      # Rapport principal
├── images/              # Captures d'écran
├── scripts/             # Scripts d'installation
├── config/              # Configurations DNS
├── Makefile            # Automatisation
└── rapport-dns.pdf     # PDF généré
🛠️ Commandes Utiles
bash
# Vérifier le service
sudo systemctl status bind9

# Tester le DNS
dig @192.168.1.10 www.entreprise.local

# Vérifier la configuration
sudo named-checkconf
📸 Capture d'Écran
https://images/bind9-status.png

📄 Rapport LaTeX
Le rapport inclut :

Installation détaillée

Configuration complète

Tests de validation

Dépannage

Annexes techniques

👤 Auteur
Manar Oberri 
