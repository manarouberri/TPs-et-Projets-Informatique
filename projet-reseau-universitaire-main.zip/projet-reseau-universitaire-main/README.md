# Architecture Réseau Universitaire uemf Fès

## Description
Conception complète d'un réseau universitaire avec adressage IP, VLANs et services.

## Fichiers du projet
- **📄 [adressage-IP.docx](documentation/adressage-IP.docx)** - Tableaux d'adressage
- **📕 [rapport-reseaux.pdf](documentation/manarOuberri-rapport-reseaux.pdf)** - Rapport complet
- **🌐 [topologie.pkt](schemas/topologie.pkt)** - Schéma Cisco Packet Tracer

## Structure réseau
- **Réseau principal** : 192.168.20.0/24
- **Site serveur** : 192.168.21.0/28
- **5 départements** : ADM, EIDIA, FM, FP, BSIT

## Technologies
- Cisco Packet Tracer
- VLANs et sous-réseaux
- Services DHCP/DNS/Web
- Routage inter-VLAN

## Auteurs
- Manar OUBERRI (Étudiant)
- Ahmed AMAMOU (Encadrant)

Année : 2023-2024
