<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';

function auth_user(): ?array {
  return $_SESSION['user'] ?? null;
}

function require_login(): void {
  if (!auth_user()) {
    redirect('index.php?page=login');
  }
}

function require_role(string $role): void {
  $u = auth_user();
  if (!$u || ($u['role'] ?? '') !== $role) {
    http_response_code(403);
    exit('Accès interdit');
  }
}

function login(string $email, string $password): bool {
  $pdo = db();

  $stmt = $pdo->prepare("SELECT id, nom, prenom, email, password_hash, role, actif FROM utilisateurs WHERE email=? LIMIT 1");
  $stmt->execute([$email]);
  $u = $stmt->fetch(PDO::FETCH_ASSOC);

  if (!$u) return false;
  if ((int)$u['actif'] !== 1) return false;

  if (!password_verify($password, (string)$u['password_hash'])) {
    return false;
  }

  $_SESSION['user'] = [
    'id' => (int)$u['id'],
    'nom' => (string)$u['nom'],
    'prenom' => (string)$u['prenom'],
    'email' => (string)$u['email'],
    'role' => (string)$u['role'],
  ];

  return true;
}

function logout(): void {
  unset($_SESSION['user']);
  session_regenerate_id(true);
}
