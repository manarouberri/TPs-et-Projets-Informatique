<?php
declare(strict_types=1);

ini_set('display_errors', '1');
error_reporting(E_ALL);

define('DB_HOST', '127.0.0.1');   // pas "localhost"
define('DB_PORT', '8889');        // <-- METS ICI le port MySQL vu dans MAMP
define('DB_NAME', 'application_notes');   // <-- le nom exact de ta base dans phpMyAdmin
define('DB_USER', 'root');
define('DB_PASS', 'root');        // sur MAMP Windows: root / root (souvent)
