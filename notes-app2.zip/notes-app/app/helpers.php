<?php
declare(strict_types=1);

function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

function redirect(string $url): never {
  header("Location: $url");
  exit;
}

function nowMysql(): string {
  return (new DateTimeImmutable('now'))->format('Y-m-d H:i:s');
}
