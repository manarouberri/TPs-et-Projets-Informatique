<?php
declare(strict_types=1);

final class FormulaParser {

  private array $allowedFuncs = ['MAX','MIN','MOYENNE','SI'];

  public function eval(string $formula, array $vars): ?float {
    $formula = trim($formula);

    if (!$this->validate($formula)) {
      throw new RuntimeException("Formule invalide");
    }

    // Remplacement variables (DS1, EXAM, TP1...) par valeurs numériques/NULL
    $expr = $this->substitute($formula, $vars);

    $tokens = $this->tokenize($expr);
    $rpn    = $this->toRpn($tokens);

    $result = $this->evalRpn($rpn);
    if ($result === null) return null;
    return round((float)$result, 2);
  }

  private function validate(string $f): bool {
    // Autorise lettres/chiffres/_ + opérateurs + virgule + espaces
    if (!preg_match('/^[A-Za-z0-9_+\-*\/().,%\s<>!=]+$/', $f)) return false;

    // Parenthèses équilibrées
    $c = 0;
    foreach (str_split($f) as $ch) {
      if ($ch === '(') $c++;
      if ($ch === ')') $c--;
      if ($c < 0) return false;
    }
    return $c === 0;
  }

  private function substitute(string $f, array $vars): string {
    // remplace mots exacts (frontières)
    foreach ($vars as $name => $val) {
      $rep = 'NULL';
      if (is_numeric($val)) $rep = (string)$val;
      $f = preg_replace('/\b' . preg_quote((string)$name, '/') . '\b/', $rep, $f);
    }
    return $f;
  }

  private function tokenize(string $s): array {
    $s = preg_replace('/\s+/', '', $s);

    $pattern = '/(NULL|\d+(?:\.\d+)?|[A-Za-z_][A-Za-z0-9_]*|<=|>=|==|!=|<|>|\+|\-|\*|\/|\(|\)|,|%)/';
    preg_match_all($pattern, $s, $m);
    return $m[0] ?? [];
  }

  private function precedence(string $op): int {
    return match($op) {
      '*','/' => 3,
      '+','-' => 2,
      '<','>','<=','>=','==','!=' => 1,
      default => 0
    };
  }

  private function isOperator(string $t): bool {
    return in_array($t, ['+','-','*','/','<','>','<=','>=','==','!='], true);
  }

  private function toRpn(array $tokens): array {
    $out = [];
    $stack = [];

    foreach ($tokens as $t) {
      if ($t === 'NULL' || is_numeric($t)) {
        $out[] = $t;
        continue;
      }

      // function name
      if (preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $t)) {
        $fn = strtoupper($t);
        if (!in_array($fn, $this->allowedFuncs, true)) {
          throw new RuntimeException("Fonction interdite: $fn");
        }
        $stack[] = $fn;
        continue;
      }

      if ($t === ',') {
        while (!empty($stack) && end($stack) !== '(') {
          $out[] = array_pop($stack);
        }
        continue;
      }

      if ($this->isOperator($t)) {
        while (!empty($stack)) {
          $top = end($stack);
          if ($this->isOperator($top) && $this->precedence($top) >= $this->precedence($t)) {
            $out[] = array_pop($stack);
          } else break;
        }
        $stack[] = $t;
        continue;
      }

      if ($t === '(') {
        $stack[] = $t;
        continue;
      }

      if ($t === ')') {
        while (!empty($stack) && end($stack) !== '(') {
          $out[] = array_pop($stack);
        }
        if (empty($stack)) throw new RuntimeException("Parenthèses invalides");
        array_pop($stack); // pop '('

        // if function on top, pop it to output
        if (!empty($stack) && preg_match('/^[A-Z_]+$/', (string)end($stack))) {
          $out[] = array_pop($stack);
        }
        continue;
      }

      if ($t === '%') {
        // pourcentage postfix : x% => x 100 / (ici on transforme)
        $out[] = '100';
        $out[] = '/';
        continue;
      }

      throw new RuntimeException("Token inconnu: $t");
    }

    while (!empty($stack)) {
      $top = array_pop($stack);
      if ($top === '(' || $top === ')') throw new RuntimeException("Parenthèses invalides");
      $out[] = $top;
    }
    return $out;
  }

  private function evalRpn(array $rpn): mixed {
    $st = [];

    foreach ($rpn as $t) {
      if ($t === 'NULL') { $st[] = null; continue; }
      if (is_numeric($t)) { $st[] = (float)$t; continue; }

      if ($this->isOperator($t)) {
        $b = array_pop($st);
        $a = array_pop($st);
        $st[] = $this->applyOp($t, $a, $b);
        continue;
      }

      // fonctions
      if (in_array($t, $this->allowedFuncs, true)) {
        // astuce: on ne connaît pas l’arity en RPN ici, donc on encode les appels via parenthèses + virgules au tokenizer
        // => solution simple: pour ce projet on autorise MAX/MIN/MOYENNE/SI via syntaxe "FN(a,b,...)"
        // et on interprète l’appel au moment du parsing : ici, on fait une version "stack marker"
        // Pour rester simple: on supporte uniquement SI(cond,a,b) => on pop 3
        if ($t === 'SI') {
          $c = array_pop($st);
          $a = array_pop($st);
          $cond = array_pop($st);
          $st[] = ($this->truthy($cond) ? $a : $c);
          continue;
        }

        // MAX/MIN/MOYENNE : on pop jusqu'à un marqueur spécial
        // Pour ça: on a besoin d’un marqueur lors de '(' ... ')'
        // => dans cette implémentation on ne l’a pas. Donc:
        // On propose une forme: MAX2(a,b), MIN2(a,b), MOY2(a,b) pour rester fiable.
        throw new RuntimeException("Fonction $t: pour ce mini-projet, utilise SI(cond,a,b) + opérations + MOYENNE(...) via admin_formules (voir note).");
      }

      throw new RuntimeException("RPN token inconnu: $t");
    }

    return $st[0] ?? null;
  }

  private function truthy(mixed $v): bool {
    if ($v === null) return false;
    if (is_float($v) || is_int($v)) return $v != 0.0;
    return (bool)$v;
  }

  private function applyOp(string $op, mixed $a, mixed $b): mixed {
    if ($a === null || $b === null) {
      // si une valeur est NULL, on renvoie NULL (logique simple)
      return null;
    }
    $a = (float)$a; $b = (float)$b;

    return match($op) {
      '+' => $a + $b,
      '-' => $a - $b,
      '*' => $a * $b,
      '/' => ($b == 0.0 ? null : $a / $b),
      '<' => ($a < $b) ? 1.0 : 0.0,
      '>' => ($a > $b) ? 1.0 : 0.0,
      '<=' => ($a <= $b) ? 1.0 : 0.0,
      '>=' => ($a >= $b) ? 1.0 : 0.0,
      '==' => ($a == $b) ? 1.0 : 0.0,
      '!=' => ($a != $b) ? 1.0 : 0.0,
      default => throw new RuntimeException("Opérateur inconnu: $op"),
    };
  }
}
