document.addEventListener('DOMContentLoaded', () => {
  // petite mémoire des valeurs précédentes pour rollback si erreur
  const previousValues = new Map();

  document.querySelectorAll('.noteInput').forEach((inp) => {
    // stocker la valeur initiale
    previousValues.set(inp, inp.value);

    // quand l'utilisateur commence à modifier
    inp.addEventListener('focus', () => {
      previousValues.set(inp, inp.value);
    });

    const handler = async () => {
      const etudiantId = inp.dataset.etudiantId;
      const colonneId  = inp.dataset.colonneId;
      const valeur     = inp.value;

      // CSRF token (doit exister dans la page)
      const csrf = document.querySelector('input[name="csrf"]')?.value || '';

      const fd = new FormData();
      fd.append('csrf', csrf);
      fd.append('etudiant_id', etudiantId);
      fd.append('colonne_id', colonneId);
      fd.append('valeur', valeur);

      let r, text, data;

      try {
        r = await fetch('index.php?page=prof_save_note', {
          method: 'POST',
          body: fd,
          credentials: 'same-origin' // ✅ IMPORTANT: garde la session
        });

        text = await r.text();

        try {
          data = JSON.parse(text);
        } catch (e) {
          alert("Réponse serveur NON-JSON (probable erreur PHP ou redirect login):\n\n" + text);
          // rollback valeur
          inp.value = previousValues.get(inp) ?? '';
          return;
        }

      } catch (e) {
        alert("Erreur réseau / serveur (verifie MAMP + URL)");
        // rollback valeur
        inp.value = previousValues.get(inp) ?? '';
        return;
      }

      if (!r.ok || !data.ok) {
        alert("Erreur serveur:\n" + (data?.error || text));
        // rollback valeur
        inp.value = previousValues.get(inp) ?? '';
        return;
      }

      // ✅ Mise à jour moyenne : IMPORTANT il faut que ta cellule HTML ait class="moyCell"
      const cell = document.querySelector(`.moyCell[data-etudiant-id="${etudiantId}"] b`);
      if (cell) {
        cell.textContent = (data.moyenne === null ? '-' : data.moyenne);
      }

      // enregistrer nouvelle valeur comme "précédente"
      previousValues.set(inp, inp.value);
    };

    // déclenchement sur change + blur
    inp.addEventListener('change', handler);
    inp.addEventListener('blur', handler);
  });
});
