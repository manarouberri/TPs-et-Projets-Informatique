<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../app/helpers.php';
require_once __DIR__ . '/../app/auth.php';

$page = $_GET['page'] ?? 'home';
$user = auth_user();

// Pages publiques (sans login)
$publicPages = ['login'];

// Map des pages
$map = [
  'login' => __DIR__ . '/pages/login.php',
  'logout' => __DIR__ . '/pages/logout.php',

  'admin_dashboard' => __DIR__ . '/pages/admin_dashboard.php',
  'admin_periodes' => __DIR__ . '/pages/admin_periodes.php',
  'admin_matieres' => __DIR__ . '/pages/admin_matieres.php',
  'admin_affectations' => __DIR__ . '/pages/admin_affectations.php',
  'admin_config_colonnes' => __DIR__ . '/pages/admin_config_colonnes.php',
  'admin_formules' => __DIR__ . '/pages/admin_formules.php',

  'prof_matieres' => __DIR__ . '/pages/prof_matieres.php',
  'prof_saisie' => __DIR__ . '/pages/prof_saisie.php',
  'prof_save_note' => __DIR__ . '/pages/prof_save_note.php', // ✅ AJAX JSON
  'prof_valider' => __DIR__ . '/pages/prof_valider.php',

  'etu_notes' => __DIR__ . '/pages/etu_notes.php',
];

// ✅ Pages API/AJAX : ne doivent PAS être enveloppées en HTML
$apiPages = [
  'prof_save_note',
];

// Protection login (sauf pages publiques)
if (!in_array($page, $publicPages, true)) {
  if (!$user) redirect('index.php?page=login');
}

// Home redirect selon rôle
if ($page === 'home') {
  if ($user && $user['role'] === 'admin') redirect('index.php?page=admin_dashboard');
  if ($user && $user['role'] === 'professeur') redirect('index.php?page=prof_matieres');
  redirect('index.php?page=etu_notes');
}

$file = $map[$page] ?? null;
if (!$file || !file_exists($file)) {
  http_response_code(404);
  exit('Page not found');
}

// ✅ Si page API => inclure et terminer (pas de layout HTML)
if (in_array($page, $apiPages, true)) {
  require $file;
  exit;
}

?><!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Notes App</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar">
  <div class="brand">📊 Notes App</div>
  <nav>
    <?php if ($user): ?>
      <span class="muted"><?= e($user['prenom'].' '.$user['nom']) ?> (<?= e($user['role']) ?>)</span>
      <a class="btn" href="index.php?page=logout">Déconnexion</a>
    <?php endif; ?>
  </nav>
</header>

<main class="container">
  <?php require $file; ?>
</main>

<script src="assets/app.js"></script>
</body>
</html>
