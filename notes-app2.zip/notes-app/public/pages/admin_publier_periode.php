<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/auth.php';
require_once __DIR__ . '/../../app/helpers.php';
require_once __DIR__ . '/../../app/csrf.php';
require_once __DIR__ . '/../../app/db.php';
require_once __DIR__ . '/../../app/FormulaParser.php';

require_role('admin');

$pdo = db();

function redirect_with_msg(string $url, string $type, string $msg): void {
  $sep = (str_contains($url, '?')) ? '&' : '?';
  header("Location: {$url}{$sep}{$type}=" . urlencode($msg));
  exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  exit('Méthode non autorisée');
}

csrf_check();

$periodeId = (int)($_POST['periode_id'] ?? 0);
if ($periodeId <= 0) {
  redirect_with_msg('index.php?page=admin_periodes', 'err', 'Paramètre période manquant');
}

// Charger période
$st = $pdo->prepare("SELECT id, nom, statut FROM periodes WHERE id=?");
$st->execute([$periodeId]);
$periode = $st->fetch(PDO::FETCH_ASSOC);

if (!$periode) {
  redirect_with_msg('index.php?page=admin_periodes', 'err', 'Période introuvable');
}

if ($periode['statut'] === 'publiee') {
  redirect_with_msg('index.php?page=admin_periodes', 'ok', 'Période déjà publiée');
}

// Recommandé : publier uniquement si fermee
if ($periode['statut'] !== 'fermee') {
  redirect_with_msg(
    'index.php?page=admin_periodes',
    'err',
    "Impossible de publier : la période doit être 'fermee' (statut actuel: {$periode['statut']})"
  );
}

$parser = new FormulaParser();

$pdo->beginTransaction();

try {
  // Matières concernées
  $st = $pdo->prepare("
    SELECT DISTINCT m.id AS matiere_id, m.nom, m.seuil_validation
    FROM matieres m
    JOIN inscriptions_matieres im ON im.matiere_id = m.id
    WHERE im.periode_id = ?
    ORDER BY m.nom ASC
  ");
  $st->execute([$periodeId]);
  $matieres = $st->fetchAll(PDO::FETCH_ASSOC);

  if (!$matieres) {
    throw new Exception("Aucune matière/inscription trouvée pour cette période");
  }

  $totalMaj = 0;
  $totalErr = 0;

  foreach ($matieres as $mat) {
    $matiereId = (int)$mat['matiere_id'];
    $seuil = (float)$mat['seuil_validation'];

    // Formule
    $st = $pdo->prepare("SELECT formule FROM formules WHERE matiere_id=? AND periode_id=? LIMIT 1");
    $st->execute([$matiereId, $periodeId]);
    $rowFormule = $st->fetch(PDO::FETCH_ASSOC);
    if (!$rowFormule) {
      $totalErr++;
      continue;
    }
    $formule = (string)$rowFormule['formule'];

    // Colonnes (id -> code_colonne)
    $st = $pdo->prepare("
      SELECT id, code_colonne
      FROM configuration_colonnes
      WHERE matiere_id=? AND periode_id=?
    ");
    $st->execute([$matiereId, $periodeId]);
    $cols = $st->fetchAll(PDO::FETCH_ASSOC);
    if (!$cols) {
      $totalErr++;
      continue;
    }

    $colIdToCode = [];
    $allowedCodes = [];
    foreach ($cols as $c) {
      $cid = (int)$c['id'];
      $code = (string)$c['code_colonne'];
      $colIdToCode[$cid] = $code;
      $allowedCodes[$code] = true;
    }

    // Étudiants inscrits
    $st = $pdo->prepare("
      SELECT etudiant_id
      FROM inscriptions_matieres
      WHERE matiere_id=? AND periode_id=?
    ");
    $st->execute([$matiereId, $periodeId]);
    $etuList = $st->fetchAll(PDO::FETCH_COLUMN);
    if (!$etuList) continue;

    // Notes en masse
    $placeholders = implode(',', array_fill(0, count($etuList), '?'));
    $params = array_merge([$matiereId, $periodeId], $etuList);

    $sqlNotes = "
      SELECT n.etudiant_id, n.colonne_id, n.valeur, n.statut
      FROM notes n
      JOIN configuration_colonnes c ON c.id = n.colonne_id
      WHERE c.matiere_id = ? AND c.periode_id = ?
        AND n.etudiant_id IN ($placeholders)
    ";
    $st = $pdo->prepare($sqlNotes);
    $st->execute($params);
    $notesRows = $st->fetchAll(PDO::FETCH_ASSOC);

    // Init map valeurs par étudiant
    $etuValues = [];
    foreach ($etuList as $etuId) {
      $etuValues[(int)$etuId] = [];
    }

    foreach ($notesRows as $nr) {
      $etuId = (int)$nr['etudiant_id'];
      $colId = (int)$nr['colonne_id'];
      $statut = (string)$nr['statut'];
      $valeur = $nr['valeur'];

      if (!isset($colIdToCode[$colId])) continue;
      $code = $colIdToCode[$colId];

      // ABS/DIS/DEF => null
      if ($statut !== 'saisie') {
        $etuValues[$etuId][$code] = null;
      } else {
        $etuValues[$etuId][$code] = ($valeur !== null) ? (float)$valeur : null;
      }
    }

    // Assurer existence de toutes variables dans la formule (au moins null)
    foreach ($etuValues as $etuId => $vals) {
      foreach ($allowedCodes as $code => $_) {
        if (!array_key_exists($code, $vals)) $etuValues[$etuId][$code] = null;
      }
    }

    // Calcul + upsert moyennes
    foreach ($etuValues as $etuId => $vals) {
      $moyenne = null;
      $decision = 'en_attente';

      try {
        $result = $parser->evaluer($formule, $vals);
        if ($result !== null) {
          $moyenne = round((float)$result, 2);
          $decision = ($moyenne >= $seuil) ? 'valide' : 'non_valide';
        }
      } catch (Throwable $e) {
        $totalErr++;
        $moyenne = null;
        $decision = 'en_attente';
      }

      $st = $pdo->prepare("
        INSERT INTO moyennes (etudiant_id, matiere_id, periode_id, moyenne, decision, date_calcul)
        VALUES (?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
          moyenne = VALUES(moyenne),
          decision = VALUES(decision),
          date_calcul = NOW()
      ");
      $st->execute([(int)$etuId, $matiereId, $periodeId, $moyenne, $decision]);
      $totalMaj++;
    }
  }

  // Publier période
  $st = $pdo->prepare("UPDATE periodes SET statut='publiee', date_publication=NOW() WHERE id=?");
  $st->execute([$periodeId]);

  $pdo->commit();

  redirect_with_msg(
    'index.php?page=admin_periodes',
    'ok',
    "Période publiée ✅ | Moyennes maj: {$totalMaj} | Erreurs: {$totalErr}"
  );

} catch (Throwable $e) {
  $pdo->rollBack();
  redirect_with_msg('index.php?page=admin_periodes', 'err', 'Erreur publication : '.$e->getMessage());
}
