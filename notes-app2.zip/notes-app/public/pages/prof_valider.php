<?php
// public/pages/prof_valider.php
declare(strict_types=1);

require_once __DIR__ . '/../../app/auth.php';
require_once __DIR__ . '/../../app/helpers.php';
require_once __DIR__ . '/../../app/csrf.php';
require_once __DIR__ . '/../../app/db.php';
require_once __DIR__ . '/../../app/FormulaParser.php';

require_role('professeur');

$pdo = db();
$u = auth_user();
$profId = (int)$u['id'];

function redirect_with_msg(string $pageUrl, string $type, string $msg): void {
  $sep = (str_contains($pageUrl, '?')) ? '&' : '?';
  header("Location: {$pageUrl}{$sep}{$type}=" . urlencode($msg));
  exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  exit('Méthode non autorisée');
}

// ✅ CSRF: ton csrf.php attend POST['csrf']
csrf_check();

$matiereId = (int)($_POST['matiere_id'] ?? 0);
$periodeId = (int)($_POST['periode_id'] ?? 0);

if ($matiereId <= 0 || $periodeId <= 0) {
  redirect_with_msg("index.php?page=prof_matieres", "err", "Paramètres manquants");
}

// 1) Vérifier période ouverte + fenêtre
$st = $pdo->prepare("SELECT statut, date_debut_saisie, date_fin_saisie FROM periodes WHERE id=? LIMIT 1");
$st->execute([$periodeId]);
$periode = $st->fetch();

if (!$periode) {
  redirect_with_msg("index.php?page=prof_matieres", "err", "Période introuvable");
}
if ((string)$periode['statut'] !== 'ouverte') {
  redirect_with_msg("index.php?page=prof_matieres", "err", "La période n'est pas ouverte");
}

$now = new DateTimeImmutable('now');
$d1 = new DateTimeImmutable((string)$periode['date_debut_saisie']);
$d2 = new DateTimeImmutable((string)$periode['date_fin_saisie']);
if ($now < $d1 || $now > $d2) {
  redirect_with_msg("index.php?page=prof_matieres", "err", "Hors fenêtre de saisie");
}

// 2) Vérifier affectation prof
$st = $pdo->prepare("
  SELECT groupe
  FROM affectations_profs
  WHERE professeur_id=? AND matiere_id=? AND periode_id=?
  LIMIT 1
");
$st->execute([$profId, $matiereId, $periodeId]);
$aff = $st->fetch();

if (!$aff) {
  redirect_with_msg("index.php?page=prof_matieres", "err", "Vous n'êtes pas affecté à cette matière");
}
$groupeProf = (string)($aff['groupe'] ?? 'Tous');

// 3) Nombre d'étudiants concernés
if ($groupeProf !== 'Tous') {
  $st = $pdo->prepare("SELECT COUNT(*) FROM inscriptions_matieres WHERE matiere_id=? AND periode_id=? AND groupe=?");
  $st->execute([$matiereId, $periodeId, $groupeProf]);
} else {
  $st = $pdo->prepare("SELECT COUNT(*) FROM inscriptions_matieres WHERE matiere_id=? AND periode_id=?");
  $st->execute([$matiereId, $periodeId]);
}
$totalEtudiants = (int)$st->fetchColumn();

// 4) Colonnes obligatoires
$st = $pdo->prepare("
  SELECT COUNT(*)
  FROM configuration_colonnes
  WHERE matiere_id=? AND periode_id=?
    AND type IN ('note','bonus','malus')
    AND obligatoire=1
");
$st->execute([$matiereId, $periodeId]);
$totalColonnesOblig = (int)$st->fetchColumn();

$totalAttendues = $totalEtudiants * $totalColonnesOblig;

// 5) Notes saisies (ABS/DIS/DEF comptent comme remplies car la ligne existe)
$params = [$matiereId, $periodeId];
$sql = "
  SELECT COUNT(*)
  FROM notes n
  JOIN configuration_colonnes c ON c.id = n.colonne_id
  JOIN inscriptions_matieres im ON im.etudiant_id = n.etudiant_id
  WHERE c.matiere_id = ? AND c.periode_id = ?
    AND c.type IN ('note','bonus','malus')
    AND c.obligatoire = 1
    AND im.matiere_id = c.matiere_id AND im.periode_id = c.periode_id
";
if ($groupeProf !== 'Tous') {
  $sql .= " AND im.groupe = ? ";
  $params[] = $groupeProf;
}
$st = $pdo->prepare($sql);
$st->execute($params);
$notesSaisies = (int)$st->fetchColumn();

$pourcentage = 0.0;
if ($totalAttendues > 0) {
  $pourcentage = round(($notesSaisies / $totalAttendues) * 100, 2);
}

// 6) Refuser si incomplet
if ($totalAttendues > 0 && $notesSaisies < $totalAttendues) {
  $manquantes = $totalAttendues - $notesSaisies;
  redirect_with_msg(
    "index.php?page=prof_saisie&matiere_id={$matiereId}&periode_id={$periodeId}",
    "err",
    "Validation refusée : il manque {$manquantes} note(s) obligatoire(s) ({$pourcentage}%)"
  );
}

// 7) Upsert progression_saisie + (option pro) recalcul moyennes
$pdo->beginTransaction();

try {
  // ---- progression_saisie ----
  $st = $pdo->prepare("
    SELECT id FROM progression_saisie
    WHERE matiere_id=? AND periode_id=? AND professeur_id=?
    LIMIT 1
  ");
  $st->execute([$matiereId, $periodeId, $profId]);
  $progId = $st->fetchColumn();

  if ($progId) {
    $st = $pdo->prepare("
      UPDATE progression_saisie
      SET total_etudiants=?, total_notes_attendues=?, notes_saisies=?, pourcentage=?,
          valide_par_prof=1, date_validation=NOW()
      WHERE id=?
    ");
    $st->execute([$totalEtudiants, $totalAttendues, $notesSaisies, $pourcentage, $progId]);
  } else {
    $st = $pdo->prepare("
      INSERT INTO progression_saisie
        (matiere_id, periode_id, professeur_id, total_etudiants, total_notes_attendues,
         notes_saisies, pourcentage, valide_par_prof, date_validation)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1, NOW())
    ");
    $st->execute([$matiereId, $periodeId, $profId, $totalEtudiants, $totalAttendues, $notesSaisies, $pourcentage]);
  }

  // ---- (Option pro) recalcul des moyennes et sauvegarde dans table moyennes ----
  // Récupérer formule
  $st = $pdo->prepare("SELECT formule FROM formules WHERE matiere_id=? AND periode_id=? LIMIT 1");
  $st->execute([$matiereId, $periodeId]);
  $formRow = $st->fetch();
  $formule = $formRow['formule'] ?? null;

  if ($formule) {
    // Colonnes de cette matière
    $colsStmt = $pdo->prepare("SELECT id, code_colonne FROM configuration_colonnes WHERE matiere_id=? AND periode_id=?");
    $colsStmt->execute([$matiereId, $periodeId]);
    $cols = $colsStmt->fetchAll();
    $colIds = array_map(fn($c) => (int)$c['id'], $cols);

    // Etudiants concernés
    if ($groupeProf !== 'Tous') {
      $st = $pdo->prepare("
        SELECT etudiant_id
        FROM inscriptions_matieres
        WHERE matiere_id=? AND periode_id=? AND groupe=?
      ");
      $st->execute([$matiereId, $periodeId, $groupeProf]);
    } else {
      $st = $pdo->prepare("
        SELECT etudiant_id
        FROM inscriptions_matieres
        WHERE matiere_id=? AND periode_id=?
      ");
      $st->execute([$matiereId, $periodeId]);
    }
    $etudIds = array_map(fn($r) => (int)$r['etudiant_id'], $st->fetchAll());

    $parser = new FormulaParser();

    foreach ($etudIds as $etudiantId) {
      $vars = [];

      if (count($colIds) > 0) {
        $in = implode(',', array_fill(0, count($colIds), '?'));
        $stmt = $pdo->prepare("SELECT colonne_id, valeur, statut FROM notes WHERE etudiant_id=? AND colonne_id IN ($in)");
        $stmt->execute(array_merge([$etudiantId], $colIds));
        $rows = $stmt->fetchAll();

        $map = [];
        foreach ($rows as $r) $map[(int)$r['colonne_id']] = $r;
      } else {
        $map = [];
      }

      foreach ($cols as $c) {
        $cid = (int)$c['id'];
        $code = (string)$c['code_colonne'];
        $r = $map[$cid] ?? null;

        $v = $r ? $r['valeur'] : null;
        $stt = $r ? (string)$r['statut'] : 'saisie';

        if (in_array($stt, ['absent','dispense','defaillant'], true)) $v = null;
        $vars[$code] = ($v === null) ? null : (float)$v;
      }

      $moy = null;
      try {
        $res = $parser->evaluer((string)$formule, $vars);
        $moy = ($res === null) ? null : round((float)$res, 2);
      } catch (Throwable $e) {
        $moy = null;
      }

      $up = $pdo->prepare("
        INSERT INTO moyennes(etudiant_id, matiere_id, periode_id, moyenne, decision)
        VALUES(?,?,?,?, 'en_attente')
        ON DUPLICATE KEY UPDATE
          moyenne=VALUES(moyenne),
          date_calcul=NOW()
      ");
      $up->execute([$etudiantId, $matiereId, $periodeId, $moy]);
    }
  }

  $pdo->commit();
} catch (Throwable $e) {
  $pdo->rollBack();
  redirect_with_msg(
    "index.php?page=prof_saisie&matiere_id={$matiereId}&periode_id={$periodeId}",
    "err",
    "Erreur validation : " . $e->getMessage()
  );
}

redirect_with_msg(
  "index.php?page=prof_saisie&matiere_id={$matiereId}&periode_id={$periodeId}",
  "ok",
  "Saisie validée ✅ ({$pourcentage}%)"
);
