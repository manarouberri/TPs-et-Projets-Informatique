<?php
// public/pages/etu_notes.php
declare(strict_types=1);

require_once __DIR__ . '/../../app/config.php';
require_once __DIR__ . '/../../app/db.php';
require_once __DIR__ . '/../../app/auth.php';

require_login();
require_role('etudiant');

$pdo = db();
$etuId = (int)($_SESSION['user']['id'] ?? 0);

// 1) Liste des périodes publiées
$periodes = $pdo->query("
    SELECT id, nom, annee_universitaire, type, date_publication
    FROM periodes
    WHERE statut = 'publiee'
    ORDER BY date_publication DESC
")->fetchAll(PDO::FETCH_ASSOC);

$periodeId = (int)($_GET['periode_id'] ?? 0);

// Si aucune période choisie, prendre la plus récente publiée
if ($periodeId <= 0 && count($periodes) > 0) {
    $periodeId = (int)$periodes[0]['id'];
}

// Vérifier que la période choisie est publiée
$st = $pdo->prepare("SELECT id, nom, date_publication
                     FROM periodes
                     WHERE id=? AND statut='publiee'");
$st->execute([$periodeId]);
$periode = $st->fetch(PDO::FETCH_ASSOC);

?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Mes notes</title>
  <link rel="stylesheet" href="../assets/style.css">
  <style>
    .wrap{max-width:1100px;margin:20px auto;padding:0 12px;}
    .card{background:#fff;border:1px solid #e5e5e5;border-radius:10px;padding:14px;margin:12px 0;}
    .row{display:flex;gap:12px;flex-wrap:wrap;align-items:center;}
    table{width:100%;border-collapse:collapse}
    th,td{border:1px solid #ddd;padding:8px;font-size:14px}
    th{background:#f7f7f7}
    .muted{color:#666}
    .badge{display:inline-block;padding:4px 8px;border-radius:999px;background:#f2f2f2;font-size:12px}
  </style>
</head>
<body>
<div class="wrap">
  <h2>📊 Mes notes</h2>

  <?php if (!$periode): ?>
    <div class="card">
      <p class="muted">Aucune période publiée disponible pour le moment.</p>
    </div>
  <?php exit; endif; ?>

  <div class="card">
    <div class="row">
      <div>
        <strong>Période :</strong>
        <span class="badge"><?= htmlspecialchars($periode['nom']) ?></span>
      </div>

      <form method="get" style="margin-left:auto;">
        <label class="muted">Changer période :</label>
        <select name="periode_id" onchange="this.form.submit()">
          <?php foreach ($periodes as $p): ?>
            <option value="<?= (int)$p['id'] ?>" <?= ((int)$p['id'] === $periodeId) ? 'selected' : '' ?>>
              <?= htmlspecialchars($p['nom']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </form>
    </div>
  </div>

  <?php
  // 2) Récupérer matières où l’étudiant est inscrit sur cette période
  $st = $pdo->prepare("
      SELECT m.id, m.code, m.nom, m.coefficient, m.credits, m.seuil_validation
      FROM inscriptions_matieres im
      JOIN matieres m ON m.id = im.matiere_id
      WHERE im.etudiant_id = ? AND im.periode_id = ?
      ORDER BY m.nom ASC
  ");
  $st->execute([$etuId, $periodeId]);
  $matieres = $st->fetchAll(PDO::FETCH_ASSOC);

  if (!$matieres):
  ?>
    <div class="card">
      <p class="muted">Aucune inscription trouvée pour cette période.</p>
    </div>
  <?php else: ?>

    <?php foreach ($matieres as $mat): ?>
      <?php
      $matiereId = (int)$mat['id'];

      // 3) Colonnes dynamiques
      $st = $pdo->prepare("
          SELECT id, nom_colonne, code_colonne, type, note_max, coefficient, ordre
          FROM configuration_colonnes
          WHERE matiere_id=? AND periode_id=?
          ORDER BY ordre ASC
      ");
      $st->execute([$matiereId, $periodeId]);
      $cols = $st->fetchAll(PDO::FETCH_ASSOC);

      // 4) Notes de l’étudiant pour ces colonnes
      // On map par colonne_id
      $st = $pdo->prepare("
          SELECT colonne_id, valeur, statut
          FROM notes
          WHERE etudiant_id = ?
            AND colonne_id IN (
              SELECT id FROM configuration_colonnes WHERE matiere_id=? AND periode_id=?
            )
      ");
      $st->execute([$etuId, $matiereId, $periodeId]);
      $rows = $st->fetchAll(PDO::FETCH_ASSOC);

      $notesMap = [];
      foreach ($rows as $r) {
        $notesMap[(int)$r['colonne_id']] = $r;
      }

      // 5) Moyenne calculée (si tu remplis table moyennes au moment publication)
      $st = $pdo->prepare("
          SELECT moyenne, decision
          FROM moyennes
          WHERE etudiant_id=? AND matiere_id=? AND periode_id=?
          LIMIT 1
      ");
      $st->execute([$etuId, $matiereId, $periodeId]);
      $moy = $st->fetch(PDO::FETCH_ASSOC);

      $moyenne = $moy['moyenne'] ?? null;
      $decision = $moy['decision'] ?? 'en_attente';

      ?>
      <div class="card">
        <div class="row">
          <div>
            <h3 style="margin:0;"><?= htmlspecialchars($mat['nom']) ?> <span class="muted">(<?= htmlspecialchars($mat['code']) ?>)</span></h3>
            <div class="muted">
              Coef: <?= htmlspecialchars((string)$mat['coefficient']) ?> |
              Crédit: <?= htmlspecialchars((string)($mat['credits'] ?? '-')) ?> |
              Seuil: <?= htmlspecialchars((string)$mat['seuil_validation']) ?>
            </div>
          </div>

          <div style="margin-left:auto;text-align:right;">
            <div><strong>Moyenne :</strong> <?= ($moyenne !== null) ? htmlspecialchars((string)$moyenne) : '<span class="muted">N/A</span>' ?></div>
            <div class="muted">Décision : <?= htmlspecialchars($decision) ?></div>
          </div>
        </div>

        <div style="overflow:auto;margin-top:10px;">
          <table>
            <thead>
              <tr>
                <?php foreach ($cols as $c): ?>
                  <th>
                    <?= htmlspecialchars($c['nom_colonne']) ?>
                    <div class="muted" style="font-weight:normal;">
                      /<?= htmlspecialchars((string)$c['note_max']) ?>
                      <?php if ((float)$c['coefficient'] != 1.0): ?>
                        | coef <?= htmlspecialchars((string)$c['coefficient']) ?>
                      <?php endif; ?>
                    </div>
                  </th>
                <?php endforeach; ?>
              </tr>
            </thead>
            <tbody>
              <tr>
                <?php foreach ($cols as $c): ?>
                  <?php
                    $cid = (int)$c['id'];
                    $n = $notesMap[$cid] ?? null;

                    if (!$n) {
                      $display = '<span class="muted">—</span>';
                    } else {
                      if ($n['statut'] === 'absent') $display = 'ABS';
                      elseif ($n['statut'] === 'dispense') $display = 'DIS';
                      elseif ($n['statut'] === 'defaillant') $display = 'DEF';
                      else {
                        $display = ($n['valeur'] !== null) ? (string)$n['valeur'] : '<span class="muted">—</span>';
                      }
                    }
                  ?>
                  <td style="text-align:center;"><?= $display ?></td>
                <?php endforeach; ?>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    <?php endforeach; ?>

  <?php endif; ?>

</div>
</body>
</html>
