<?php
require_once __DIR__ . '/../../app/auth.php';
require_once __DIR__ . '/../../app/helpers.php';
require_role('admin');
?>
<div class="grid">
  <div class="card">
    <h3>Administration</h3>
    <p class="muted">Configurer périodes, matières, affectations, colonnes, formules.</p>
    <a class="btn" href="index.php?page=admin_periodes">Périodes</a>
    <a class="btn" href="index.php?page=admin_matieres">Matières</a>
    <a class="btn" href="index.php?page=admin_affectations">Affectations</a>
    <a class="btn" href="index.php?page=admin_config_colonnes">Colonnes</a>
    <a class="btn" href="index.php?page=admin_formules">Formules</a>
  </div>
</div>
