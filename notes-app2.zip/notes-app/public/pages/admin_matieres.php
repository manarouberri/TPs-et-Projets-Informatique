<?php
require_once __DIR__ . '/../../app/auth.php';
require_once __DIR__ . '/../../app/helpers.php';
require_once __DIR__ . '/../../app/csrf.php';
require_once __DIR__ . '/../../app/db.php';
require_role('admin');

$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_check();
  if (($_POST['action'] ?? '') === 'add_filiere') {
    $pdo->prepare("INSERT INTO filieres(code,nom,niveau,responsable_id) VALUES(?,?,?,NULL)")
        ->execute([trim($_POST['f_code']), trim($_POST['f_nom']), trim($_POST['f_niveau'])]);
    redirect('index.php?page=admin_matieres');
  }
  if (($_POST['action'] ?? '') === 'add_matiere') {
    $pdo->prepare("INSERT INTO matieres(code,nom,filiere_id,coefficient,credits,seuil_validation) VALUES(?,?,?,?,?,?)")
        ->execute([trim($_POST['m_code']), trim($_POST['m_nom']), (int)$_POST['filiere_id'], (float)$_POST['coef'], (int)$_POST['credits'], (float)$_POST['seuil']]);
    redirect('index.php?page=admin_matieres');
  }
}

$filieres = $pdo->query("SELECT * FROM filieres ORDER BY id DESC")->fetchAll();
$matieres = $pdo->query("SELECT m.*, f.nom AS filiere_nom FROM matieres m JOIN filieres f ON f.id=m.filiere_id ORDER BY m.id DESC")->fetchAll();
?>
<div class="grid">
  <div class="card">
    <h2>Filières</h2>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="action" value="add_filiere">
      <label>Code</label><input name="f_code" required>
      <label>Nom</label><input name="f_nom" required>
      <label>Niveau</label><input name="f_niveau" placeholder="Licence / Master">
      <button class="btn" style="margin-top:10px;">Ajouter filière</button>
    </form>
  </div>

  <div class="card">
    <h2>Matières</h2>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="action" value="add_matiere">
      <label>Code</label><input name="m_code" required>
      <label>Nom</label><input name="m_nom" required>
      <label>Filière</label>
      <select name="filiere_id" required>
        <?php foreach($filieres as $f): ?>
          <option value="<?= (int)$f['id'] ?>"><?= e($f['code'].' - '.$f['nom']) ?></option>
        <?php endforeach; ?>
      </select>
      <div class="grid" style="grid-template-columns:repeat(3,1fr);margin-top:10px;">
        <div><label>Coef</label><input name="coef" type="number" step="0.1" value="1"></div>
        <div><label>Crédits</label><input name="credits" type="number" value="6"></div>
        <div><label>Seuil</label><input name="seuil" type="number" step="0.01" value="10"></div>
      </div>
      <button class="btn" style="margin-top:10px;">Ajouter matière</button>
    </form>
  </div>
</div>

<div class="card">
  <h3>Liste matières</h3>
  <table>
    <tr><th>ID</th><th>Code</th><th>Nom</th><th>Filière</th><th>Coef</th></tr>
    <?php foreach($matieres as $m): ?>
      <tr>
        <td><?= (int)$m['id'] ?></td>
        <td><span class="badge"><?= e($m['code']) ?></span></td>
        <td><?= e($m['nom']) ?></td>
        <td><?= e($m['filiere_nom']) ?></td>
        <td><?= e((string)$m['coefficient']) ?></td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>
