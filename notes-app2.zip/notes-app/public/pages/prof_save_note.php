<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/auth.php';
require_once __DIR__ . '/../../app/helpers.php';
require_once __DIR__ . '/../../app/csrf.php';
require_once __DIR__ . '/../../app/db.php';
require_once __DIR__ . '/../../app/FormulaParser.php';

require_role('professeur');

header('Content-Type: application/json; charset=utf-8');

function json_out(int $code, array $payload): void {
  http_response_code($code);
  echo json_encode($payload, JSON_UNESCAPED_UNICODE);
  exit;
}

/**
 * Remplace MOYENNE(x,y,...) par une expression arithmétique safe:
 * MOYENNE(A,B,C) => (A + B + C) / 3
 * Ignore les arguments vides (mais pas NULL => NULL restera NULL et donnera NULL au final)
 */
function expand_moyenne(string $formula): string {
  // boucle tant qu'on trouve MOYENNE(...)
  while (preg_match('/MOYENNE\s*\(([^()]*)\)/i', $formula, $m)) {
    $inside = trim($m[1]);

    // split simple par virgule (sans parenthèses internes dans notre cas)
    $parts = array_values(array_filter(array_map('trim', explode(',', $inside)), fn($x) => $x !== ''));

    if (count($parts) === 0) {
      // MOYENNE() => NULL
      $replacement = 'NULL';
    } else {
      $sum = '(' . implode(' + ', $parts) . ')';
      $replacement = '(' . $sum . ' / ' . count($parts) . ')';
    }

    // remplace uniquement la première occurrence trouvée
    $formula = preg_replace('/MOYENNE\s*\(([^()]*)\)/i', $replacement, $formula, 1);
  }
  return $formula;
}

try {
  if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(405, ['ok'=>false,'error'=>'Method not allowed']);
  }

  // CSRF (attend POST name="csrf")
  csrf_check();

  $pdo = db();
  $u   = auth_user();

  $etudiant_id = (int)($_POST['etudiant_id'] ?? 0);
  $colonne_id  = (int)($_POST['colonne_id'] ?? 0);
  $raw         = trim((string)($_POST['valeur'] ?? ''));

  if ($etudiant_id <= 0 || $colonne_id <= 0) {
    json_out(400, ['ok'=>false,'error'=>'Paramètres invalides']);
  }

  // Récup colonne + statut période
  $st = $pdo->prepare("
    SELECT c.id, c.matiere_id, c.periode_id, c.note_max, c.code_colonne, p.statut
    FROM configuration_colonnes c
    JOIN periodes p ON p.id = c.periode_id
    WHERE c.id = ?
    LIMIT 1
  ");
  $st->execute([$colonne_id]);
  $col = $st->fetch(PDO::FETCH_ASSOC);

  if (!$col) {
    json_out(404, ['ok'=>false,'error'=>'Colonne introuvable']);
  }

  $matiere_id = (int)$col['matiere_id'];
  $periode_id = (int)$col['periode_id'];

  // Vérifier affectation prof
  $st = $pdo->prepare("
    SELECT 1
    FROM affectations_profs
    WHERE professeur_id=? AND matiere_id=? AND periode_id=?
    LIMIT 1
  ");
  $st->execute([(int)$u['id'], $matiere_id, $periode_id]);
  if (!$st->fetchColumn()) {
    json_out(403, ['ok'=>false,'error'=>'Non autorisé']);
  }

  if (in_array((string)$col['statut'], ['fermee','publiee'], true)) {
    json_out(403, ['ok'=>false,'error'=>'Période verrouillée']);
  }

  // Convertir valeur + statut
  $statut = 'saisie';
  $valeur = null;

  $upper = strtoupper($raw);
  if ($upper === 'ABS') $statut = 'absent';
  elseif ($upper === 'DIS') $statut = 'dispense';
  elseif ($upper === 'DEF') $statut = 'defaillant';
  elseif ($raw === '') { $statut = 'saisie'; $valeur = null; }
  else {
    if (!is_numeric($raw)) {
      json_out(400, ['ok'=>false,'error'=>'Valeur invalide (nombre, ABS, DIS, DEF)']);
    }
    $val = (float)$raw;
    $max = (float)$col['note_max'];
    if ($val < 0 || $val > $max) {
      json_out(400, ['ok'=>false,'error'=>"Note hors plage 0..{$max}"]);
    }
    $valeur = $val;
  }

  // Upsert note
  $st = $pdo->prepare("
    INSERT INTO notes(etudiant_id, colonne_id, valeur, statut, saisi_par)
    VALUES(?,?,?,?,?)
    ON DUPLICATE KEY UPDATE
      valeur=VALUES(valeur),
      statut=VALUES(statut),
      saisi_par=VALUES(saisi_par),
      date_modification=NOW()
  ");
  $st->execute([$etudiant_id, $colonne_id, $valeur, $statut, (int)$u['id']]);

  // Charger formule
  $formStmt = $pdo->prepare("SELECT formule FROM formules WHERE matiere_id=? AND periode_id=? LIMIT 1");
  $formStmt->execute([$matiere_id, $periode_id]);
  $formRow = $formStmt->fetch(PDO::FETCH_ASSOC);
  $formule = isset($formRow['formule']) ? trim((string)$formRow['formule']) : '';

  $moy = null;

  if ($formule !== '') {
    // ✅ Expand MOYENNE(...) en expression arithmétique
    $formule = expand_moyenne($formule);

    // Colonnes de la matière
    $colsStmt = $pdo->prepare("
      SELECT id, code_colonne
      FROM configuration_colonnes
      WHERE matiere_id=? AND periode_id=?
      ORDER BY ordre
    ");
    $colsStmt->execute([$matiere_id, $periode_id]);
    $cols = $colsStmt->fetchAll(PDO::FETCH_ASSOC);

    if ($cols) {
      $ids = array_map(fn($c)=> (int)$c['id'], $cols);
      $in  = implode(',', array_fill(0, count($ids), '?'));

      $stmt = $pdo->prepare("SELECT colonne_id, valeur, statut FROM notes WHERE etudiant_id=? AND colonne_id IN ($in)");
      $stmt->execute(array_merge([$etudiant_id], $ids));
      $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

      $map = [];
      foreach ($rows as $r) $map[(int)$r['colonne_id']] = $r;

      $vars = [];
      foreach ($cols as $c) {
        $cid  = (int)$c['id'];
        $code = (string)$c['code_colonne'];

        $r    = $map[$cid] ?? null;
        $v    = $r ? $r['valeur'] : null;
        $stt  = $r ? (string)$r['statut'] : 'saisie';

        if (in_array($stt, ['absent','dispense','defaillant'], true)) $v = null;

        $vars[$code] = ($v === null || $v === '') ? null : (float)$v;
      }

      // Eval formule
      try {
        $parser = new FormulaParser();
        $res = $parser->eval($formule, $vars);
        $moy = ($res === null) ? null : round((float)$res, 2);
      } catch (Throwable $e) {
        // Si formule invalide => moyenne null, mais on n'arrête pas la saisie
        $moy = null;
      }
    }
  }

  json_out(200, ['ok'=>true, 'moyenne'=>$moy]);

} catch (Throwable $e) {
  json_out(500, ['ok'=>false, 'error'=>'Erreur serveur: '.$e->getMessage()]);
}
