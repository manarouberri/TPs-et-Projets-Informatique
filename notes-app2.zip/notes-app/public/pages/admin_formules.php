<?php
require_once __DIR__ . '/../../app/auth.php';
require_once __DIR__ . '/../../app/helpers.php';
require_once __DIR__ . '/../../app/csrf.php';
require_once __DIR__ . '/../../app/db.php';
require_role('admin');

$pdo = db();

$periodes = $pdo->query("SELECT id, nom FROM periodes ORDER BY id DESC")->fetchAll();
$matieres = $pdo->query("SELECT id, code, nom FROM matieres ORDER BY nom")->fetchAll();

$matiere_id = (int)($_GET['matiere_id'] ?? ($matieres[0]['id'] ?? 0));
$periode_id = (int)($_GET['periode_id'] ?? ($periodes[0]['id'] ?? 0));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_check();
  $matiere_id = (int)$_POST['matiere_id'];
  $periode_id = (int)$_POST['periode_id'];
  $formule = trim($_POST['formule']);

  $pdo->prepare("INSERT INTO formules(matiere_id,periode_id,formule,description)
                 VALUES(?,?,?,?)
                 ON DUPLICATE KEY UPDATE formule=VALUES(formule), description=VALUES(description)")
      ->execute([$matiere_id,$periode_id,$formule, trim($_POST['description'] ?? '')]);

  redirect("index.php?page=admin_formules&matiere_id=$matiere_id&periode_id=$periode_id");
}

$stmt = $pdo->prepare("SELECT * FROM formules WHERE matiere_id=? AND periode_id=?");
$stmt->execute([$matiere_id,$periode_id]);
$f = $stmt->fetch();

$colsStmt = $pdo->prepare("SELECT code_colonne FROM configuration_colonnes WHERE matiere_id=? AND periode_id=? ORDER BY ordre");
$colsStmt->execute([$matiere_id,$periode_id]);
$vars = array_map(fn($r) => $r['code_colonne'], $colsStmt->fetchAll());
?>
<div class="card">
  <h2>Formules</h2>

  <form method="get" class="grid" style="grid-template-columns:repeat(2,1fr);">
    <input type="hidden" name="page" value="admin_formules">
    <div>
      <label>Matière</label>
      <select name="matiere_id" onchange="this.form.submit()">
        <?php foreach($matieres as $m): ?>
          <option value="<?= (int)$m['id'] ?>" <?= $m['id']==$matiere_id?'selected':'' ?>>
            <?= e($m['code'].' - '.$m['nom']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label>Période</label>
      <select name="periode_id" onchange="this.form.submit()">
        <?php foreach($periodes as $p): ?>
          <option value="<?= (int)$p['id'] ?>" <?= $p['id']==$periode_id?'selected':'' ?>>
            <?= e($p['nom']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
  </form>
</div>

<div class="card">
  <div class="notice">
    <b>Variables disponibles :</b> <?= e(implode(', ', $vars)) ?><br>
    <b>Astuce :</b> pour les TP, tu peux utiliser <b>TPMOY</b> (calculé automatiquement si TP1/TP2/TP3 existent).
  </div>

  <form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="matiere_id" value="<?= (int)$matiere_id ?>">
    <input type="hidden" name="periode_id" value="<?= (int)$periode_id ?>">

    <label>Description</label>
    <input name="description" value="<?= e($f['description'] ?? '') ?>">

    <label style="margin-top:10px;">Formule</label>
    <textarea name="formule" rows="3" required><?= e($f['formule'] ?? '') ?></textarea>

    <button class="btn" style="margin-top:10px;">Enregistrer</button>
  </form>
</div>
