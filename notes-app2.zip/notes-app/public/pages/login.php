<?php
require_once __DIR__ . '/../../app/helpers.php';
require_once __DIR__ . '/../../app/auth.php';
require_once __DIR__ . '/../../app/csrf.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_check();
  $email = trim($_POST['email'] ?? '');
  $pass  = (string)($_POST['password'] ?? '');

  if (login($email, $pass)) redirect('index.php?page=home');
  $error = "Email ou mot de passe incorrect.";
}
?>
<div class="card" style="max-width:420px;margin:40px auto;">
  <h2>Connexion</h2>
  <?php if ($error): ?><div class="error"><?= e($error) ?></div><?php endif; ?>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
    <label>Email</label>
    <input name="email" type="email" required>
    <label style="margin-top:10px;display:block;">Mot de passe</label>
    <input name="password" type="password" required>
    <button class="btn" style="margin-top:12px;width:100%;">Se connecter</button>
  </form>
  <p class="small muted" style="margin-top:10px;">
    Admin: admin@uni.ma / Admin@123<br>
    Prof: prof1@uni.ma / Prof@123<br>
    Étudiant: etu1@uni.ma / Etu@123
  </p>
</div>
