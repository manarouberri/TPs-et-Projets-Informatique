<?php
require_once __DIR__ . '/../../app/auth.php';
require_once __DIR__ . '/../../app/helpers.php';
require_once __DIR__ . '/../../app/csrf.php';
require_once __DIR__ . '/../../app/db.php';
require_role('admin');

$pdo = db();

$periodes = $pdo->query("SELECT id, nom FROM periodes ORDER BY id DESC")->fetchAll();
$matieres = $pdo->query("SELECT id, code, nom FROM matieres ORDER BY nom")->fetchAll();

$matiere_id = (int)($_GET['matiere_id'] ?? ($matieres[0]['id'] ?? 0));
$periode_id = (int)($_GET['periode_id'] ?? ($periodes[0]['id'] ?? 0));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_check();
  $matiere_id = (int)$_POST['matiere_id'];
  $periode_id = (int)$_POST['periode_id'];

  // Sécurité pro: ne pas modifier si période fermée/publiee (exemple)
  $stat = $pdo->prepare("SELECT statut FROM periodes WHERE id=?");
  $stat->execute([$periode_id]);
  $periode = $stat->fetch();
  if (!$periode || in_array($periode['statut'], ['fermee','publiee'], true)) {
    exit('Période verrouillée');
  }

  $pdo->prepare("INSERT INTO configuration_colonnes(matiere_id,periode_id,nom_colonne,code_colonne,type,note_max,coefficient,obligatoire,ordre)
                 VALUES(?,?,?,?,?,?,?,?,?)")
      ->execute([
        $matiere_id, $periode_id,
        trim($_POST['nom_colonne']),
        strtoupper(trim($_POST['code_colonne'])),
        $_POST['type'],
        (float)$_POST['note_max'],
        (float)$_POST['coefficient'],
        isset($_POST['obligatoire']) ? 1 : 0,
        (int)$_POST['ordre']
      ]);

  redirect("index.php?page=admin_config_colonnes&matiere_id=$matiere_id&periode_id=$periode_id");
}

$stmt = $pdo->prepare("SELECT * FROM configuration_colonnes WHERE matiere_id=? AND periode_id=? ORDER BY ordre ASC");
$stmt->execute([$matiere_id,$periode_id]);
$cols = $stmt->fetchAll();
?>
<div class="card">
  <h2>Colonnes dynamiques</h2>

  <form method="get" class="grid" style="grid-template-columns:repeat(2,1fr);">
    <input type="hidden" name="page" value="admin_config_colonnes">
    <div>
      <label>Matière</label>
      <select name="matiere_id" onchange="this.form.submit()">
        <?php foreach($matieres as $m): ?>
          <option value="<?= (int)$m['id'] ?>" <?= $m['id']==$matiere_id?'selected':'' ?>>
            <?= e($m['code'].' - '.$m['nom']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label>Période</label>
      <select name="periode_id" onchange="this.form.submit()">
        <?php foreach($periodes as $p): ?>
          <option value="<?= (int)$p['id'] ?>" <?= $p['id']==$periode_id?'selected':'' ?>>
            <?= e($p['nom']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
  </form>
</div>

<div class="card">
  <h3>Ajouter une colonne</h3>
  <form method="post" class="grid" style="grid-template-columns:repeat(4,1fr);">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="matiere_id" value="<?= (int)$matiere_id ?>">
    <input type="hidden" name="periode_id" value="<?= (int)$periode_id ?>">

    <div><label>Nom</label><input name="nom_colonne" required></div>
    <div><label>Code (formule)</label><input name="code_colonne" required placeholder="DS1 / EXAM"></div>
    <div>
      <label>Type</label>
      <select name="type">
        <option value="note">note</option>
        <option value="bonus">bonus</option>
        <option value="malus">malus</option>
        <option value="info">info</option>
      </select>
    </div>
    <div><label>Ordre</label><input name="ordre" type="number" value="<?= count($cols)+1 ?>"></div>

    <div><label>Note max</label><input name="note_max" type="number" step="0.01" value="20"></div>
    <div><label>Coef</label><input name="coefficient" type="number" step="0.01" value="1"></div>
    <div style="display:flex;gap:8px;align-items:end;">
      <label><input type="checkbox" name="obligatoire" checked> Obligatoire</label>
    </div>
    <div style="align-self:end;"><button class="btn">Ajouter</button></div>
  </form>
</div>

<div class="card">
  <h3>Colonnes actuelles</h3>
  <table>
    <tr><th>Ordre</th><th>Nom</th><th>Code</th><th>Type</th><th>Max</th><th>Coef</th></tr>
    <?php foreach($cols as $c): ?>
      <tr>
        <td><?= (int)$c['ordre'] ?></td>
        <td><?= e($c['nom_colonne']) ?></td>
        <td><span class="badge"><?= e($c['code_colonne']) ?></span></td>
        <td><?= e($c['type']) ?></td>
        <td><?= e((string)$c['note_max']) ?></td>
        <td><?= e((string)$c['coefficient']) ?></td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>
