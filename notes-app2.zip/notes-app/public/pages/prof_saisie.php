<?php
// public/pages/prof_saisie.php
declare(strict_types=1);

require_once __DIR__ . '/../../app/auth.php';
require_once __DIR__ . '/../../app/helpers.php';
require_once __DIR__ . '/../../app/csrf.php';
require_once __DIR__ . '/../../app/db.php';
require_once __DIR__ . '/../../app/FormulaParser.php';

require_role('professeur');

$pdo = db();
$u   = auth_user();

$matiere_id = (int)($_GET['matiere_id'] ?? 0);
$periode_id = (int)($_GET['periode_id'] ?? 0);

if ($matiere_id <= 0 || $periode_id <= 0) {
  exit('Paramètres invalides.');
}

// Vérifier affectation prof + statut période
$check = $pdo->prepare("
  SELECT a.*, p.statut
  FROM affectations_profs a
  JOIN periodes p ON p.id = a.periode_id
  WHERE a.professeur_id = ? AND a.matiere_id = ? AND a.periode_id = ?
  LIMIT 1
");
$check->execute([(int)$u['id'], $matiere_id, $periode_id]);
$aff = $check->fetch();

if (!$aff) exit('Non autorisé');

$locked = in_array((string)$aff['statut'], ['fermee', 'publiee'], true);

// Colonnes dynamiques
$colsStmt = $pdo->prepare("
  SELECT *
  FROM configuration_colonnes
  WHERE matiere_id = ? AND periode_id = ?
  ORDER BY ordre
");
$colsStmt->execute([$matiere_id, $periode_id]);
$cols = $colsStmt->fetchAll();

if (!$cols) exit('Aucune colonne définie pour cette matière/période.');

// Étudiants inscrits
$studentsStmt = $pdo->prepare("
  SELECT u.id, u.nom, u.prenom
  FROM inscriptions_matieres i
  JOIN utilisateurs u ON u.id = i.etudiant_id
  WHERE i.matiere_id = ? AND i.periode_id = ?
  ORDER BY u.nom, u.prenom
");
$studentsStmt->execute([$matiere_id, $periode_id]);
$students = $studentsStmt->fetchAll();

// Formule
$formStmt = $pdo->prepare("SELECT formule FROM formules WHERE matiere_id=? AND periode_id=? LIMIT 1");
$formStmt->execute([$matiere_id, $periode_id]);
$formRow = $formStmt->fetch();
$formule = $formRow['formule'] ?? null;

$parser = new FormulaParser();

function getNoteMap(PDO $pdo, int $etudiant_id, array $cols): array {
  if (count($cols) === 0) return [];
  $ids = array_map(fn($c) => (int)$c['id'], $cols);
  $in  = implode(',', array_fill(0, count($ids), '?'));

  $stmt = $pdo->prepare("SELECT colonne_id, valeur, statut FROM notes WHERE etudiant_id=? AND colonne_id IN ($in)");
  $stmt->execute(array_merge([$etudiant_id], $ids));
  $rows = $stmt->fetchAll();

  $map = [];
  foreach ($rows as $r) {
    $map[(int)$r['colonne_id']] = [
      'valeur' => $r['valeur'],
      'statut' => (string)$r['statut']
    ];
  }
  return $map;
}

function computeTPMOY(array $vars): ?float {
  $tps = [];
  foreach (['TP1','TP2','TP3'] as $k) {
    if (isset($vars[$k]) && is_numeric($vars[$k])) $tps[] = (float)$vars[$k];
  }
  if (count($tps) === 0) return null;
  return array_sum($tps) / count($tps);
}

?>
<div class="card">
  <h2>Saisie des notes</h2>
  <div class="notice">
    Statut période : <b><?= e((string)$aff['statut']) ?></b>
    <?php if ($locked): ?> — <b>verrouillée</b> (saisie bloquée)<?php endif; ?><br>
    Formule : <b><?= e($formule ?? 'Aucune formule') ?></b>
  </div>

  <?php if (!empty($_GET['ok'])): ?>
    <div class="success" style="margin-top:10px;"><?= e((string)$_GET['ok']) ?></div>
  <?php endif; ?>
  <?php if (!empty($_GET['err'])): ?>
    <div class="error" style="margin-top:10px;"><?= e((string)$_GET['err']) ?></div>
  <?php endif; ?>
</div>

<div class="card">
  <table>
    <tr>
      <th>Étudiant</th>
      <?php foreach($cols as $c): ?>
        <th class="cell">
          <?= e((string)$c['nom_colonne']) ?>
          <div class="small muted">Max <?= e((string)$c['note_max']) ?></div>
        </th>
      <?php endforeach; ?>
      <th>Moyenne</th>
    </tr>

    <?php foreach($students as $s): ?>
      <?php
        $etudiantId = (int)$s['id'];
        $map = getNoteMap($pdo, $etudiantId, $cols);

        // Variables pour la formule (DS1, DS2, EXAM, TP1...)
        $vars = [];
        foreach($cols as $c) {
          $colId = (int)$c['id'];
          $code  = (string)$c['code_colonne'];

          $val  = $map[$colId]['valeur'] ?? null;
          $stat = $map[$colId]['statut'] ?? 'saisie';

          // ABS/DIS/DEF => NULL pour le calcul
          if (in_array($stat, ['absent','dispense','defaillant'], true)) $val = null;

          // garder null ou numeric
          $vars[$code] = (is_numeric($val) ? (float)$val : null);
        }

        // Optionnel : moyenne des TP si tu utilises TPMOY dans une formule
        $vars['TPMOY'] = computeTPMOY($vars);

        // Calcul moyenne via parser (✅ méthode eval)
        $moy = null;
        if ($formule) {
          try {
            $moy = $parser->eval((string)$formule, $vars); // ✅ IMPORTANT
          } catch (Throwable $e) {
            $moy = null;
          }
        }
      ?>
      <tr>
        <td><?= e($s['nom'].' '.$s['prenom']) ?></td>

        <?php foreach($cols as $c): ?>
          <?php
            $colId = (int)$c['id'];
            $val   = $map[$colId]['valeur'] ?? '';
            $stat  = $map[$colId]['statut'] ?? 'saisie';
            $max   = (float)$c['note_max'];
            $display = $val;

            if ($stat === 'absent')      $display = 'ABS';
            if ($stat === 'dispense')    $display = 'DIS';
            if ($stat === 'defaillant')  $display = 'DEF';
          ?>
          <td>
            <input
              class="noteInput"
              <?= $locked ? 'disabled' : '' ?>
              data-etudiant-id="<?= $etudiantId ?>"
              data-colonne-id="<?= $colId ?>"
              value="<?= e((string)$display) ?>"
              placeholder="0..<?= e((string)$max) ?> / ABS"
            >
            <div class="small muted">coef <?= e((string)$c['coefficient']) ?></div>
          </td>
        <?php endforeach; ?>

        <td class="moyCell" data-etudiant-id="<?= $etudiantId ?>">
          <b><?= $moy === null ? '-' : e((string)$moy) ?></b>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>

  <div style="margin-top:12px;display:flex;gap:10px;align-items:center;">
    <a class="btn secondary" href="index.php?page=prof_matieres">Retour</a>

    <?php if (!$locked): ?>
      <form method="post" action="index.php?page=prof_valider" style="margin:0;">
        <!-- ✅ CSRF name = csrf (compatible csrf_check()) -->
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="matiere_id" value="<?= (int)$matiere_id ?>">
        <input type="hidden" name="periode_id" value="<?= (int)$periode_id ?>">

        <button type="submit" class="btn"
          onclick="return confirm('Valider la saisie ? Après validation, vous confirmez que toutes les notes sont complètes.');">
          Valider la saisie
        </button>
      </form>
    <?php else: ?>
      <button class="btn" disabled title="Période verrouillée">Valider la saisie</button>
    <?php endif; ?>
  </div>
</div>
