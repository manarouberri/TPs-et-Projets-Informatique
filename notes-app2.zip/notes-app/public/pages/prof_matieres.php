<?php
require_once __DIR__ . '/../../app/auth.php';
require_once __DIR__ . '/../../app/helpers.php';
require_once __DIR__ . '/../../app/db.php';
require_role('professeur');

$pdo = db();
$u = auth_user();

$stmt = $pdo->prepare("
  SELECT a.id AS aff_id, m.id AS matiere_id, m.code, m.nom,
         p.id AS periode_id, p.nom AS periode_nom, p.statut, a.groupe
  FROM affectations_profs a
  JOIN matieres m ON m.id=a.matiere_id
  JOIN periodes p ON p.id=a.periode_id
  WHERE a.professeur_id=?
  ORDER BY p.id DESC, m.nom
");
$stmt->execute([$u['id']]);
$rows = $stmt->fetchAll();
?>
<div class="card">
  <h2>Mes matières</h2>
  <table>
    <tr><th>Matière</th><th>Période</th><th>Groupe</th><th>Statut</th><th>Action</th></tr>
    <?php foreach($rows as $r): ?>
      <tr>
        <td><?= e($r['code'].' - '.$r['nom']) ?></td>
        <td><?= e($r['periode_nom']) ?></td>
        <td><?= e($r['groupe']) ?></td>
        <td><span class="badge"><?= e($r['statut']) ?></span></td>
        <td>
          <a class="btn" href="index.php?page=prof_saisie&matiere_id=<?= (int)$r['matiere_id'] ?>&periode_id=<?= (int)$r['periode_id'] ?>">
            Saisir
          </a>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>
