<?php
require_once __DIR__ . '/../../app/auth.php';
require_once __DIR__ . '/../../app/helpers.php';
require_once __DIR__ . '/../../app/csrf.php';
require_once __DIR__ . '/../../app/db.php';

require_role('admin');

$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_check();

  $nom = trim($_POST['nom'] ?? '');
  $code = trim($_POST['code'] ?? '');
  $annee = trim($_POST['annee'] ?? '');
  $type = $_POST['type'] ?? 'semestre';
  $deb = $_POST['debut'] ?? '';
  $fin = $_POST['fin'] ?? '';
  $statut = $_POST['statut'] ?? 'a_venir';

  $stmt = $pdo->prepare("
    INSERT INTO periodes(nom,code,annee_universitaire,type,date_debut_saisie,date_fin_saisie,statut)
    VALUES(?,?,?,?,?,?,?)
  ");
  $stmt->execute([$nom,$code,$annee,$type,$deb,$fin,$statut]);

  redirect('index.php?page=admin_periodes');
}

$periodes = $pdo->query("SELECT * FROM periodes ORDER BY id DESC")->fetchAll();
?>

<div class="card">
  <h2>Périodes</h2>

  <form method="post" class="grid" style="grid-template-columns:repeat(3,1fr);">
<input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">

    <div><label>Nom</label><input name="nom" required></div>
    <div><label>Code</label><input name="code" required></div>
    <div><label>Année</label><input name="annee" placeholder="2024-2025" required></div>

    <div>
      <label>Type</label>
      <select name="type">
        <option value="semestre">semestre</option>
        <option value="trimestre">trimestre</option>
        <option value="session">session</option>
        <option value="rattrapage">rattrapage</option>
      </select>
    </div>

    <div><label>Début saisie</label><input type="datetime-local" name="debut" required></div>
    <div><label>Fin saisie</label><input type="datetime-local" name="fin" required></div>

    <div>
      <label>Statut</label>
      <select name="statut">
        <option value="a_venir">a_venir</option>
        <option value="ouverte">ouverte</option>
        <option value="fermee">fermee</option>
        <option value="publiee">publiee</option>
      </select>
    </div>

    <div style="align-self:end;"><button class="btn">Ajouter</button></div>
  </form>
</div>

<div class="card">
  <h3>Liste</h3>
  <table>
    <tr>
      <th>ID</th>
      <th>Nom</th>
      <th>Code</th>
      <th>Année</th>
      <th>Statut</th>
      <th>Fenêtre saisie</th>
      <th>Action</th>
    </tr>

    <?php foreach($periodes as $p): ?>
      <tr>
        <td><?= (int)$p['id'] ?></td>
        <td><?= e($p['nom']) ?></td>
        <td><span class="badge"><?= e($p['code']) ?></span></td>
        <td><?= e($p['annee_universitaire']) ?></td>
        <td><?= e($p['statut']) ?></td>
        <td class="small"><?= e($p['date_debut_saisie']) ?> → <?= e($p['date_fin_saisie']) ?></td>

        <td>
          <?php if ($p['statut'] !== 'publiee'): ?>
            <form method="post"
      action="index.php?page=admin_publier_periode"
      onsubmit="return confirm('Publier cette période ? Cela recalculera toutes les moyennes.');"
      style="margin:0;">
  <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
  <input type="hidden" name="periode_id" value="<?= (int)$p['id'] ?>">
  <button type="submit" class="btn small">📢 Publier</button>
</form>

          <?php else: ?>
            <span class="badge">Déjà publiée</span>
          <?php endif; ?>
        </td>

      </tr>
    <?php endforeach; ?>
  </table>
</div>
