<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/auth.php';
require_once __DIR__ . '/../../app/helpers.php';
require_once __DIR__ . '/../../app/csrf.php';
require_once __DIR__ . '/../../app/db.php';

require_role('admin');

$pdo = db();

$ok = $_GET['ok'] ?? '';
$err = $_GET['err'] ?? '';

// =========================
// POST: Ajouter / Supprimer
// =========================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_check();

  $action = $_POST['action'] ?? 'add';

  // ---- SUPPRIMER ----
  if ($action === 'delete') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) {
      redirect('index.php?page=admin_affectations&err=' . urlencode("ID invalide"));
    }

    $st = $pdo->prepare("DELETE FROM affectations_profs WHERE id=?");
    $st->execute([$id]);

    redirect('index.php?page=admin_affectations&ok=' . urlencode("Affectation supprimée ✅"));
  }

  // ---- AJOUTER ----
  $prof_id   = (int)($_POST['professeur_id'] ?? 0);
  $mat_id    = (int)($_POST['matiere_id'] ?? 0);
  $per_id    = (int)($_POST['periode_id'] ?? 0);
  $groupe    = trim($_POST['groupe'] ?? 'Tous');
  if ($groupe === '') $groupe = 'Tous';

  if ($prof_id <= 0 || $mat_id <= 0 || $per_id <= 0) {
    redirect('index.php?page=admin_affectations&err=' . urlencode("Paramètres invalides"));
  }

  // Eviter doublons
  $check = $pdo->prepare("
    SELECT id FROM affectations_profs
    WHERE professeur_id=? AND matiere_id=? AND periode_id=? AND groupe=?
    LIMIT 1
  ");
  $check->execute([$prof_id, $mat_id, $per_id, $groupe]);
  $exists = $check->fetchColumn();

  if ($exists) {
    redirect('index.php?page=admin_affectations&err=' . urlencode("Affectation déjà existante (doublon)."));
  }

  $stmt = $pdo->prepare("
    INSERT INTO affectations_profs(professeur_id, matiere_id, periode_id, groupe)
    VALUES (?,?,?,?)
  ");
  $stmt->execute([$prof_id, $mat_id, $per_id, $groupe]);

  redirect('index.php?page=admin_affectations&ok=' . urlencode("Affectation ajoutée ✅"));
}

// =========================
// Données pour affichage
// =========================
$profs = $pdo->query("SELECT id, nom, prenom, email FROM utilisateurs WHERE role='professeur' ORDER BY nom, prenom")->fetchAll();
$matieres = $pdo->query("SELECT id, code, nom FROM matieres ORDER BY nom")->fetchAll();
$periodes = $pdo->query("SELECT id, nom, code, statut FROM periodes ORDER BY id DESC")->fetchAll();

$affs = $pdo->query("
  SELECT a.id, a.groupe,
         u.nom AS prof_nom, u.prenom AS prof_prenom,
         m.code AS mat_code, m.nom AS mat_nom,
         p.nom AS per_nom, p.code AS per_code
  FROM affectations_profs a
  JOIN utilisateurs u ON u.id = a.professeur_id
  JOIN matieres m ON m.id = a.matiere_id
  JOIN periodes p ON p.id = a.periode_id
  ORDER BY p.id DESC, m.nom ASC, u.nom ASC
")->fetchAll();
?>

<div class="card">
  <h2>Affectations Professeurs</h2>

  <?php if ($ok): ?>
    <div class="notice"><?= e($ok) ?></div>
  <?php endif; ?>
  <?php if ($err): ?>
    <div class="notice error"><?= e($err) ?></div>
  <?php endif; ?>

  <form method="post" class="grid" style="grid-template-columns:repeat(4,1fr);gap:12px;">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="action" value="add">

    <div>
      <label>Professeur</label>
      <select name="professeur_id" required>
        <option value="">-- choisir --</option>
        <?php foreach($profs as $p): ?>
          <option value="<?= (int)$p['id'] ?>"><?= e($p['prenom'].' '.$p['nom'].' ('.$p['email'].')') ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label>Matière</label>
      <select name="matiere_id" required>
        <option value="">-- choisir --</option>
        <?php foreach($matieres as $m): ?>
          <option value="<?= (int)$m['id'] ?>"><?= e($m['code'].' - '.$m['nom']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label>Période</label>
      <select name="periode_id" required>
        <option value="">-- choisir --</option>
        <?php foreach($periodes as $p): ?>
          <option value="<?= (int)$p['id'] ?>"><?= e($p['code'].' - '.$p['nom'].' ('.$p['statut'].')') ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label>Groupe</label>
      <input name="groupe" value="Tous" placeholder="Tous / Groupe A / Groupe B">
      <div style="margin-top:8px;">
        <button class="btn">Ajouter</button>
      </div>
    </div>
  </form>
</div>

<div class="card">
  <h3>Liste des affectations</h3>
  <table>
    <tr>
      <th>Professeur</th>
      <th>Matière</th>
      <th>Période</th>
      <th>Groupe</th>
      <th>Action</th>
    </tr>

    <?php foreach($affs as $a): ?>
      <tr>
        <td><?= e($a['prof_prenom'].' '.$a['prof_nom']) ?></td>
        <td><?= e($a['mat_code'].' - '.$a['mat_nom']) ?></td>
        <td><?= e($a['per_code'].' - '.$a['per_nom']) ?></td>
        <td><?= e($a['groupe']) ?></td>
        <td style="white-space:nowrap;">
          <form method="post" action="index.php?page=admin_affectations"
                style="display:inline;margin:0;"
                onsubmit="return confirm('Supprimer cette affectation ?');">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
            <button class="btn small danger" type="submit">🗑️ Supprimer</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>

  <div class="small muted" style="margin-top:8px;">
    Une affectation est unique par (professeur, matière, période, groupe).  
    Si tu veux la changer, supprime puis recrée.
  </div>
</div>
