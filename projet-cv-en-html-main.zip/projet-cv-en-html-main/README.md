# Projet CV - Site Web du Groupe

## 📋 Description
Ce projet présente un site web regroupant les CV et informations de contact des membres de notre équipe. Le site comprend plusieurs pages interconnectées pour une navigation facile.

## 👥 Membres de l'Équipe
- **Manar Ouberri**
- **Chaymae Noughou** 
- **Mohamed Khalil**
- **DJE BI TRAZIE ENOCk**
- **ocean**
## 🚀 Fonctionnalités
- **Page d'accueil** : Présentation générale du projet
- **Page CV** : Tableau comparatif des profils des membres
- **Page Contact** : Informations de contact détaillées
- **Navigation** : Menu cohérent sur toutes les pages
- **Design responsive** : Adaptation sur différents écrans

## 🛠️ Technologies Utilisées
- HTML5
- CSS3
- Git & GitHub

*Développé par l'équipe de projet
