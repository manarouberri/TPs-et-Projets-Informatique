# Serveur DHCP Ubuntu - Configuration Multi-plages

## 📋 Description du projet
Ce projet montre comment installer et configurer un serveur DHCP sous Ubuntu Server 22.04. Le serveur peut attribuer des adresses IP sur deux plages différentes dans le même réseau.

## 🎯 Objectifs
- Installer le serveur DHCP ISC
- Configurer une adresse IP fixe pour le serveur
- Créer deux plages d'adresses IP pour les clients
- Tester que tout fonctionne correctement

## 🔧 Installation

### 1. Mettre à jour le système
```bash
sudo apt update
sudo apt upgrade -y
